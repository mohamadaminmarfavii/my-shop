# گزارش تست — نسخه 3.3.0 Multi-Reference Fix

## تست‌های انجام‌شده در محیط ساخت
- PHP syntax همه فایل‌ها: PASS
- JavaScript syntax: PASS
- تبدیل شمسی/میلادی: PASS
- ZIP integrity: PASS
- جستجوی `eval`, `shell_exec`, `exec`, `base64_decode`: PASS / مورد اجرایی پیدا نشد
- `wp_ajax_nopriv`: وجود ندارد
- Query Pagination: `paged` استفاده می‌شود
- لایه Legacy Exact: مستقیماً به `WC_Report_Sales_By_Date` متصل است
- لایه Analytics: از `report-orders-stats` استفاده می‌کند
- Audit export با مدل سه‌منبعی همگام شد

## محدودیت تست آفلاین
تطبیق عددی نهایی با سفارش‌های واقعی فقط روی همان فروشگاه ممکن است. معیار پذیرش نسخه:
1. یک بازه ثابت در `WooCommerce > Reports` باز شود.
2. افزونه روی `Legacy Exact` و بدون فیلتر اضافی قرار گیرد.
3. Orders / Items / Net Sales / Total Sales / Refunds / Shipping با گزارش کلاسیک مقایسه شوند.
4. سپس تب ممیزی KPI اختلاف Legacy و Analytics را جداگانه نشان دهد.

## نتیجه
نسخه 3.3.0 مشکل «مقایسه دو موتور متفاوت WooCommerce به‌عنوان یک مرجع واحد» را برطرف می‌کند. این نسخه دیگر WooCommerce Reports کلاسیک و WooCommerce Analytics را هم‌معنی فرض نمی‌کند.


## تست‌های جدید v3.3
- مرجع پیش‌فرض Analytics است.
- حالت Sync=false هرگز canonical_kpi=true تولید نمی‌کند.
- Data Health route و UI موجود است.
- Snapshotهای Dashboard در حالت Analytics از Sync Gate عبور می‌کنند.
