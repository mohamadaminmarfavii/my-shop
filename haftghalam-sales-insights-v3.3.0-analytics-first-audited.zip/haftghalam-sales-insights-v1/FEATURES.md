# پوشش قابلیت‌ها — نسخه 3.3.0

## لایه اعتماد به داده
- WooCommerce Reports Legacy Exact: تطبیق مستقیم با `WC_Report_Sales_By_Date`.
- WooCommerce Analytics Orders Stats: مرجع مستقل مدرن.
- Independent CRUD Ledger: کنترل و گزارش فیلترشده.
- ممیزی سه‌منبعی و نمایش اختلاف Cohort.
- نمایش Reference Mode و Data Source روی داشبورد/فروش.

## گزارش‌ها
1. داشبورد KPI
2. فروش روزانه/ساعتی
3. محصولات
4. کمبود/ریسک موجودی
5. دسته‌بندی‌ها
6. برندها
7. مشتریان
8. سگمنت مشتری
9. خرید مجدد
10. جغرافیا
11. روش ارسال
12. روش پرداخت
13. لغوشده‌ها
14. دلیل لغو
15. Failed
16. قیف سفارش/سبد
17. کوپن‌ها
18. محصولات خریداری‌شده باهم
19. Attribution
20. دستگاه
21. سود و COGS Coverage
22. CSV/XLS
23. فیلتر دقیق و تاریخ شمسی
24. هشدارهای مدیریتی
25. سلامت داده و Sync Analytics ↔ CRUD
26. ممیزی KPI سه‌منبعی

## عملکرد
- Query سفارش‌ها ID-based و Lazy Hydration است.
- Pagination با `paged` انجام می‌شود.
- Dashboard بازه بزرگ مسیر Fast Reference دارد.
- Report cache با نسخه داده invalidate می‌شود.

## امنیت
- AJAX فقط برای کاربران مجاز و همراه Nonce.
- تنظیمات فقط برای manage_options.
- بدون nopriv، eval، shell execution یا API خارجی.


## لایه اعتماد داده v3.3
- Analytics-first KPI policy
- Structural Sync Gate (Analytics ↔ CRUD)
- Data Health tab with per-status reconciliation
- canonical_kpi flag on reports/exports
- Legacy retained as secondary control
