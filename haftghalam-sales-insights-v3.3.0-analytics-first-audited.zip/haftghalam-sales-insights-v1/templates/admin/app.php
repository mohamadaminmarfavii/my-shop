<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="wrap hgr-wrap hgr-theme-<?php echo esc_attr( $theme ); ?>" id="hgr-app">
    <header class="hgr-topbar">
        <div class="hgr-title-block">
            <div class="hgr-kicker">HaftGhalam Sales Intelligence</div>
            <h1>مرکز تحلیل فروش و KPI هفت‌قلم</h1>
            <p>نسخه <?php echo esc_html( HGR_VERSION ); ?> · HPOS-safe · تاریخ شمسی · گزارش و خروجی مدیریتی</p>
        </div>
        <div class="hgr-top-actions">
            <button type="button" class="hgr-btn hgr-btn-ghost" id="hgr-health">سلامت افزونه</button>
            <button type="button" class="hgr-btn hgr-btn-ghost" id="hgr-refresh">↻ بروزرسانی</button>
            <div class="hgr-export-menu">
                <button type="button" class="hgr-btn hgr-btn-primary" id="hgr-export-toggle">خروجی گزارش ▾</button>
                <div class="hgr-export-pop" id="hgr-export-pop" hidden>
                    <button type="button" data-format="csv">CSV UTF-8</button>
                    <button type="button" data-format="xls">Excel (.xls)</button>
                </div>
            </div>
        </div>
    </header>

    <section class="hgr-filter-shell">
        <div class="hgr-presets" id="hgr-presets">
            <button type="button" data-preset="today">امروز</button>
            <button type="button" data-preset="yesterday">دیروز</button>
            <button type="button" data-preset="7d">۷ روز</button>
            <button type="button" data-preset="30d" class="is-active">۳۰ روز</button>
            <button type="button" data-preset="jmonth">این ماه شمسی</button>
            <button type="button" data-preset="prev-jmonth">ماه قبل شمسی</button>
            <button type="button" data-preset="3m">۳ ماه</button>
            <button type="button" data-preset="jyear">امسال شمسی</button>
        </div>
        <div class="hgr-date-row">
            <label><span>از تاریخ شمسی</span><input type="text" inputmode="numeric" id="hgr-start-j" placeholder="1405/06/01" autocomplete="off"></label>
            <label><span>تا تاریخ شمسی</span><input type="text" inputmode="numeric" id="hgr-end-j" placeholder="1405/06/17" autocomplete="off"></label>
            <label><span>مقایسه با</span>
                <select id="hgr-compare">
                    <option value="previous_period">دوره قبل</option>
                    <option value="previous_jmonth">ماه شمسی قبل</option>
                    <option value="previous_month">ماه میلادی قبل</option>
                    <option value="last_year">سال قبل</option>
                    <option value="none">بدون مقایسه</option>
                </select>
            </label>
            <button type="button" class="hgr-btn hgr-btn-primary" id="hgr-apply">اعمال</button>
            <button type="button" class="hgr-btn hgr-btn-ghost" id="hgr-toggle-advanced">فیلترهای دقیق <span id="hgr-active-count"></span></button>
        </div>
        <div class="hgr-advanced" id="hgr-advanced" hidden>
            <div class="hgr-filter-grid">
                <label><span>وضعیت سفارش</span><select id="hgr-f-status" multiple size="4"></select></label>
                <label><span>روش پرداخت</span><select id="hgr-f-payment" multiple size="4"></select></label>
                <label><span>روش ارسال</span><select id="hgr-f-shipping" multiple size="4"></select></label>
                <label><span>استان</span><select id="hgr-f-state"><option value="">همه استان‌ها</option></select></label>
                <label><span>شهر</span><input type="search" id="hgr-f-city" placeholder="مثلاً شیراز"></label>
                <label><span>محصول</span><input type="search" id="hgr-f-product-search" placeholder="حداقل ۲ حرف از نام یا SKU"><select id="hgr-f-product"><option value="">همه محصولات</option></select><small>برای فروشگاه‌های بزرگ، لیست محصول با جستجوی Ajax بارگذاری می‌شود.</small></label>
                <label><span>دسته‌بندی</span><select id="hgr-f-category"><option value="">همه دسته‌ها</option></select></label>
                <label><span>برند</span><select id="hgr-f-brand"><option value="">همه برندها</option></select></label>
                <label><span>کد تخفیف</span><input type="search" id="hgr-f-coupon" placeholder="مثلاً PAY3SCM"></label>
                <label><span>منبع فروش</span><input type="search" id="hgr-f-source" placeholder="Google / Instagram / UTM"></label>
                <label><span>دستگاه</span><select id="hgr-f-device"><option value="">همه دستگاه‌ها</option><option value="mobile">موبایل</option><option value="desktop">دسکتاپ</option><option value="tablet">تبلت</option><option value="unknown">نامشخص</option></select></label>
                <label><span>سگمنت مشتری</span><select id="hgr-f-segment"><option value="">همه مشتریان</option></select></label>
                <label><span>حداقل مبلغ سفارش</span><input type="number" id="hgr-f-min" min="0" step="1"></label>
                <label><span>حداکثر مبلغ سفارش</span><input type="number" id="hgr-f-max" min="0" step="1"></label>
                <label class="hgr-filter-wide"><span>جستجوی سفارش/مشتری</span><input type="search" id="hgr-f-search" placeholder="شماره سفارش، نام، موبایل، ایمیل یا شهر"></label>
            </div>
            <div class="hgr-filter-actions">
                <button type="button" class="hgr-btn hgr-btn-ghost" id="hgr-clear-filters">پاک کردن فیلترها</button>
                <button type="button" class="hgr-btn hgr-btn-primary" id="hgr-apply-advanced">اعمال فیلترهای دقیق</button>
            </div>
        </div>
    </section>

    <nav class="hgr-nav-scroll" id="hgr-nav">
        <button class="hgr-nav is-active" data-report="dashboard">داشبورد</button>
        <button class="hgr-nav" data-report="sales">فروش</button>
        <button class="hgr-nav" data-report="products">محصولات</button>
        <button class="hgr-nav" data-report="categories">دسته‌بندی‌ها</button>
        <button class="hgr-nav" data-report="brands">برندها</button>
        <button class="hgr-nav" data-report="customers">مشتریان</button>
        <button class="hgr-nav" data-report="retention">وفاداری و خرید مجدد</button>
        <button class="hgr-nav" data-report="cancellations">لغو و ناموفق</button>
        <button class="hgr-nav" data-report="funnel">قیف سفارش/سبد</button>
        <button class="hgr-nav" data-report="channels">پرداخت و ارسال</button>
        <button class="hgr-nav" data-report="geography">شهرها</button>
        <button class="hgr-nav" data-report="coupons">کوپن‌ها</button>
        <button class="hgr-nav" data-report="attribution">منابع و دستگاه</button>
        <button class="hgr-nav" data-report="bundles">خریدهای ترکیبی</button>
        <button class="hgr-nav" data-report="profit">سود</button>
        <button class="hgr-nav" data-report="inventory">موجودی</button>
        <button class="hgr-nav" data-report="alerts">هشدارها</button>
        <button class="hgr-nav" data-report="data_health">سلامت داده</button>
        <button class="hgr-nav" data-report="audit">ممیزی KPI</button>
        <?php if ( $can_manage_options ) : ?><button class="hgr-nav" data-report="settings">تنظیمات / ظاهر</button><?php endif; ?>
    </nav>

    <main class="hgr-content">
        <div class="hgr-loading" id="hgr-loading" hidden><span></span><div><strong>در حال محاسبه گزارش...</strong><small>در بازه‌های بزرگ ممکن است چند ثانیه زمان ببرد.</small></div></div>
        <div class="hgr-alert" id="hgr-alert" hidden></div>
        <div class="hgr-meta-warning" id="hgr-meta-warning" hidden></div>
        <div id="hgr-view"></div>
    </main>

    <?php if ( $can_manage_options ) : ?>
    <template id="hgr-settings-template">
        <div class="hgr-settings-layout">
            <section class="hgr-panel">
                <div class="hgr-panel-head"><div><h2>تنظیمات تحلیل</h2><p>تنظیمات KPI، سود، سگمنت و ردیابی سبد خرید.</p></div></div>
                <div class="hgr-settings-grid">
                    <label><span>Taxonomy برند</span><input type="text" id="hgr-s-brand" placeholder="product_brand"></label>
                    <label><span>مرجع اصلی KPI فروش</span><select id="hgr-s-reference-mode"><option value="analytics">WooCommerce Analytics — مرجع اصلی پیشنهادی KPI</option><option value="legacy">WooCommerce Reports — Legacy Exact (فقط کنترل/تطبیق)</option></select><small>ساختار استاندارد: Analytics = KPI پایه؛ WC_Order/CRUD = تحلیل سفارشی؛ Legacy = کنترل اختلاف. اگر Analytics Sync نباشد افزونه KPI را تأییدشده علامت نمی‌زند.</small></label>
                    <label><span>وضعیت‌های لحاظ‌شده در فروش</span><select id="hgr-s-sales-statuses" multiple size="5"></select><small>اگر خالی باشد، Legacy Exact از completed/processing/on-hold/refunded و Analytics از تنظیمات خود WooCommerce استفاده می‌کند. انتخاب دستی، تطبیق دقیق با مرجع اصلی را غیرفعال می‌کند.</small></label>
                    <label><span>مبنای تاریخ KPI</span><select id="hgr-s-date-type"><option value="analytics">همان تنظیم WooCommerce Analytics (پیشنهادی)</option><option value="date_paid">تاریخ پرداخت</option><option value="date_created">تاریخ ایجاد سفارش</option><option value="date_completed">تاریخ تکمیل</option></select><small>در Legacy Exact این گزینه نادیده گرفته می‌شود و تاریخ ایجاد سفارش مبناست؛ در Analytics حالت اول توصیه می‌شود.</small></label>
                    <label><span>Meta Key بهای خرید (اختیاری)</span><input type="text" id="hgr-s-cost" placeholder="_purchase_price"></label>
                    <label><span>تبدیل مبلغ</span><select id="hgr-s-divisor"><option value="auto">خودکار (IRR÷10)</option><option value="1">بدون تقسیم</option><option value="10">تقسیم بر ۱۰</option></select></label>
                    <label><span>برچسب واحد پول</span><input type="text" id="hgr-s-money-label" value="تومان"></label>
                    <label><span>آستانه مشتری VIP</span><input type="number" id="hgr-s-vip" min="0"></label>
                    <label><span>روز تا «در خطر ریزش»</span><input type="number" id="hgr-s-risk" min="1"></label>
                    <label><span>روز تا «از دست رفته»</span><input type="number" id="hgr-s-lost" min="2"></label>
                    <label><span>ردیابی سبد رهاشده</span><select id="hgr-s-cart-tracking"><option value="yes">فعال</option><option value="no">غیرفعال</option></select><small>در صورت غیرفعال بودن، داده جدید سبد ذخیره نمی‌شود.</small></label>
                    <label><span>دقیقه تا سبد رهاشده</span><input type="number" id="hgr-s-abandoned" min="15"></label>
                    <label><span>نگهداری تاریخچه ردیابی (روز)</span><input type="number" id="hgr-s-retention-days" min="30" max="3650"></label>
                    <label><span>هشدار افت فروش (%)</span><input type="number" id="hgr-s-sales-drop" min="0" step="0.1"></label>
                    <label><span>هشدار نرخ لغو (%)</span><input type="number" id="hgr-s-cancel" min="0" step="0.1"></label>
                    <label><span>هشدار ناموفق (%)</span><input type="number" id="hgr-s-failed" min="0" step="0.1"></label>
                    <label><span>هشدار مرجوعی (%)</span><input type="number" id="hgr-s-refund" min="0" step="0.1"></label>
                </div>
                <div class="hgr-panel-foot"><button type="button" class="hgr-btn hgr-btn-primary" id="hgr-save-settings">ذخیره تنظیمات تحلیل</button></div>
            </section>

            <section class="hgr-panel">
                <div class="hgr-panel-head"><div><h2>ظاهر و قالب سفارشی</h2><p>منطق گزارش از UI جداست؛ می‌توانی ظاهر را بدون تغییر موتور گزارش‌گیری عوض کنی.</p></div></div>
                <div class="hgr-settings-grid">
                    <label><span>تم داخلی</span><select id="hgr-theme-select"><option value="default" <?php selected( $theme, 'default' ); ?>>پیش‌فرض</option><option value="compact" <?php selected( $theme, 'compact' ); ?>>فشرده</option><option value="dark" <?php selected( $theme, 'dark' ); ?>>تیره</option></select></label>
                    <label class="hgr-filter-wide"><span>CSS سفارشی</span><textarea id="hgr-custom-css" rows="12" spellcheck="false" placeholder=".hgr-card { border-radius: 24px; }"><?php echo esc_textarea( $custom_css ); ?></textarea></label>
                </div>
                <div class="hgr-template-note"><strong>Template Override کامل:</strong><code>/wp-content/themes/YOUR-CHILD-THEME/haftghalam-reports/admin/app.php</code></div>
                <div class="hgr-panel-foot"><button type="button" class="hgr-btn hgr-btn-primary" id="hgr-save-ui">ذخیره ظاهر</button></div>
            </section>

            <section class="hgr-panel">
                <div class="hgr-panel-head"><div><h2>سلامت و تعمیر ایمن</h2><p>هیچ سفارش یا محصولی در این تست تغییر نمی‌کند.</p></div></div>
                <div id="hgr-health-inline" class="hgr-health-grid"></div>
                <div class="hgr-panel-foot"><button type="button" class="hgr-btn hgr-btn-ghost" id="hgr-run-health-inline">اجرای تست سلامت</button><button type="button" class="hgr-btn hgr-btn-ghost" id="hgr-repair-tables">بررسی/تعمیر جدول‌های داخلی</button></div>
            </section>
        </div>
    </template>
    <?php endif; ?>
</div>
