# Changelog

## 3.3.0 — Analytics-First + Data Health
- WooCommerce Analytics به مرجع پیش‌فرض KPI پایه تبدیل شد.
- در ارتقا از نسخه‌های قبل، Reference Policy یک‌بار به Analytics-First مهاجرت می‌کند.
- WooCommerce CRUD/WC_Order برای تحلیل‌های سفارشی و فیلترهای پیشرفته حفظ شد.
- Legacy Reports فقط نقش کنترل و تطبیق دارد.
- تب «سلامت داده» اضافه شد: Analytics ↔ CRUD روی همان date/status cohort، آخرین lookup، و اختلاف هر Status.
- KPIهای پایه فقط وقتی `canonical_kpi=true` می‌شوند که Analytics با Cohort خام تطبیق داشته باشد.
- اگر Analytics ناقص باشد، افزونه fallback را نشان می‌دهد اما آن را «تأییدشده» معرفی نمی‌کند.
- Snapshotهای امروز/دیروز/ماه هم از Sync Gate عبور می‌کنند تا عدد stale نمایش داده نشود.
- Export شامل پرچم `canonical_kpi` شد.

## 3.2.0 — Multi-Reference / Legacy Exact Fix

- رفع اختلاف بزرگ بین افزونه و صفحه کلاسیک `WooCommerce > Reports > Sales by date`.
- اضافه‌شدن `HGR_Legacy_Reference` که اعداد اصلی را مستقیماً از کلاس رسمی `WC_Report_Sales_By_Date` ووکامرس می‌خواند؛ فرمول کلاسیک دوباره از روی حدس بازنویسی نشده است.
- اضافه‌شدن تنظیم «مرجع اصلی KPI»: `Legacy Exact` یا `WooCommerce Analytics`.
- در نسخه 3.2 حالت Legacy Exact برای تطبیق با `wc-reports` اضافه شد؛ از 3.3 سیاست پیش‌فرض به Analytics-First تغییر کرده است.
- Legacy Exact از `date_created` و وضعیت‌های `completed / processing / on-hold / refunded` استفاده می‌کند؛ همان Cohort گزارش کلاسیک ووکامرس.
- WooCommerce Analytics همچنان به‌عنوان مرجع مدرن مستقل حفظ شده و date type / excluded statuses خودش را دارد.
- ممیزی KPI از دو منبع به سه منبع ارتقا یافت: Legacy Reports + Analytics + Independent CRUD Ledger.
- در ممیزی، اختلاف تعداد سفارش Legacy و Analytics صریحاً نمایش داده می‌شود.
- Gross در Legacy و Analytics به‌عنوان تعریف‌های متفاوت علامت‌گذاری می‌شود و اختلاف معنایی به‌اشتباه «خطای عددی» گزارش نمی‌شود.
- Health Check برای هر موتور، Cohort CRUD متناظر خودش را می‌سازد؛ دیگر Analytics با Cohort Legacy مقایسه نمی‌شود.
- Export ممیزی با ستون‌های سه‌منبعی به‌روزرسانی شد.
- مسیر High-volume برای هر دو مرجع فعال شد و در بازه‌های بزرگ از Hydrate کردن کل سفارش‌ها در داشبورد جلوگیری می‌شود.
- تنظیم دستی وضعیت فروش یا فیلترهای پیشرفته، Legacy Exact را عمداً غیرفعال می‌کند تا عدد «Exact» به‌صورت نادرست نمایش داده نشود.
- نسخه موتور و پیام‌های خطا به 3.2.0 به‌روزرسانی شد.

## 3.1.0 — Standard Audited KPI Engine

- Reference Layer مبتنی بر WooCommerce Analytics.
- Reconciliation با CRUD.
- Historical COGS coverage و Audit KPI.
