#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

find "$ROOT" -name '*.php' -not -path '*/tests/*' -print0 | xargs -0 -n1 php -l >/tmp/hgr-php-lint.txt
node --check "$ROOT/assets/js/admin.js"

if grep -RInE 'eval\s*\(|base64_decode\s*\(|shell_exec\s*\(|exec\s*\(|system\s*\(|passthru\s*\(' "$ROOT" --include='*.php' --include='*.js' | grep -v '/tests/' ; then
  echo 'Potential dangerous function found.' >&2
  exit 1
fi

if grep -RIn 'wp_ajax_nopriv' "$ROOT" --include='*.php' | grep -v '/tests/' ; then
  echo 'Public AJAX action found.' >&2
  exit 1
fi

if grep -RInE '\bwp_posts\b|\bwp_postmeta\b' "$ROOT/includes" --include='*.php' ; then
  echo 'Direct legacy order-table dependency found.' >&2
  exit 1
fi

grep -Eq "Version:[[:space:]]+3\.3\.0" "$ROOT/haftghalam-sales-insights.php"
grep -q "public static function audit" "$ROOT/includes/class-hgr-reports.php"
grep -q "WC_Report_Sales_By_Date" "$ROOT/includes/class-hgr-legacy-reference.php"
grep -q "financial_fallback_ledger" "$ROOT/includes/class-hgr-reports.php"
grep -q "_cogs_value" "$ROOT/includes/class-hgr-reports.php"
grep -q "'paged'" "$ROOT/includes/class-hgr-reports.php"
grep -q "data-report=\"audit\"" "$ROOT/templates/admin/app.php"

if grep -nE '#wpcontent|#wpbody|^[[:space:]]*:root' "$ROOT/assets/css/admin.css" ; then
  echo 'Unscoped WordPress admin CSS selector found.' >&2
  exit 1
fi

grep -q '\.hgr-wrap' "$ROOT/assets/css/admin.css"

# v3.3 Analytics-first trust layer
grep -q "analytics_sync_status" "$ROOT/includes/class-hgr-reference.php"
grep -q "public static function data_health" "$ROOT/includes/class-hgr-reports.php"
grep -q 'data-report="data_health"' "$ROOT/templates/admin/app.php"
grep -q "canonical_kpi" "$ROOT/includes/class-hgr-reports.php"
grep -q "'hgr_reference_mode'           => 'analytics'" "$ROOT/includes/class-hgr-plugin.php"

echo 'Static checks passed.'
