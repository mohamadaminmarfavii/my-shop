<?php
require_once dirname( __DIR__ ) . '/includes/class-hgr-jalali.php';
$cases = array(
    array( 2024, 3, 20, 1403, 1, 1 ),
    array( 2025, 3, 21, 1404, 1, 1 ),
    array( 2026, 9, 8, 1405, 6, 17 ),
);
$fail = 0;
foreach ( $cases as $c ) {
    list( $jy, $jm, $jd ) = HGR_Jalali::gregorian_to_jalali( $c[0], $c[1], $c[2] );
    $ok = $jy === $c[3] && $jm === $c[4] && $jd === $c[5];
    echo ( $ok ? 'PASS' : 'FAIL' ) . " G {$c[0]}-{$c[1]}-{$c[2]} => J {$jy}/{$jm}/{$jd}\n";
    if ( ! $ok ) $fail++;
    list( $gy, $gm, $gd ) = HGR_Jalali::jalali_to_gregorian( $c[3], $c[4], $c[5] );
    $ok2 = $gy === $c[0] && $gm === $c[1] && $gd === $c[2];
    echo ( $ok2 ? 'PASS' : 'FAIL' ) . " J {$c[3]}/{$c[4]}/{$c[5]} => G {$gy}-{$gm}-{$gd}\n";
    if ( ! $ok2 ) $fail++;
}
exit( $fail ? 1 : 0 );
