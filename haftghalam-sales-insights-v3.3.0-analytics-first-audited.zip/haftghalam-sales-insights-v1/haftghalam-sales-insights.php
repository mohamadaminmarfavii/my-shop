<?php
/**
 * Plugin Name: هفت‌قلم - مرکز تحلیل فروش و KPI ووکامرس
 * Plugin URI:  https://haftghalamstore.com
 * Description: مرکز تحلیل فروش، KPI، مشتری، محصول، موجودی، لغوها، کمپین‌ها و سود برای WooCommerce با پشتیبانی HPOS و تاریخ شمسی.
 * Version:     3.3.0
 * Author:      HaftGhalam
 * Text Domain: haftghalam-sales-insights
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * WC requires at least: 8.2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'HGR_VERSION', '3.3.0' );
define( 'HGR_FILE', __FILE__ );
define( 'HGR_PATH', plugin_dir_path( __FILE__ ) );
define( 'HGR_URL', plugin_dir_url( __FILE__ ) );

add_action( 'before_woocommerce_init', static function () {
    if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
} );

require_once HGR_PATH . 'includes/class-hgr-jalali.php';
require_once HGR_PATH . 'includes/class-hgr-order-collection.php';
require_once HGR_PATH . 'includes/class-hgr-theme.php';
require_once HGR_PATH . 'includes/class-hgr-tracker.php';
require_once HGR_PATH . 'includes/class-hgr-reference.php';
require_once HGR_PATH . 'includes/class-hgr-legacy-reference.php';
require_once HGR_PATH . 'includes/class-hgr-reports.php';
require_once HGR_PATH . 'includes/class-hgr-export.php';
require_once HGR_PATH . 'includes/class-hgr-health.php';
require_once HGR_PATH . 'includes/class-hgr-admin.php';
require_once HGR_PATH . 'includes/class-hgr-plugin.php';

register_activation_hook( __FILE__, array( 'HGR_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'HGR_Plugin', 'deactivate' ) );

HGR_Plugin::instance();
