=== هفت‌قلم - مرکز استاندارد تحلیل فروش و KPI ووکامرس ===
Version: 3.3.0
Requires WordPress: 6.4+
Requires PHP: 7.4+
Requires WooCommerce: 8.2+

افزونه مدیریتی گزارش فروش و KPI برای WooCommerce با تاریخ شمسی، فیلترهای دقیق، خروجی مدیریتی، ممیزی چندمنبعی و لایه مرجع قابل انتخاب.

سیاست استاندارد مرجع در نسخه 3.3:
1) WooCommerce Analytics — مرجع پیش‌فرض KPI پایه
   - برای معماری مدرن WooCommerce و HPOS/lookup tables.
   - از Orders Stats DataStore خود WooCommerce استفاده می‌کند.
   - date type و excluded statuses از تنظیمات Analytics تبعیت می‌کنند.
   - فقط وقتی Analytics با Cohort متناظر WC_Order/CRUD Sync باشد، KPI با برچسب «تأییدشده» نمایش داده می‌شود.

2) WooCommerce CRUD / WC_Order
   - منبع تحلیل‌های سفارشی، شهر، درگاه، مشتری، محصول، برند، لغو و فیلترهای دقیق.
   - اگر Analytics ناقص باشد، fallback تحلیلی می‌دهد ولی canonical_kpi=false می‌ماند.

3) WooCommerce Reports — Legacy Exact
   - فقط برای کنترل و تطبیق با صفحه قدیمی WooCommerce > Reports > Sales by date.
   - همان کلاس WC_Report_Sales_By_Date خود WooCommerce را اجرا می‌کند.
   - مبنا: date_created و وضعیت‌های completed / processing / on-hold / refunded.

4) Independent CRUD Ledger
   - موتور مستقل افزونه برای کنترل و گزارش‌های دارای فیلترهای پیشرفته.
   - مرجع مالی اصلی نیست، مگر اینکه مرجع انتخاب‌شده در دسترس نباشد.

تب «ممیزی KPI» هر سه مسیر را کنار هم نمایش می‌دهد تا اختلاف پنهان نماند.

امکانات:
- داشبورد KPI و مقایسه دوره‌ای
- فروش روزانه و ساعتی
- محصولات، دسته‌ها و برندها
- مشتریان، سگمنت، وفاداری و خرید مجدد
- لغو، Failed، دلیل لغو و قیف سفارش
- روش پرداخت و ارسال، شهر و استان
- کوپن و کمپین
- WooCommerce Order Attribution و دستگاه
- محصولات معمولاً خریداری‌شده باهم
- سود/COGS با اعلام Coverage
- موجودی، ناموجودی، بدون فروش و برآورد فروش ازدست‌رفته
- هشدارهای مدیریتی
- جستجو و فیلتر پیشرفته با تاریخ شمسی
- CSV UTF-8 و فایل Excel-readable XLS
- سلامت داده و Sync Gate
- ممیزی سه‌منبعی KPI
- Health Check برای Legacy Reports، Analytics، CRUD، HPOS، COGS، Attribution، Cron و PHP
- UI مستقل، CSS سفارشی و Template Override از Child Theme

نکته مهم فیلترها:
WooCommerce Legacy Exact فقط گزارش اصلی تاریخ‌محور کلاسیک را دقیقاً بازتولید می‌کند. فیلترهایی مثل روش پرداخت، شهر، برند، محصول و Source در Legacy report اصلی وجود ندارند؛ در این حالت افزونه عمداً از موتور CRUD فیلترشده استفاده می‌کند و در Meta گزارش، Reference Exact را خاموش نشان می‌دهد.

نکته HPOS:
مسیرهای مدرن افزونه از WooCommerce CRUD/Analytics استفاده می‌کنند. حالت Legacy Exact عمداً همان موتور قدیمی خود WooCommerce را فراخوانی می‌کند تا با wc-reports تطبیق عددی داشته باشد؛ بنابراین محدودیت‌های همان گزارش کلاسیک را نیز به ارث می‌برد.

امنیت:
- هیچ داده‌ای به سرویس خارجی ارسال نمی‌شود.
- AJAX عمومی nopriv وجود ندارد.
- گزارش‌ها به manage_woocommerce و تنظیمات به manage_options محدود هستند.
- Nonce روی درخواست‌های مدیریتی استفاده می‌شود.
- افزونه قیمت، موجودی یا وضعیت سفارش را بدون اقدام صریح مدیر تغییر نمی‌دهد.
