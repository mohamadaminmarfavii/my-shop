# نصب و ارتقا — HaftGhalam Sales Insights 3.3.0

1. از سایت و دیتابیس Backup بگیر.
2. ZIP نسخه 3.3.0 را از «افزونه‌ها → افزودن → بارگذاری افزونه» نصب کن.
3. چون پوشه افزونه همان شناسه قبلی را دارد، گزینه «جایگزینی نسخه فعلی» را انتخاب کن.
4. برو به «تحلیل فروش → تنظیمات / ظاهر».
5. برای سایتی که مرجع مقایسه‌اش صفحه `WooCommerce > Reports` است، گزینه «WooCommerce Reports — Legacy Exact» را انتخاب کن.
6. وضعیت‌های فروش را خالی بگذار؛ Override دستی باعث می‌شود Legacy Exact دیگر قابل تضمین نباشد.
7. Cache افزونه را پاک کن و یک بار صفحه را Refresh کن.
8. تب «ممیزی KPI» را روی همان بازه‌ای که در WooCommerce Reports باز کرده‌ای اجرا کن.

## تست پیشنهادی بعد از نصب

برای همان بازه دقیق، این اعداد را مقایسه کن:
- Orders
- Items
- Net Sales
- Total/Gross Sales کلاسیک
- Refunds
- Shipping
- Coupons

در Legacy Exact، Orders / Items / Net / Total باید با صفحه کلاسیک WooCommerce هم‌راستا باشند، چون منبع هر دو همان `WC_Report_Sales_By_Date` است.

## چه زمانی Analytics را انتخاب کنم؟

اگر مبنای مدیریتی شما «Analytics → Revenue / Orders» است و HPOS/lookup tables به‌درستی Sync هستند، مرجع اصلی را روی WooCommerce Analytics بگذار. در آن حالت افزونه همان DataStore تحلیلی WooCommerce را مرجع می‌گیرد.


## سیاست مرجع نهایی v3.3
1. WooCommerce Analytics = مرجع KPI پایه، فقط پس از تکمیل Historical Import/Sync.
2. WC_Order / wc_get_orders = تحلیل سفارشی و فیلترهای دقیق.
3. WooCommerce Legacy Reports = کنترل و مقایسه، نه مرجع اصلی آینده.
4. بعد از نصب، تب «سلامت داده» را روی ۷ و ۳۰ روز اجرا کن؛ وضعیت باید «آماده و Sync» باشد.
