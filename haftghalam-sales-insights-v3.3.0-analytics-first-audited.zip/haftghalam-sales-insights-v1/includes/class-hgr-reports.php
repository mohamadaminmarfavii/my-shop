<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class HGR_Reports {
    const CACHE_TTL = 600;
    const MAX_ORDERS = 200000;

    public static function bump_cache_version() {
        update_option( 'hgr_cache_version', (string) microtime( true ), false );
    }

    private static function cache_key( $type, $start, $end, $filters = array() ) {
        $version = get_option( 'hgr_cache_version', '1' );
        return 'hgr2_' . md5( HGR_VERSION . '|' . $version . '|' . $type . '|' . $start . '|' . $end . '|' . wp_json_encode( $filters ) );
    }

    private static function get_cached( $type, $start, $end, $filters = array() ) {
        return get_transient( self::cache_key( $type, $start, $end, $filters ) );
    }

    private static function set_cached( $type, $start, $end, $filters, $value ) {
        set_transient( self::cache_key( $type, $start, $end, $filters ), $value, self::CACHE_TTL );
        return $value;
    }

    public static function sanitize_filters( $raw ) {
        if ( is_string( $raw ) ) {
            $decoded = json_decode( wp_unslash( $raw ), true );
            $raw = is_array( $decoded ) ? $decoded : array();
        }
        if ( ! is_array( $raw ) ) {
            $raw = array();
        }
        $filters = array();
        $array_keys = array( 'statuses', 'payment_methods', 'shipping_methods' );
        foreach ( $array_keys as $key ) {
            if ( isset( $raw[ $key ] ) && is_array( $raw[ $key ] ) ) {
                $filters[ $key ] = array_values( array_filter( array_map( 'sanitize_key', $raw[ $key ] ) ) );
            }
        }
        $text_keys = array( 'city', 'state', 'coupon', 'source', 'device', 'customer_segment', 'search' );
        foreach ( $text_keys as $key ) {
            if ( isset( $raw[ $key ] ) && '' !== $raw[ $key ] ) {
                $filters[ $key ] = sanitize_text_field( wp_unslash( $raw[ $key ] ) );
            }
        }
        foreach ( array( 'product_id', 'category_id', 'brand_term_id' ) as $key ) {
            if ( ! empty( $raw[ $key ] ) ) {
                $filters[ $key ] = absint( $raw[ $key ] );
            }
        }
        foreach ( array( 'min_total', 'max_total' ) as $key ) {
            if ( isset( $raw[ $key ] ) && '' !== $raw[ $key ] && is_numeric( $raw[ $key ] ) ) {
                $filters[ $key ] = (float) $raw[ $key ];
            }
        }
        if ( isset( $raw['compare'] ) ) {
            $compare = sanitize_key( $raw['compare'] );
            $filters['compare'] = in_array( $compare, array( 'previous_period', 'previous_jmonth', 'previous_month', 'last_year', 'none' ), true ) ? $compare : 'previous_period';
        }
        return $filters;
    }

    public static function normalize_range( $start, $end ) {
        $today = current_time( 'Y-m-d' );
        $start = self::valid_date( $start ) ? $start : gmdate( 'Y-m-d', strtotime( $today . ' -29 days' ) );
        $end   = self::valid_date( $end ) ? $end : $today;
        if ( $start > $end ) {
            $tmp = $start;
            $start = $end;
            $end = $tmp;
        }
        return array( $start, $end );
    }

    private static function valid_date( $date ) {
        if ( ! is_string( $date ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
            return false;
        }
        $d = DateTime::createFromFormat( 'Y-m-d', $date );
        return $d && $d->format( 'Y-m-d' ) === $date;
    }

    private static function range_timestamps( $start, $end ) {
        $tz = wp_timezone();
        $s = new DateTimeImmutable( $start . ' 00:00:00', $tz );
        $e = new DateTimeImmutable( $end . ' 23:59:59', $tz );
        return array( $s->getTimestamp(), $e->getTimestamp() );
    }

    /**
     * Sales statuses used by the reporting engine.
     *
     * Some stores move paid orders into custom statuses (for example shipped,
     * delivered, packed, etc.). WooCommerce's wc_get_is_paid_statuses() does
     * not necessarily include those custom statuses, which can make a valid
     * store look like it has zero sales. We therefore start with WooCommerce's
     * official paid statuses and safely auto-detect custom statuses whose recent
     * orders have a paid date. The result is cached for six hours.
     */
    private static function paid_statuses() {
        // v3: Never guess which statuses are revenue. Use WooCommerce Analytics
        // configuration by default; an administrator may explicitly override it.
        return HGR_Reference::included_statuses();
    }

    /**
     * If a store has real orders but none match the normal paid statuses, use a
     * conservative recovery pass. This is only used when the primary sales query
     * returns zero rows. It accepts orders that have an explicit paid date, or
     * are in a custom non-failure status and have a non-zero total plus either a
     * transaction id or a known payment method. This prevents a custom workflow
     * from blanking the whole dashboard while still excluding pending/failed/etc.
     */
    private static function is_recovery_sale_order( WC_Order $order ) {
        // v3 intentionally disables heuristic revenue recovery. A guessed sale
        // status is unacceptable for KPI reconciliation.
        return in_array( $order->get_status(), self::paid_statuses(), true );
    }

    public static function sales_statuses_for_diagnostics() {
        return self::paid_statuses();
    }

    private static function all_statuses() {
        $keys = array_keys( wc_get_order_statuses() );
        return array_map( static function ( $s ) { return str_replace( 'wc-', '', $s ); }, $keys );
    }

    private static function failed_statuses() {
        return array( 'cancelled', 'failed' );
    }

    public static function brand_taxonomy() {
        $saved = sanitize_key( (string) get_option( 'hgr_brand_taxonomy', '' ) );
        if ( $saved && taxonomy_exists( $saved ) ) {
            return $saved;
        }
        foreach ( array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'pa_brand', 'product_brands' ) as $tax ) {
            if ( taxonomy_exists( $tax ) ) {
                return $tax;
            }
        }
        return '';
    }

    /**
     * Query matching order IDs in bounded batches and hydrate lazily later.
     *
     * v2.0 retained every WC_Order object in RAM. On a busy store a 30-day
     * report could therefore exhaust PHP memory before any JSON was returned.
     * This implementation stores only integer IDs and only hydrates orders when
     * a report actually iterates them.
     */
    private static function query_orders( $start, $end, $statuses, $filters = array(), $max = self::MAX_ORDERS, $date_basis = 'auto' ) {
        static $request_cache = array();

        $statuses = is_array( $statuses ) ? array_values( $statuses ) : array( $statuses );
        $cache_filters = $filters;
        unset( $cache_filters['compare'], $cache_filters['customer_segment'] );
        $resolved_date_key = self::resolve_query_date_key( $statuses, $date_basis );
        $request_key = md5( wp_json_encode( array( $start, $end, $statuses, $cache_filters, (int) $max, $resolved_date_key ) ) );
        if ( isset( $request_cache[ $request_key ] ) ) {
            return $request_cache[ $request_key ];
        }

        $ids = array();
        $page = 1;
        $per = 500;
        $truncated = false;
        $native_payment = ! empty( $filters['payment_methods'] ) && 1 === count( $filters['payment_methods'] );
        $needs_object_filter = self::needs_object_filter( $filters, $native_payment );
        $date_key = $resolved_date_key;

        do {
            $args = array(
                'status'   => $statuses,
                'limit'    => $per,
                'paged'    => $page,
                'paginate' => true,
                'orderby'  => 'date',
                'order'    => 'DESC',
                'return'   => 'ids',
            );
            $args[ $date_key ] = $start . '...' . $end;
            if ( $native_payment ) {
                $args['payment_method'] = reset( $filters['payment_methods'] );
            }

            $result = wc_get_orders( $args );
            if ( ! is_object( $result ) || empty( $result->orders ) ) {
                break;
            }
            foreach ( $result->orders as $order_id ) {
                $order_id = absint( $order_id );
                if ( ! $order_id ) continue;
                if ( $needs_object_filter ) {
                    $order = wc_get_order( $order_id );
                    if ( ! $order instanceof WC_Order || ! self::order_matches_filters( $order, $filters ) ) {
                        unset( $order );
                        continue;
                    }
                    unset( $order );
                }
                $ids[] = $order_id;
                if ( count( $ids ) >= $max ) {
                    $truncated = true;
                    break 2;
                }
            }
            $page++;
        } while ( $page <= (int) $result->max_num_pages );

        $payload = array(
            'orders'         => new HGR_Order_Collection( $ids ),
            'ids'            => $ids,
            'truncated'      => $truncated,
            'recovery_used'  => false,
            'query_statuses' => $statuses,
            'date_type'      => $date_key,
        );
        $request_cache[ $request_key ] = $payload;
        return $payload;
    }

    private static function same_status_set( $a, $b ) {
        $a = array_values( array_unique( array_map( 'sanitize_key', (array) $a ) ) );
        $b = array_values( array_unique( array_map( 'sanitize_key', (array) $b ) ) );
        sort( $a );
        sort( $b );
        return $a === $b;
    }

    private static function query_recovery_sales_ids( $start, $end, $filters, $max ) {
        return array( 'ids' => array(), 'truncated' => false );
    }

    private static function needs_object_filter( $filters, $native_payment = false ) {
        $keys = array( 'shipping_methods', 'city', 'state', 'coupon', 'source', 'device', 'product_id', 'category_id', 'brand_term_id', 'min_total', 'max_total', 'search' );
        if ( ! $native_payment && ! empty( $filters['payment_methods'] ) ) {
            return true;
        }
        if ( ! empty( $filters['statuses'] ) ) {
            // Statuses are already constrained by the report's status query; an
            // explicit user subset still needs matching when it is narrower.
            return true;
        }
        foreach ( $keys as $key ) {
            if ( isset( $filters[ $key ] ) && '' !== $filters[ $key ] && array() !== $filters[ $key ] ) {
                return true;
            }
        }
        return false;
    }




    private static function order_query_date_key() {
        $type = HGR_Reference::date_type();
        return in_array( $type, array( 'date_created', 'date_paid', 'date_completed' ), true ) ? $type : 'date_created';
    }

    /**
     * Revenue reports follow WooCommerce Analytics' configured date basis.
     * Failed/cancelled/all-status operational cohorts must use creation date;
     * those orders commonly have no paid/completed timestamp at all.
     */
    private static function resolve_query_date_key( $statuses, $date_basis = 'auto' ) {
        if ( in_array( $date_basis, array( 'date_created', 'date_paid', 'date_completed' ), true ) ) {
            return $date_basis;
        }
        $statuses = array_values( array_unique( array_map( static function ( $s ) {
            return str_replace( 'wc-', '', sanitize_key( $s ) );
        }, (array) $statuses ) ) );
        if ( $statuses && 0 === count( array_diff( $statuses, self::failed_statuses() ) ) ) {
            return 'date_created';
        }
        return self::order_query_date_key();
    }

    private static function order_report_date( WC_Order $order ) {
        $type = HGR_Reference::date_type();
        if ( 'date_paid' === $type ) return $order->get_date_paid();
        if ( 'date_completed' === $type ) return $order->get_date_completed();
        return $order->get_date_created();
    }

    private static function lower( $text ) {
        return function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $text, 'UTF-8' ) : strtolower( (string) $text );
    }

    private static function ipos( $haystack, $needle ) {
        if ( function_exists( 'mb_stripos' ) ) return mb_stripos( (string) $haystack, (string) $needle, 0, 'UTF-8' );
        return stripos( (string) $haystack, (string) $needle );
    }

    private static function order_matches_filters( WC_Order $order, $filters ) {
        if ( ! empty( $filters['statuses'] ) && ! in_array( $order->get_status(), $filters['statuses'], true ) ) {
            return false;
        }
        if ( ! empty( $filters['payment_methods'] ) && ! in_array( $order->get_payment_method(), $filters['payment_methods'], true ) ) {
            return false;
        }
        if ( ! empty( $filters['shipping_methods'] ) ) {
            $found = false;
            foreach ( $order->get_items( 'shipping' ) as $shipping ) {
                $method_id = method_exists( $shipping, 'get_method_id' ) ? $shipping->get_method_id() : '';
                $instance_id = method_exists( $shipping, 'get_instance_id' ) ? $shipping->get_instance_id() : 0;
                $compound = $instance_id ? $method_id . ':' . $instance_id : $method_id;
                if ( in_array( $method_id, $filters['shipping_methods'], true ) || in_array( $compound, $filters['shipping_methods'], true ) ) {
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                return false;
            }
        }
        $total = (float) $order->get_total();
        if ( isset( $filters['min_total'] ) && $total < (float) $filters['min_total'] ) {
            return false;
        }
        if ( isset( $filters['max_total'] ) && $total > (float) $filters['max_total'] ) {
            return false;
        }
        if ( ! empty( $filters['city'] ) && false === self::ipos( (string) $order->get_billing_city(), $filters['city'] ) ) {
            return false;
        }
        if ( ! empty( $filters['state'] ) && (string) $order->get_billing_state() !== (string) $filters['state'] ) {
            return false;
        }
        if ( ! empty( $filters['coupon'] ) ) {
            $codes = array_map( 'strtolower', $order->get_coupon_codes() );
            if ( ! in_array( strtolower( $filters['coupon'] ), $codes, true ) ) {
                return false;
            }
        }
        if ( ! empty( $filters['source'] ) ) {
            $source = strtolower( self::attribution_source( $order ) );
            if ( false === strpos( $source, strtolower( $filters['source'] ) ) ) {
                return false;
            }
        }
        if ( ! empty( $filters['device'] ) ) {
            $device = strtolower( self::attribution_device( $order ) );
            if ( strtolower( $filters['device'] ) !== $device ) {
                return false;
            }
        }
        if ( ! empty( $filters['product_id'] ) || ! empty( $filters['category_id'] ) || ! empty( $filters['brand_term_id'] ) ) {
            $brand_tax = self::brand_taxonomy();
            $product_ok = empty( $filters['product_id'] );
            $category_ok = empty( $filters['category_id'] );
            $brand_ok = empty( $filters['brand_term_id'] );
            foreach ( $order->get_items( 'line_item' ) as $item ) {
                $product_id = $item->get_variation_id() ?: $item->get_product_id();
                $parent_id  = $item->get_product_id();
                if ( ! $product_ok && ( (int) $product_id === (int) $filters['product_id'] || (int) $parent_id === (int) $filters['product_id'] ) ) $product_ok = true;
                if ( ! $category_ok && has_term( (int) $filters['category_id'], 'product_cat', $parent_id ) ) $category_ok = true;
                if ( ! $brand_ok && $brand_tax && has_term( (int) $filters['brand_term_id'], $brand_tax, $parent_id ) ) $brand_ok = true;
                if ( $product_ok && $category_ok && $brand_ok ) break;
            }
            if ( ! ( $product_ok && $category_ok && $brand_ok ) ) return false;
        }
        if ( ! empty( $filters['search'] ) ) {
            $needle = self::lower( $filters['search'] );
            $hay = self::lower( implode( ' ', array(
                $order->get_order_number(),
                $order->get_formatted_billing_full_name(),
                $order->get_billing_phone(),
                $order->get_billing_email(),
                $order->get_billing_city(),
            ) ) );
            if ( false === strpos( $hay, $needle ) ) {
                return false;
            }
        }
        return true;
    }

    private static function customer_key( WC_Order $order ) {
        // Stable resolver: registered account first, then normalized email, then phone.
        // The same priority is used by lifetime_customer_map() to avoid new/repeat mismatches.
        $uid = absint( $order->get_customer_id() );
        $email = strtolower( trim( (string) $order->get_billing_email() ) );
        $phone = preg_replace( '/\D+/', '', (string) $order->get_billing_phone() );
        if ( $uid ) return 'u:' . $uid;
        if ( $email ) return 'e:' . $email;
        if ( $phone ) return 'p:' . $phone;
        return 'o:' . $order->get_id();
    }

    private static function customer_name( WC_Order $order ) {
        $name = trim( $order->get_formatted_billing_full_name() );
        return $name ? $name : 'مهمان';
    }

    private static function city_data( WC_Order $order ) {
        $city = trim( (string) $order->get_billing_city() );
        $state = trim( (string) $order->get_billing_state() );
        $country = trim( (string) $order->get_billing_country() );
        $state_name = $state;
        if ( $country && isset( WC()->countries->states[ $country ][ $state ] ) ) {
            $state_name = WC()->countries->states[ $country ][ $state ];
        }
        return array( 'city' => $city ?: 'نامشخص', 'state' => $state_name ?: 'نامشخص', 'state_code' => $state );
    }

    private static function order_net( WC_Order $order ) {
        return (float) $order->get_total() - (float) $order->get_total_tax() - (float) $order->get_shipping_total();
    }

    private static function order_item_qty( WC_Order $order ) {
        $qty = 0;
        foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
            $qty += max( 0, (float) $item->get_quantity() + (float) $order->get_qty_refunded_for_item( $item_id ) );
        }
        return $qty;
    }

    private static function shipping_method( WC_Order $order ) {
        $titles = array();
        foreach ( $order->get_items( 'shipping' ) as $item ) {
            $title = method_exists( $item, 'get_method_title' ) ? $item->get_method_title() : $item->get_name();
            if ( $title ) $titles[] = $title;
        }
        return $titles ? implode( ' + ', array_unique( $titles ) ) : 'بدون روش ارسال';
    }

    private static function attribution_source( WC_Order $order ) {
        foreach ( array( '_wc_order_attribution_utm_source', '_wc_order_attribution_source_type', '_wc_order_attribution_referrer' ) as $key ) {
            $v = trim( (string) $order->get_meta( $key, true ) );
            if ( $v ) {
                if ( '_wc_order_attribution_referrer' === $key ) {
                    $host = wp_parse_url( $v, PHP_URL_HOST );
                    return $host ? $host : $v;
                }
                return $v;
            }
        }
        return 'Direct / Unknown';
    }

    private static function attribution_device( WC_Order $order ) {
        $device = trim( (string) $order->get_meta( '_wc_order_attribution_device_type', true ) );
        if ( $device ) return strtolower( $device );
        $ua = strtolower( (string) $order->get_meta( '_wc_order_attribution_user_agent', true ) );
        if ( false !== strpos( $ua, 'mobile' ) ) return 'mobile';
        if ( false !== strpos( $ua, 'tablet' ) || false !== strpos( $ua, 'ipad' ) ) return 'tablet';
        return $ua ? 'desktop' : 'unknown';
    }

    private static function primary_category( $product_id ) {
        $primary_id = absint( get_post_meta( $product_id, '_yoast_wpseo_primary_product_cat', true ) );
        if ( $primary_id ) {
            $term = get_term( $primary_id, 'product_cat' );
            if ( $term && ! is_wp_error( $term ) ) return $term;
        }
        $terms = get_the_terms( $product_id, 'product_cat' );
        if ( ! $terms || is_wp_error( $terms ) ) return null;
        usort( $terms, static function ( $a, $b ) {
            return count( get_ancestors( $b->term_id, 'product_cat', 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat', 'taxonomy' ) );
        } );
        return reset( $terms );
    }

    private static function product_brand( $product_id ) {
        $tax = self::brand_taxonomy();
        if ( ! $tax ) return null;
        $terms = get_the_terms( $product_id, $tax );
        if ( ! $terms || is_wp_error( $terms ) ) return null;
        return reset( $terms );
    }

    private static function native_cogs_enabled() {
        try {
            if ( function_exists( 'wc_get_container' ) && class_exists( '\\Automattic\\WooCommerce\\Internal\\Features\\FeaturesController' ) ) {
                $controller = wc_get_container()->get( \Automattic\WooCommerce\Internal\Features\FeaturesController::class );
                if ( is_object( $controller ) && method_exists( $controller, 'feature_is_enabled' ) ) {
                    return (bool) $controller->feature_is_enabled( 'cost_of_goods_sold' );
                }
            }
        } catch ( Throwable $e ) {
            return false;
        }
        return false;
    }

    private static function product_cost( $product ) {
        if ( ! $product instanceof WC_Product ) return null;
        if ( self::native_cogs_enabled() ) {
            // get_cogs_total_value() includes parent + variation COGS where WooCommerce supports it.
            foreach ( array( 'get_cogs_total_value', 'get_cogs_value' ) as $method ) {
                if ( method_exists( $product, $method ) ) {
                    try {
                        $v = $product->{$method}();
                        if ( null !== $v && '' !== $v && is_numeric( $v ) ) return (float) $v;
                    } catch ( Throwable $e ) {}
                }
            }
        }
        $key = trim( (string) get_option( 'hgr_cost_meta_key', '' ) );
        $keys = $key ? array( $key ) : array( '_wc_cog_cost', '_purchase_price', '_cost', 'purchase_price' );
        foreach ( $keys as $meta_key ) {
            $v = get_post_meta( $product->get_id(), $meta_key, true );
            if ( '' !== $v && is_numeric( $v ) ) return (float) $v;
        }
        if ( $product->is_type( 'variation' ) ) {
            $parent = wc_get_product( $product->get_parent_id() );
            if ( $parent ) {
                if ( self::native_cogs_enabled() ) {
                    foreach ( array( 'get_cogs_total_value', 'get_cogs_value' ) as $method ) {
                        if ( method_exists( $parent, $method ) ) {
                            try {
                                $v = $parent->{$method}();
                                if ( null !== $v && '' !== $v && is_numeric( $v ) ) return (float) $v;
                            } catch ( Throwable $e ) {}
                        }
                    }
                }
                foreach ( $keys as $meta_key ) {
                    $v = get_post_meta( $parent->get_id(), $meta_key, true );
                    if ( '' !== $v && is_numeric( $v ) ) return (float) $v;
                }
            }
        }
        return null;
    }

    private static function order_item_cost( $item, $product = null ) {
        // WooCommerce stores historical COGS on the order item in _cogs_value.
        // get_cogs_value() alone is not enough for coverage detection because it can
        // return numeric zero when COGS is disabled/missing. Metadata presence is the
        // conservative proof that historical cost was actually persisted.
        if ( is_object( $item ) && method_exists( $item, 'get_meta' ) ) {
            $stored = $item->get_meta( '_cogs_value', true );
            if ( '' !== $stored && null !== $stored && is_numeric( $stored ) ) {
                return array( 'cost'=>(float) $stored, 'exact'=>true, 'source'=>'order_item_cogs_meta' );
            }
        }
        $qty = is_object( $item ) && method_exists( $item, 'get_quantity' ) ? max( 0, (float) $item->get_quantity() ) : 0;
        $unit = self::product_cost( $product );
        if ( null !== $unit && $qty > 0 ) {
            return array( 'cost'=>(float) $unit * $qty, 'exact'=>false, 'source'=>'current_product_cost_fallback' );
        }
        return array( 'cost'=>null, 'exact'=>false, 'source'=>'missing' );
    }

    private static function attempt_metrics( $start, $end, $filters = array() ) {
        // Cancellation/failure are order-attempt metrics and always use creation date.
        $statuses = self::all_statuses();
        $ids = array();
        $page = 1;
        $per = 500;
        $max = self::MAX_ORDERS;
        $truncated = false;
        do {
            $args = array(
                'status' => $statuses, 'date_created' => $start . '...' . $end,
                'limit' => $per, 'paged' => $page, 'paginate' => true, 'return' => 'ids',
                'orderby' => 'date', 'order' => 'DESC',
            );
            $result = wc_get_orders( $args );
            if ( ! is_object( $result ) || empty( $result->orders ) ) break;
            foreach ( $result->orders as $id ) {
                $order = wc_get_order( absint( $id ) );
                if ( ! $order instanceof WC_Order ) continue;
                if ( ! self::order_matches_filters( $order, $filters ) ) continue;
                $ids[] = $order->get_id();
                if ( count( $ids ) >= $max ) { $truncated = true; break 2; }
            }
            $page++;
        } while ( $page <= (int) $result->max_num_pages );
        $cancelled = $failed = $attempts = 0; $lost = 0.0;
        foreach ( $ids as $id ) {
            $order = wc_get_order( $id );
            if ( ! $order instanceof WC_Order ) continue;
            $status = $order->get_status();
            if ( in_array( $status, array( 'checkout-draft', 'trash' ), true ) ) continue;
            $attempts++;
            if ( 'cancelled' === $status ) { $cancelled++; $lost += (float) $order->get_total(); }
            if ( 'failed' === $status ) { $failed++; $lost += (float) $order->get_total(); }
        }
        return array(
            'attempts' => $attempts, 'cancelled' => $cancelled, 'failed' => $failed, 'lost_value' => $lost,
            'cancel_rate' => $attempts ? 100 * $cancelled / $attempts : 0,
            'failed_rate' => $attempts ? 100 * $failed / $attempts : 0,
            'truncated' => $truncated,
        );
    }

    /**
     * Refund-event ledger for filtered KPI fallbacks.
     *
     * WooCommerce Analytics books returns on the refund event date. When a
     * filter cannot be delegated to the Analytics DataStore, this helper keeps
     * that temporal behavior instead of subtracting every historical refund
     * from the parent order's original sale date.
     */
    private static function refund_metrics( $start, $end, $filters = array(), $prefer_analytics = true ) {
        global $wpdb;
        $ids = array();
        $truncated = false;
        $stats_table = $wpdb->prefix . 'wc_order_stats';
        $stats_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stats_table ) ) === $stats_table;
        // Refunds are event-ledger entries: always book them on the refund's
        // creation date, independently from the parent order's sales date basis.
        $date_col = 'date_created';

        if ( $stats_exists && $prefer_analytics ) {
            $start_dt = $start . ' 00:00:00';
            $end_dt = $end . ' 23:59:59';
            // Refund rows in wc_order_stats are parent_id > 0. WooCommerce
            // synchronizes their report dates to the refund creation event.
            $sql = "SELECT order_id FROM {$stats_table} WHERE parent_id > 0 AND `{$date_col}` BETWEEN %s AND %s ORDER BY `{$date_col}` ASC LIMIT %d";
            $rows = $wpdb->get_col( $wpdb->prepare( $sql, $start_dt, $end_dt, self::MAX_ORDERS + 1 ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( count( $rows ) > self::MAX_ORDERS ) {
                $truncated = true;
                $rows = array_slice( $rows, 0, self::MAX_ORDERS );
            }
            $ids = array_map( 'absint', $rows );
        } else {
            // Portable fallback. Refund objects are always dated by creation.
            $page = 1; $per = 500;
            do {
                $result = wc_get_orders( array(
                    'type' => 'shop_order_refund',
                    'date_created' => $start . '...' . $end,
                    'limit' => $per,
                    'paged' => $page,
                    'paginate' => true,
                    'return' => 'ids',
                    'orderby' => 'date',
                    'order' => 'ASC',
                ) );
                if ( ! is_object( $result ) || empty( $result->orders ) ) break;
                foreach ( $result->orders as $id ) {
                    $ids[] = absint( $id );
                    if ( count( $ids ) >= self::MAX_ORDERS ) { $truncated = true; break 2; }
                }
                $page++;
            } while ( $page <= (int) $result->max_num_pages );
        }

        $returns = 0.0;
        $taxes = 0.0;
        $shipping = 0.0;
        $items = 0.0;
        $parents = array();
        $daily = array();
        foreach ( $ids as $id ) {
            $refund = wc_get_order( $id );
            if ( ! $refund instanceof WC_Order_Refund ) continue;
            $parent = wc_get_order( $refund->get_parent_id() );
            if ( ! $parent instanceof WC_Order ) continue;
            if ( ! self::order_matches_filters( $parent, $filters ) ) continue;

            $parents[ $parent->get_id() ] = true;
            $refund_tax = abs( (float) $refund->get_total_tax() );
            $refund_shipping = abs( (float) $refund->get_shipping_total() );
            $taxes += $refund_tax;
            $shipping += $refund_shipping;

            $line_return = 0.0;
            $line_qty = 0.0;
            foreach ( $refund->get_items( 'line_item' ) as $item ) {
                $line_return += abs( (float) $item->get_total() );
                $line_qty += abs( (float) $item->get_quantity() );
            }
            // Manual refunds can have no line items. In that case derive the
            // merchandise/fee return from the refund total excluding tax/ship.
            if ( $line_return <= 0 ) {
                $line_return = max( 0, abs( (float) $refund->get_total() ) - abs( (float) $refund->get_total_tax() ) - abs( (float) $refund->get_shipping_total() ) );
            }
            $returns += $line_return;
            $items += $line_qty;
            $rd = $refund->get_date_created();
            $day_key = $rd ? $rd->date_i18n( 'Y-m-d' ) : '';
            if ( $day_key ) {
                if ( ! isset( $daily[ $day_key ] ) ) {
                    $daily[ $day_key ] = array( 'returns'=>0.0, 'taxes'=>0.0, 'shipping'=>0.0, 'items'=>0.0, 'parents'=>array() );
                }
                $daily[ $day_key ]['returns'] += $line_return;
                $daily[ $day_key ]['taxes'] += $refund_tax;
                $daily[ $day_key ]['shipping'] += $refund_shipping;
                $daily[ $day_key ]['items'] += $line_qty;
                $daily[ $day_key ]['parents'][ $parent->get_id() ] = true;
            }
        }
        foreach ( $daily as &$dr ) {
            $dr['refund_orders'] = count( $dr['parents'] );
            unset( $dr['parents'] );
        }
        unset( $dr );

        return array(
            'returns' => $returns,
            'taxes' => $taxes,
            'shipping' => $shipping,
            'items' => $items,
            'refund_orders' => count( $parents ),
            'daily' => $daily,
            'truncated' => $truncated,
            'source' => ( $stats_exists && $prefer_analytics ) ? 'wc_order_stats_refund_events' : 'woocommerce_refund_crud',
        );
    }

    /**
     * Period gross-profit ledger using historical order-item COGS when present.
     * Parent sale events follow the Analytics date basis; refund events are
     * booked on the refund date and restore the refunded item's historical COGS.
     */
    private static function profit_metrics( $start, $end, $filters = array(), $prefer_analytics = true ) {
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $merch_revenue = 0.0;
        $net_cogs = 0.0;
        $coverage_base = 0.0;
        $coverage_known = 0.0;
        $coverage_historical = 0.0;

        foreach ( $q['orders'] as $order ) {
            foreach ( $order->get_items( 'line_item' ) as $item ) {
                $revenue = max( 0, (float) $item->get_total() );
                $merch_revenue += $revenue;
                $coverage_base += abs( $revenue );
                $ci = self::order_item_cost( $item, $item->get_product() );
                if ( null !== $ci['cost'] ) {
                    $net_cogs += (float) $ci['cost'];
                    $coverage_known += abs( $revenue );
                    if ( ! empty( $ci['exact'] ) ) $coverage_historical += abs( $revenue );
                }
            }
        }

        // Refund event IDs are read from wc_order_stats where available because
        // that is the same reporting ledger WooCommerce Analytics uses.
        global $wpdb;
        $stats_table = $wpdb->prefix . 'wc_order_stats';
        $stats_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stats_table ) ) === $stats_table;
        $refund_ids = array();
        $refund_truncated = false;
        if ( $stats_exists && $prefer_analytics ) {
            $date_col = 'date_created';
            $sql = "SELECT order_id FROM {$stats_table} WHERE parent_id > 0 AND `{$date_col}` BETWEEN %s AND %s ORDER BY `{$date_col}` ASC LIMIT %d";
            $refund_ids = $wpdb->get_col( $wpdb->prepare( $sql, $start . ' 00:00:00', $end . ' 23:59:59', self::MAX_ORDERS + 1 ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( count( $refund_ids ) > self::MAX_ORDERS ) {
                $refund_ids = array_slice( $refund_ids, 0, self::MAX_ORDERS );
                $refund_truncated = true;
            }
        } else {
            $page = 1; $per = 500;
            do {
                $r = wc_get_orders( array( 'type'=>'shop_order_refund', 'date_created'=>$start.'...'.$end, 'limit'=>$per, 'paged'=>$page, 'paginate'=>true, 'return'=>'ids', 'orderby'=>'date', 'order'=>'ASC' ) );
                if ( ! is_object( $r ) || empty( $r->orders ) ) break;
                foreach ( $r->orders as $rid ) {
                    $refund_ids[] = absint( $rid );
                    if ( count( $refund_ids ) >= self::MAX_ORDERS ) { $refund_truncated = true; break 2; }
                }
                $page++;
            } while ( $page <= (int) $r->max_num_pages );
        }

        foreach ( $refund_ids as $rid ) {
            $refund = wc_get_order( absint( $rid ) );
            if ( ! $refund instanceof WC_Order_Refund ) continue;
            $parent = wc_get_order( $refund->get_parent_id() );
            if ( ! $parent instanceof WC_Order || ! self::order_matches_filters( $parent, $filters ) ) continue;

            $had_line = false;
            foreach ( $refund->get_items( 'line_item' ) as $refund_item ) {
                $had_line = true;
                $return_revenue = abs( (float) $refund_item->get_total() );
                $merch_revenue -= $return_revenue;
                $coverage_base += abs( $return_revenue );

                $refund_cost = null;
                $historical = false;
                if ( method_exists( $refund_item, 'get_meta' ) ) {
                    $rv = $refund_item->get_meta( '_cogs_value', true );
                    if ( '' !== $rv && null !== $rv && is_numeric( $rv ) ) {
                        $refund_cost = abs( (float) $rv );
                        $historical = true;
                    }
                }
                if ( null === $refund_cost ) {
                    $original_item_id = absint( $refund_item->get_meta( '_refunded_item_id', true ) );
                    if ( $original_item_id ) {
                        $original_item = $parent->get_item( $original_item_id );
                        if ( $original_item ) {
                            $oci = self::order_item_cost( $original_item, $original_item->get_product() );
                            if ( null !== $oci['cost'] ) {
                                $oq = max( 0.0, abs( (float) $original_item->get_quantity() ) );
                                $rq = max( 0.0, abs( (float) $refund_item->get_quantity() ) );
                                $refund_cost = $oq > 0 ? (float) $oci['cost'] * min( 1, $rq / $oq ) : null;
                                $historical = ! empty( $oci['exact'] );
                            }
                        }
                    }
                }
                if ( null !== $refund_cost ) {
                    // A returned item restores cost to inventory/economic COGS.
                    $net_cogs -= $refund_cost;
                    $coverage_known += abs( $return_revenue );
                    if ( $historical ) $coverage_historical += abs( $return_revenue );
                }
            }
            if ( ! $had_line ) {
                $manual_return = max( 0, abs( (float) $refund->get_total() ) - abs( (float) $refund->get_total_tax() ) - abs( (float) $refund->get_shipping_total() ) );
                $merch_revenue -= $manual_return;
                $coverage_base += abs( $manual_return );
                // No item linkage means cost restoration is unknowable.
            }
        }

        $profit = $coverage_known > 0 ? $merch_revenue - $net_cogs : null;
        return array(
            'profit' => $profit,
            'margin' => null !== $profit && abs( $merch_revenue ) > 0.00001 ? 100 * $profit / $merch_revenue : null,
            'merch_revenue' => $merch_revenue,
            'net_cogs' => $net_cogs,
            'cost_coverage' => $coverage_base > 0 ? 100 * $coverage_known / $coverage_base : 0,
            'historical_cogs_coverage' => $coverage_base > 0 ? 100 * $coverage_historical / $coverage_base : 0,
            'coverage_base' => $coverage_base,
            'coverage_known' => $coverage_known,
            'truncated' => $q['truncated'] || $refund_truncated,
            'basis' => 'event_period_historical_order_item_cogs',
        );
    }

    private static function money_meta() {
        $currency = get_woocommerce_currency();
        $divisor_setting = (string) get_option( 'hgr_money_divisor', 'auto' );
        if ( 'auto' === $divisor_setting ) {
            $divisor = 'IRR' === strtoupper( $currency ) ? 10 : 1;
        } else {
            $divisor = max( 1, (float) $divisor_setting );
        }
        $label = trim( (string) get_option( 'hgr_money_label', '' ) );
        if ( ! $label ) {
            $label = 'IRR' === strtoupper( $currency ) || 'IRT' === strtoupper( $currency ) ? 'تومان' : $currency;
        }
        return array( 'currency' => $currency, 'divisor' => $divisor, 'label' => $label );
    }

    /**
     * Independent event-ledger fallback used when the Analytics DataStore cannot
     * express the active filters. Sale events use the configured Analytics date
     * basis; refund events are booked on the actual refund event date.
     */
    private static function financial_fallback_ledger( $start, $end, $filters = array() ) {
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $gross = 0.0; $discounts = 0.0; $tax = 0.0; $shipping = 0.0; $items = 0.0;
        foreach ( $q['orders'] as $order ) {
            // Reconstruct WooCommerce gross sales from the order financial
            // envelope. This keeps fees in the same revenue base instead of
            // silently dropping them by summing only line-item subtotals.
            $discount = (float) $order->get_discount_total();
            $gross += max( 0.0, (float) $order->get_total() - (float) $order->get_total_tax() - (float) $order->get_shipping_total() + $discount );
            $discounts += $discount;
            $tax += (float) $order->get_total_tax();
            $shipping += (float) $order->get_shipping_total();
            foreach ( $order->get_items( 'line_item' ) as $item ) $items += max( 0.0, (float) $item->get_quantity() );
        }
        $refund = self::refund_metrics( $start, $end, $filters, false );
        $returns = (float) $refund['returns'];
        $tax = max( 0.0, $tax - (float) $refund['taxes'] );
        $shipping = max( 0.0, $shipping - (float) $refund['shipping'] );
        $items = max( 0.0, $items - (float) $refund['items'] );
        $net = $gross - $discounts - $returns;
        $total = $net + $tax + $shipping;
        $orders = count( $q['orders'] );
        return array(
            'orders'=>$orders, 'items'=>$items, 'gross'=>$gross, 'refunds'=>$returns,
            'discounts'=>$discounts, 'net'=>$net, 'tax'=>$tax, 'shipping'=>$shipping,
            'total_sales'=>$total, 'aov'=>$orders ? $net/$orders : 0.0,
            'items_per_order'=>$orders ? $items/$orders : 0.0,
            'refund_orders'=>(int)$refund['refund_orders'],
            'truncated'=>!empty($q['truncated']) || !empty($refund['truncated']),
            'refund_source'=>$refund['source'],
            'date_type'=>HGR_Reference::date_type(),
        );
    }

    private static function fast_customer_cohort_metrics( $start, $end, $fallback_customers = 0 ) {
        global $wpdb;
        $stats = $wpdb->prefix . 'wc_order_stats';
        $customers = $wpdb->prefix . 'wc_customer_lookup';
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stats ) ) !== $stats || $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $customers ) ) !== $customers ) {
            return null;
        }
        $date_col = HGR_Reference::date_type();
        if ( ! in_array( $date_col, array( 'date_created','date_paid','date_completed' ), true ) ) $date_col='date_paid';
        $statuses = array_map( static function($s){ return 'wc-' . str_replace('wc-','',sanitize_key($s)); }, self::paid_statuses() );
        if ( ! $statuses ) return null;
        $ph = implode( ',', array_fill( 0, count($statuses), '%s' ) );
        $start_dt=$start.' 00:00:00'; $end_dt=$end.' 23:59:59';
        $sql = "SELECT COUNT(*) identifiable_customers,
                       SUM(CASE WHEN x.first_date >= %s THEN 1 ELSE 0 END) new_customers,
                       SUM(CASE WHEN x.first_date < %s THEN 1 ELSE 0 END) repeat_customers,
                       COALESCE(SUM(x.repeat_sales),0) repeat_sales,
                       SUM(x.identity_known) identity_known
                FROM (
                    SELECT p.customer_id, f.first_date,
                           SUM(CASE WHEN p.`{$date_col}` > f.first_date THEN p.net_total ELSE 0 END) repeat_sales,
                           MAX(CASE WHEN c.user_id>0 OR (c.email IS NOT NULL AND c.email<>'') THEN 1 ELSE 0 END) identity_known
                    FROM {$stats} p
                    INNER JOIN (
                        SELECT customer_id, MIN(`{$date_col}`) first_date
                        FROM {$stats}
                        WHERE parent_id=0 AND customer_id>0 AND `{$date_col}`<=%s AND status IN ({$ph})
                        GROUP BY customer_id
                    ) f ON f.customer_id=p.customer_id
                    LEFT JOIN {$customers} c ON c.customer_id=p.customer_id
                    WHERE p.parent_id=0 AND p.customer_id>0 AND p.`{$date_col}` BETWEEN %s AND %s AND p.status IN ({$ph})
                    GROUP BY p.customer_id, f.first_date
                ) x";
        $params=array($start_dt,$start_dt,$end_dt);
        $params=array_merge($params,$statuses,array($start_dt,$end_dt),$statuses);
        $row=$wpdb->get_row($wpdb->prepare($sql,$params),ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! is_array($row) ) return null;
        $known=(int)($row['identity_known']??0);
        $total=max((int)$fallback_customers,(int)($row['identifiable_customers']??0));
        return array(
            'customers'=>$total,
            'new_customers'=>(int)($row['new_customers']??0),
            'repeat_customers'=>(int)($row['repeat_customers']??0),
            'repeat_sales'=>(float)($row['repeat_sales']??0),
            'identity_known'=>$known,
            'identity_coverage'=>$total>0?100*$known/$total:100,
            'repeat_rate'=>$known>0?100*(int)($row['repeat_customers']??0)/$known:0,
            'source'=>'wc_order_stats_customer_cohort_sql',
        );
    }

    private static function fast_attempt_metrics( $start, $end ) {
        global $wpdb;
        $stats=$wpdb->prefix.'wc_order_stats';
        if ( $wpdb->get_var( $wpdb->prepare('SHOW TABLES LIKE %s',$stats) ) !== $stats ) return null;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT status,COUNT(*) c,COALESCE(SUM(total_sales),0) v FROM {$stats} WHERE parent_id=0 AND date_created BETWEEN %s AND %s GROUP BY status",$start.' 00:00:00',$end.' 23:59:59'),ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! is_array($rows) ) return null;
        $attempts=0;$cancelled=0;$failed=0;$lost=0.0;
        foreach($rows as $r){$st=str_replace('wc-','',sanitize_key($r['status']??''));if(in_array($st,array('checkout-draft','trash','auto-draft'),true))continue;$c=(int)$r['c'];$attempts+=$c;if('cancelled'===$st){$cancelled+=$c;$lost+=(float)$r['v'];}if('failed'===$st){$failed+=$c;$lost+=(float)$r['v'];}}
        return array('attempts'=>$attempts,'cancelled'=>$cancelled,'failed'=>$failed,'lost_value'=>$lost,'cancel_rate'=>$attempts?100*$cancelled/$attempts:0,'failed_rate'=>$attempts?100*$failed/$attempts:0,'truncated'=>false,'source'=>'wc_order_stats_operational_sql');
    }

    private static function fast_reference_summary_if_large( $start, $end, $filters ) {
        if ( self::has_data_filters( $filters ) ) return null;
        $mode = HGR_Reference::mode();
        $ref = HGR_Reference::primary_stats( $start, $end, $filters, 'day' );
        if ( is_wp_error( $ref ) ) return null;
        $base = ( isset( $ref['definition_profile'] ) && 'woocommerce_legacy_sales_by_date' === $ref['definition_profile'] )
            ? HGR_Legacy_Reference::map_to_hgr_summary( $ref['totals'] )
            : HGR_Reference::map_to_hgr_summary( $ref['totals'] );
        $threshold = max( 1000, absint( apply_filters( 'hgr_fast_summary_order_threshold', 5000 ) ) );
        if ( (int) $base['orders'] <= $threshold ) return null;

        // Cheap CRUD cohort check only; never hydrate the whole period here.
        $args = array( 'status'=>self::paid_statuses(), 'limit'=>1, 'paginate'=>true, 'return'=>'ids' );
        $date_key = self::order_query_date_key();
        $args[$date_key] = $start . '...' . $end;
        try {
            $r = wc_get_orders( $args );
            $crud = is_object( $r ) && isset( $r->total ) ? (int) $r->total : -1;
        } catch ( Throwable $e ) {
            $crud = -1;
        }
        if ( 'analytics' === $mode && ( $crud < 0 || $crud !== (int) $base['orders'] ) ) return null;

        $cust = self::fast_customer_cohort_metrics( $start, $end, (int) $base['customers_core'] );
        $attempt = self::fast_attempt_metrics( $start, $end );
        if ( null === $cust || null === $attempt ) return null;

        if ( 'legacy' === $mode && isset( $ref['totals']['refunded_orders'] ) ) {
            $refund_orders = (int) $ref['totals']['refunded_orders'];
            $refund_source = 'woocommerce_legacy_sales_by_date_exact';
            $refund_truncated = false;
        } else {
            $refund = self::refund_metrics( $start, $end, $filters, true );
            $refund_orders = (int) $refund['refund_orders'];
            $refund_source = $refund['source'];
            $refund_truncated = ! empty( $refund['truncated'] );
        }

        return array_merge( $base, array(
            'refund_orders'=>$refund_orders,
            'customers'=>$cust['customers'],
            'cancelled'=>$attempt['cancelled'], 'failed'=>$attempt['failed'], 'attempts'=>$attempt['attempts'], 'lost_value'=>$attempt['lost_value'],
            'cancel_rate'=>$attempt['cancel_rate'], 'failed_rate'=>$attempt['failed_rate'],
            'refund_rate'=>$base['orders'] ? 100*$refund_orders/$base['orders'] : 0,
            'new_customers'=>$cust['new_customers'], 'repeat_customers'=>$cust['repeat_customers'],
            'customer_identity_unknown'=>max( 0, $cust['customers']-$cust['identity_known'] ),
            'customer_identity_coverage'=>$cust['identity_coverage'], 'repeat_rate'=>$cust['repeat_rate'], 'repeat_sales'=>$cust['repeat_sales'],
            'profit'=>null, 'margin'=>null, 'cost_coverage'=>0, 'historical_cogs_coverage'=>0, 'profit_basis'=>'deferred_high_volume_open_profit_report',
            'profit_deferred'=>true,
            'truncated'=>$refund_truncated,
            'data_source'=>$ref['source'], 'reference_exact'=>true, 'reference_error'=>'', 'refund_source'=>$refund_source,
            'date_type'=>HGR_Reference::date_type(),
            'status_source'=>!empty(get_option('hgr_sales_statuses',array())) ? 'manual_override' : ( 'legacy' === $mode ? 'woocommerce_legacy_fixed_statuses' : 'woocommerce_analytics_defaults' ),
            'reference_mode'=>$mode,
            'analytics_sync'=>'analytics'===$mode ? 'matched_crud_order_count_fast' : ( $crud===(int)$base['orders'] ? 'legacy_matched_crud_order_count_fast' : 'legacy_exact_crud_cohort_diff_fast' ),
            'canonical_kpi'=>true, 'kpi_verification'=>'reference_exact_reconciled',
            'fast_path'=>true, 'fast_threshold'=>$threshold,
        ) );
    }

    private static function summary( $start, $end, $filters = array() ) {
        $cache = self::get_cached( 'summary', $start, $end, $filters );
        if ( false !== $cache ) return $cache;

        $fast = self::fast_reference_summary_if_large( $start, $end, $filters );
        if ( is_array( $fast ) ) return self::set_cached( 'summary', $start, $end, $filters, $fast );

        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $customers = array();
        $customer_order_values = array();
        foreach ( $q['orders'] as $order ) {
            $ck = self::customer_key( $order );
            $customers[ $ck ] = true;
            if ( ! isset( $customer_order_values[ $ck ] ) ) $customer_order_values[ $ck ] = array();
            $od = self::order_report_date( $order );
            $customer_order_values[ $ck ][] = array(
                'date' => $od ? $od->date_i18n( 'Y-m-d H:i:s' ) : '',
                'net' => self::order_net( $order ),
            );
        }

        // Customer cohort classification is based on the customer's first
        // successful purchase on the same date basis used by Analytics.
        $life = self::lifetime_customer_map( $end );
        $new = 0; $returning = 0; $unknown_identity = 0; $repeat_sales = 0.0;
        foreach ( array_keys( $customers ) as $ck ) {
            $first = isset( $life['map'][ $ck ]['first'] ) ? (string) $life['map'][ $ck ]['first'] : '';
            if ( ! $first ) {
                $unknown_identity++;
                continue;
            }
            if ( substr( $first, 0, 10 ) < $start ) $returning++; else $new++;
            foreach ( $customer_order_values[ $ck ] as $ov ) {
                // The first purchase itself is not repeat revenue. A second
                // purchase later in the same reporting period is.
                if ( $ov['date'] && $ov['date'] > $first ) $repeat_sales += (float) $ov['net'];
            }
        }
        $identity_known = max( 0, count( $customers ) - $unknown_identity );

        // Operational failure KPIs use the created-order cohort, independently
        // from the revenue report's paid/completed date basis.
        $attempt = self::attempt_metrics( $start, $end, $filters );

        // Active reference profile. In Legacy Exact mode this delegates to the
        // same WC_Report_Sales_By_Date class used by WooCommerce > Reports.
        // In Analytics mode it delegates to WooCommerce Orders Stats DataStore.
        $ref = HGR_Reference::primary_stats( $start, $end, $filters, 'day' );
        $source = 'filtered_event_ledger';
        $exact = false;
        $analytics_sync = 'not_applicable';
        $reference_mode = HGR_Reference::mode();
        $canonical_kpi = false;
        $kpi_verification = 'fallback_unverified';
        if ( ! is_wp_error( $ref ) && empty( $q['truncated'] ) ) {
            $reference_orders = isset( $ref['totals']['orders_count'] ) ? (int) $ref['totals']['orders_count'] : -1;
            $crud_orders = count( $q['orders'] );
            if ( 'analytics' === $reference_mode ) {
                if ( $reference_orders !== $crud_orders ) {
                    // Analytics lookup tables can be stale. In Analytics mode we
                    // refuse to present stale lookup totals as canonical.
                    $ref = new WP_Error(
                        'hgr_analytics_out_of_sync',
                        sprintf( 'WooCommerce Analytics lookup is out of sync for this range (Analytics=%d, CRUD=%d).', $reference_orders, $crud_orders )
                    );
                    $analytics_sync = 'out_of_sync';
                } else {
                    $analytics_sync = 'matched_crud_order_count';
                    $canonical_kpi = true;
                    $kpi_verification = 'analytics_reconciled';
                }
            } else {
                // Legacy Exact remains authoritative for parity with wc-reports.
                // CRUD is a supplemental cohort diagnostic only, because the core
                // legacy report may include order types/compatibility details that
                // WC_Order_Query does not reproduce identically.
                $analytics_sync = ( $reference_orders === $crud_orders ) ? 'legacy_matched_crud_order_count' : 'legacy_exact_crud_cohort_diff';
                $canonical_kpi = true;
                $kpi_verification = 'legacy_exact';
            }
        }
        $prefer_analytics_ledger = ( 'analytics' === $reference_mode && ! is_wp_error( $ref ) );
        $refund_event = array( 'returns'=>0,'taxes'=>0,'shipping'=>0,'items'=>0,'refund_orders'=>0,'truncated'=>false,'source'=>'none' );
        if ( ! is_wp_error( $ref ) ) {
            if ( isset( $ref['definition_profile'] ) && 'woocommerce_legacy_sales_by_date' === $ref['definition_profile'] ) {
                $base = HGR_Legacy_Reference::map_to_hgr_summary( $ref['totals'] );
                $refund_event = array(
                    'returns'=>(float)($ref['totals']['refunds']??0), 'taxes'=>0, 'shipping'=>0, 'items'=>0,
                    'refund_orders'=>(int)($ref['totals']['refunded_orders']??0), 'truncated'=>false,
                    'source'=>'woocommerce_legacy_sales_by_date_exact',
                );
            } else {
                $base = HGR_Reference::map_to_hgr_summary( $ref['totals'] );
                // Refund-order count is supplemental and not a core Analytics total.
                $refund_event = self::refund_metrics( $start, $end, $filters, true );
            }
            $source = $ref['source'];
            $exact = true;
        } else {
            $ledger = self::financial_fallback_ledger( $start, $end, $filters );
            $refund_event = array(
                'returns'=>$ledger['refunds'], 'taxes'=>0, 'shipping'=>0,
                'items'=>0, 'refund_orders'=>$ledger['refund_orders'],
                'truncated'=>$ledger['truncated'], 'source'=>$ledger['refund_source'],
            );
            $base = array(
                'orders'=>$ledger['orders'], 'items'=>$ledger['items'], 'gross'=>$ledger['gross'],
                'refunds'=>$ledger['refunds'], 'discounts'=>$ledger['discounts'], 'net'=>$ledger['net'],
                'tax'=>$ledger['tax'], 'shipping'=>$ledger['shipping'], 'total_sales'=>$ledger['total_sales'],
                'aov'=>$ledger['aov'], 'items_per_order'=>$ledger['items_per_order'],
                'customers_core'=>count($customers),
            );
        }

        $profit = self::profit_metrics( $start, $end, $filters, $prefer_analytics_ledger );
        $refund_orders = (int) $refund_event['refund_orders'];
        $result = array_merge( $base, array(
            'refund_orders' => $refund_orders,
            'customers' => count( $customers ),
            'cancelled' => $attempt['cancelled'],
            'failed' => $attempt['failed'],
            'attempts' => $attempt['attempts'],
            'lost_value' => $attempt['lost_value'],
            'cancel_rate' => $attempt['cancel_rate'],
            'failed_rate' => $attempt['failed_rate'],
            'refund_rate' => $base['orders'] ? 100 * $refund_orders / $base['orders'] : 0,
            'new_customers' => $new,
            'repeat_customers' => $returning,
            'customer_identity_unknown' => $unknown_identity,
            'customer_identity_coverage' => count( $customers ) ? 100 * $identity_known / count( $customers ) : 100,
            'repeat_rate' => $identity_known ? 100 * $returning / $identity_known : 0,
            'repeat_sales' => $repeat_sales,
            'profit' => $profit['profit'],
            'margin' => $profit['margin'],
            'cost_coverage' => $profit['cost_coverage'],
            'historical_cogs_coverage' => $profit['historical_cogs_coverage'],
            'profit_basis' => $profit['basis'],
            'truncated' => $q['truncated'] || $life['truncated'] || $attempt['truncated'] || ! empty( $refund_event['truncated'] ) || ! empty( $profit['truncated'] ),
            'data_source' => $source,
            'reference_exact' => $exact,
            'reference_error' => is_wp_error( $ref ) ? $ref->get_error_message() : '',
            'refund_source' => isset( $refund_event['source'] ) ? $refund_event['source'] : '',
            'date_type' => HGR_Reference::date_type(),
            'status_source' => ! empty( get_option( 'hgr_sales_statuses', array() ) ) ? 'manual_override' : ( 'legacy' === $reference_mode ? 'woocommerce_legacy_fixed_statuses' : 'woocommerce_analytics_defaults' ),
            'reference_mode' => $reference_mode,
            'analytics_sync' => $analytics_sync,
            'canonical_kpi' => $canonical_kpi,
            'kpi_verification' => $kpi_verification,
        ) );
        return self::set_cached( 'summary', $start, $end, $filters, $result );
    }


    /**
     * Lifetime customer metrics.
     *
     * Prefer WooCommerce Analytics lookup tables. Those tables are built for
     * reporting and let a busy store calculate lifetime counts without loading
     * tens of thousands of WC_Order objects. If they are unavailable we fall
     * back to the portable CRUD path.
     */
    private static function lifetime_customer_map( $end, $with_dates = false ) {
        $suffix = $with_dates ? '|dates' : '|summary';
        $key = 'hgr30_lifetime_' . md5( get_option( 'hgr_cache_version', '1' ) . '|' . $end . $suffix );
        $cached = get_transient( $key );
        if ( false !== $cached ) return $cached;

        global $wpdb;
        $stats_table = $wpdb->prefix . 'wc_order_stats';
        $customer_table = $wpdb->prefix . 'wc_customer_lookup';
        $stats_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stats_table ) );
        $customer_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $customer_table ) );
        $date_col = HGR_Reference::date_type();
        if ( ! in_array( $date_col, array( 'date_created', 'date_created_gmt', 'date_paid', 'date_completed' ), true ) ) $date_col = 'date_paid';

        $lookup_trusted = true;
        if ( 'analytics' === HGR_Reference::mode() ) {
            // Lifetime/customer KPIs must not trust partially imported Analytics
            // tables. Verify the full historical cohort up to the requested end.
            $life_sync = HGR_Reference::analytics_sync_status( '2010-01-01', $end );
            $lookup_trusted = ! empty( $life_sync['ready'] );
        }

        if ( $lookup_trusted && $stats_exists === $stats_table && $customer_exists === $customer_table ) {
            $included = array_map( static function ( $s ) { return 'wc-' . str_replace( 'wc-', '', $s ); }, self::paid_statuses() );
            if ( ! $included ) $included = array( 'wc-processing', 'wc-completed' );
            $ph = implode( ',', array_fill( 0, count( $included ), '%s' ) );
            $params = array_merge( array( $end . ' 23:59:59' ), $included );
            $sql = "SELECT s.customer_id, c.user_id, c.email,
                           COUNT(*) AS orders_count,
                           COALESCE(SUM(s.net_total),0) AS spent,
                           MIN(s.`{$date_col}`) AS first_date,
                           MAX(s.`{$date_col}`) AS last_date
                    FROM {$stats_table} s
                    LEFT JOIN {$customer_table} c ON c.customer_id=s.customer_id
                    WHERE s.parent_id=0 AND s.`{$date_col}` <= %s AND s.status IN ({$ph})
                    GROUP BY s.customer_id, c.user_id, c.email";
            $rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( is_array( $rows ) ) {
                $map = array(); $customer_to_key = array();
                foreach ( $rows as $row ) {
                    $cid=(int)$row['customer_id']; $uid=(int)$row['user_id']; $email=strtolower(trim((string)$row['email']));
                    // Keep the same resolver order as customer_key(): user -> email -> phone.
                    if ( $uid>0 ) $ck='u:'.$uid; elseif ( $email ) $ck='e:'.$email; else continue;
                    $map[$ck]=array('orders'=>(int)$row['orders_count'],'spent'=>(float)$row['spent'],'first'=>(string)$row['first_date'],'last'=>(string)$row['last_date'],'dates'=>array());
                    if($cid>0)$customer_to_key[$cid]=$ck;
                }
                // Refunds are separate event rows. Adjust lifetime net spend on
                // the refund creation date instead of retroactively changing the
                // original order date.
                if ( $customer_to_key ) {
                    $refund_sql = "SELECT p.customer_id, COALESCE(SUM(ABS(r.net_total)),0) refund_net
                                   FROM {$stats_table} r
                                   INNER JOIN {$stats_table} p ON p.order_id=r.parent_id
                                   WHERE r.parent_id>0 AND r.date_created<=%s
                                   GROUP BY p.customer_id";
                    $refund_rows = $wpdb->get_results( $wpdb->prepare( $refund_sql, $end . ' 23:59:59' ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                    foreach ( (array) $refund_rows as $rr ) {
                        $cid=(int)($rr['customer_id']??0);
                        if($cid>0 && isset($customer_to_key[$cid],$map[$customer_to_key[$cid]])) $map[$customer_to_key[$cid]]['spent'] -= (float)($rr['refund_net']??0);
                    }
                }
                if ( $with_dates && $customer_to_key ) {
                    $last_id=0; $chunk=5000;
                    do {
                        $date_params=array_merge(array($end.' 23:59:59',$last_id),$included);
                        $date_sql="SELECT s.order_id,s.customer_id,s.`{$date_col}` AS report_date FROM {$stats_table} s WHERE s.`{$date_col}`<=%s AND s.order_id>%d AND s.parent_id=0 AND s.status IN ({$ph}) ORDER BY s.order_id ASC LIMIT {$chunk}";
                        $date_rows=$wpdb->get_results($wpdb->prepare($date_sql,$date_params),ARRAY_A); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                        if(!$date_rows)break;
                        foreach($date_rows as $dr){$last_id=max($last_id,(int)$dr['order_id']);$cid=(int)$dr['customer_id'];if(isset($customer_to_key[$cid]))$map[$customer_to_key[$cid]]['dates'][]=(string)$dr['report_date'];}
                    } while(true);
                    foreach($map as &$r)sort($r['dates']); unset($r);
                }
                $result=array('map'=>$map,'truncated'=>false,'source'=>'woocommerce_analytics_lookup','date_type'=>$date_col);
                set_transient($key,$result,15*MINUTE_IN_SECONDS); return $result;
            }
        }

        $q=self::query_orders('2010-01-01',$end,self::paid_statuses(),array(),self::MAX_ORDERS); $map=array();
        foreach($q['orders'] as $order){$ck=self::customer_key($order);if(!isset($map[$ck]))$map[$ck]=array('orders'=>0,'spent'=>0,'first'=>'','last'=>'','dates'=>array());$od=self::order_report_date($order);$date=$od?$od->date_i18n('Y-m-d H:i:s'):'';$map[$ck]['orders']++;$map[$ck]['spent']+=self::order_net($order);if($date){if(!$map[$ck]['first']||$date<$map[$ck]['first'])$map[$ck]['first']=$date;if(!$map[$ck]['last']||$date>$map[$ck]['last'])$map[$ck]['last']=$date;if($with_dates)$map[$ck]['dates'][]=$date;}}
        if($with_dates){foreach($map as &$r)sort($r['dates']);unset($r);}
        $result=array('map'=>$map,'truncated'=>$q['truncated'],'source'=>'woocommerce_crud_fallback','date_type'=>HGR_Reference::date_type());set_transient($key,$result,15*MINUTE_IN_SECONDS);return $result;
    }


    private static function comparison_range( $start, $end, $mode ) {
        $tz = wp_timezone();
        $s = new DateTimeImmutable( $start, $tz );
        $e = new DateTimeImmutable( $end, $tz );
        if ( 'last_year' === $mode ) {
            return array( $s->modify( '-1 year' )->format( 'Y-m-d' ), $e->modify( '-1 year' )->format( 'Y-m-d' ) );
        }
        if ( 'previous_jmonth' === $mode ) {
            list( $jy, $jm, $jd ) = HGR_Jalali::gregorian_to_jalali( (int) $s->format( 'Y' ), (int) $s->format( 'm' ), (int) $s->format( 'd' ) );
            $jm--;
            if ( $jm < 1 ) { $jm = 12; $jy--; }
            list( $gy1, $gm1, $gd1 ) = HGR_Jalali::jalali_to_gregorian( $jy, $jm, 1 );
            $ny = $jy; $nm = $jm + 1; if ( $nm > 12 ) { $nm = 1; $ny++; }
            list( $gy2, $gm2, $gd2 ) = HGR_Jalali::jalali_to_gregorian( $ny, $nm, 1 );
            $first = new DateTimeImmutable( sprintf( '%04d-%02d-%02d', $gy1, $gm1, $gd1 ), $tz );
            $next = new DateTimeImmutable( sprintf( '%04d-%02d-%02d', $gy2, $gm2, $gd2 ), $tz );
            return array( $first->format( 'Y-m-d' ), $next->modify( '-1 day' )->format( 'Y-m-d' ) );
        }
        if ( 'previous_month' === $mode ) {
            $first = $s->modify( 'first day of previous month' );
            $last = $s->modify( 'last day of previous month' );
            return array( $first->format( 'Y-m-d' ), $last->format( 'Y-m-d' ) );
        }
        $days = (int) $s->diff( $e )->format( '%a' ) + 1;
        $prev_end = $s->modify( '-1 day' );
        $prev_start = $prev_end->modify( '-' . ( $days - 1 ) . ' days' );
        return array( $prev_start->format( 'Y-m-d' ), $prev_end->format( 'Y-m-d' ) );
    }

    private static function delta( $current, $previous ) {
        if ( 0.0 === (float) $previous ) return null;
        return 100 * ( (float) $current - (float) $previous ) / abs( (float) $previous );
    }

    private static function has_data_filters( $filters ) {
        $copy = is_array( $filters ) ? $filters : array();
        unset( $copy['compare'], $copy['customer_segment'] );
        foreach ( $copy as $value ) {
            if ( is_array( $value ) && $value ) return true;
            if ( ! is_array( $value ) && '' !== (string) $value ) return true;
        }
        return false;
    }

    /** Lightweight snapshot for the four dashboard headline periods. */
    private static function basic_snapshot( $start, $end, $filters = array() ) {
        $ref = HGR_Reference::primary_stats( $start, $end, $filters, 'day' );
        if ( ! is_wp_error( $ref ) ) {
            // Analytics headline snapshots must pass the same structural sync gate
            // as the main KPI summary; otherwise use the audited CRUD fallback.
            if ( 'analytics' === HGR_Reference::mode() && ! self::has_data_filters( $filters ) ) {
                $sync = HGR_Reference::analytics_sync_status( $start, $end );
                if ( empty( $sync['ready'] ) ) return self::summary( $start, $end, $filters );
            }
            $m = ( isset( $ref['definition_profile'] ) && 'woocommerce_legacy_sales_by_date' === $ref['definition_profile'] )
                ? HGR_Legacy_Reference::map_to_hgr_summary( $ref['totals'] )
                : HGR_Reference::map_to_hgr_summary( $ref['totals'] );
            return array( 'orders'=>$m['orders'], 'net'=>$m['net'], 'items'=>$m['items'], 'aov'=>$m['aov'], 'total_sales'=>$m['total_sales'], 'truncated'=>false, 'data_source'=>$ref['source'], 'canonical_kpi'=>true );
        }
        return self::summary( $start, $end, $filters );
    }

    private static function jalali_month_range_for_gregorian( $gregorian_date, $offset_months = 0 ) {
        $parts = explode( '-', $gregorian_date );
        list( $jy, $jm ) = HGR_Jalali::gregorian_to_jalali( (int) $parts[0], (int) $parts[1], (int) $parts[2] );
        $index = ( $jy * 12 + ( $jm - 1 ) ) + (int) $offset_months;
        $target_y = (int) floor( $index / 12 );
        $target_m = ( $index % 12 ) + 1;
        if ( $target_m <= 0 ) { $target_m += 12; $target_y--; }
        list( $sy, $sm, $sd ) = HGR_Jalali::jalali_to_gregorian( $target_y, $target_m, 1 );
        $next_index = $index + 1;
        $next_y = (int) floor( $next_index / 12 );
        $next_m = ( $next_index % 12 ) + 1;
        if ( $next_m <= 0 ) { $next_m += 12; $next_y--; }
        list( $ny, $nm, $nd ) = HGR_Jalali::jalali_to_gregorian( $next_y, $next_m, 1 );
        $start = sprintf( '%04d-%02d-%02d', $sy, $sm, $sd );
        $next = new DateTimeImmutable( sprintf( '%04d-%02d-%02d', $ny, $nm, $nd ), wp_timezone() );
        return array( $start, $next->modify( '-1 day' )->format( 'Y-m-d' ) );
    }

    public static function dashboard( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'dashboard', $start, $end, $filters );
        if ( false !== $cached ) return $cached;

        // Headline dashboard must remain fast on high-volume stores. Canonical
        // KPI summary loads first; expensive product/category detail is deferred
        // when the selected period is large.
        $current = self::summary( $start, $end, $filters );
        $detail_limit = max( 500, absint( apply_filters( 'hgr_dashboard_detail_order_limit', 5000 ) ) );
        $sales = null;
        if ( empty( $current['truncated'] ) && (int) $current['orders'] <= $detail_limit ) {
            $sales = self::sales( $start, $end, $filters );
        }
        $compare_mode = isset( $filters['compare'] ) ? $filters['compare'] : 'previous_period';
        $previous = null;
        $changes = array();
        $compare_range = null;
        if ( 'none' !== $compare_mode ) {
            $compare_range = self::comparison_range( $start, $end, $compare_mode );
            $previous = self::summary( $compare_range[0], $compare_range[1], $filters );
            foreach ( array( 'net', 'orders', 'aov', 'items', 'customers', 'cancel_rate', 'repeat_rate', 'profit' ) as $key ) {
                if ( isset( $current[ $key ] ) && isset( $previous[ $key ] ) && null !== $current[ $key ] && null !== $previous[ $key ] ) {
                    $changes[ $key ] = self::delta( $current[ $key ], $previous[ $key ] );
                }
            }
        }

        $today = current_time( 'Y-m-d' );
        $now = new DateTimeImmutable( $today, wp_timezone() );
        $yesterday = $now->modify( '-1 day' )->format( 'Y-m-d' );
        list( $month_start, $month_end ) = self::jalali_month_range_for_gregorian( $today, 0 );
        list( $prev_month_start, $prev_month_end ) = self::jalali_month_range_for_gregorian( $today, -1 );
        $snapshots = array(
            'today' => self::basic_snapshot( $today, $today, $filters ),
            'yesterday' => self::basic_snapshot( $yesterday, $yesterday, $filters ),
            'this_month' => self::basic_snapshot( $month_start, min( $today, $month_end ), $filters ),
            'previous_month' => self::basic_snapshot( $prev_month_start, $prev_month_end, $filters ),
        );

        $result = array(
            'range' => array( 'start' => $start, 'end' => $end, 'start_j' => HGR_Jalali::format_gregorian( $start ), 'end_j' => HGR_Jalali::format_gregorian( $end ) ),
            'summary' => $current,
            'previous' => $previous,
            'changes' => $changes,
            'compare_range' => $compare_range,
            'snapshots' => $snapshots,
            'top_products' => is_array( $sales ) && isset( $sales['top_products'] ) ? $sales['top_products'] : array(),
            'top_categories' => is_array( $sales ) && isset( $sales['top_categories'] ) ? $sales['top_categories'] : array(),
            'money' => self::money_meta(),
            'meta' => array(
                'truncated'=>$current['truncated'], 'engine'=>'analytics_first_reference_reconciled_v33',
                'recovery_used'=>is_array($sales) && !empty($sales['meta']['recovery_used']),
                'sales_statuses'=>self::paid_statuses(), 'detail_deferred'=>null===$sales, 'detail_limit'=>$detail_limit,
                'data_source'=>$current['data_source']??'', 'reference_exact'=>!empty($current['reference_exact']),
                'reference_error'=>$current['reference_error']??'', 'analytics_sync'=>$current['analytics_sync']??'',
                'date_type'=>$current['date_type']??HGR_Reference::date_type(), 'reference_mode'=>$current['reference_mode']??HGR_Reference::mode(), 'profit_deferred'=>!empty($current['profit_deferred']),
                'canonical_kpi'=>!empty($current['canonical_kpi']), 'kpi_verification'=>$current['kpi_verification']??'fallback_unverified',
            ),
        );
        return self::set_cached( 'dashboard', $start, $end, $filters, $result );
    }


    public static function sales( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'sales', $start, $end, $filters );
        if ( false !== $cached ) return $cached;

        // Supplemental order-level scan. Canonical headline/daily KPIs are
        // overwritten from the active WooCommerce reference profile below whenever
        // that profile supports the active filters.
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $days = array();
        $hours = array_fill( 0, 24, array( 'orders' => 0, 'net' => 0, 'items' => 0 ) );
        $cursor = new DateTimeImmutable( $start, wp_timezone() );
        $last = new DateTimeImmutable( $end, wp_timezone() );
        while ( $cursor <= $last ) {
            $key = $cursor->format( 'Y-m-d' );
            $days[ $key ] = array(
                'date' => $key,
                'date_j' => HGR_Jalali::format_gregorian( $key ),
                'orders' => 0,
                'gross' => 0,
                'refunds' => 0,
                'discounts' => 0,
                'net' => 0,
                'tax' => 0,
                'shipping' => 0,
                'total_sales' => 0,
                'items' => 0,
                'aov' => 0,
                // Profit is a historical-Cost order-cohort supplemental metric.
                // Refund event timing can differ from the order date, so its
                // basis is disclosed in meta and never used as a Woo reference KPI.
                'profit' => 0,
                'profit_known' => false,
            );
            $cursor = $cursor->modify( '+1 day' );
        }

        $product_rows = array();
        $category_rows = array();
        $category_total_sales = 0.0;
        $profit_exact_revenue = 0.0;
        $profit_known_revenue = 0.0;
        $profit_all_revenue = 0.0;

        foreach ( $q['orders'] as $order ) {
            $report_date = self::order_report_date( $order );
            if ( ! $report_date ) continue;
            $date = $report_date->date_i18n( 'Y-m-d' );
            if ( ! isset( $days[ $date ] ) ) continue;
            $hour = (int) $report_date->date_i18n( 'G' );
            $qty = self::order_item_qty( $order );
            $order_net = self::order_net( $order );

            // These are fallback/cohort values only. If core Analytics is
            // available, exact Woo values replace them per day below.
            $fallback_gross = 0.0;
            foreach ( $order->get_items( 'line_item' ) as $item ) {
                $fallback_gross += (float) $item->get_subtotal();
            }
            $fallback_discount = (float) $order->get_discount_total();
            $fallback_tax = (float) $order->get_total_tax();
            $fallback_shipping = (float) $order->get_shipping_total();

            $days[ $date ]['orders']++;
            $days[ $date ]['gross'] += $fallback_gross;
            $days[ $date ]['discounts'] += $fallback_discount;
            $days[ $date ]['net'] += $order_net;
            $days[ $date ]['tax'] += $fallback_tax;
            $days[ $date ]['shipping'] += $fallback_shipping;
            $days[ $date ]['total_sales'] += (float) $order->get_total();
            $days[ $date ]['items'] += $qty;

            $hours[ $hour ]['orders']++;
            $hours[ $hour ]['net'] += $order_net;
            $hours[ $hour ]['items'] += $qty;

            foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
                $product = $item->get_product();
                $product_id = $item->get_variation_id() ?: $item->get_product_id();
                $refunded_qty = abs( (float) $order->get_qty_refunded_for_item( $item_id ) );
                $net_qty = max( 0, (float) $item->get_quantity() - $refunded_qty );
                $item_refund = abs( (float) $order->get_total_refunded_for_item( $item_id ) );
                $item_revenue = max( 0, (float) $item->get_total() - $item_refund );

                $profit_all_revenue += max( 0, (float) $item->get_total() );
                $cost_info = self::order_item_cost( $item, $product );
                if ( null !== $cost_info['cost'] ) {
                    // Order-item COGS is historical and belongs to the original
                    // sold quantity. Scale it by net quantity when a quantity
                    // refund is attached to this parent order.
                    $orig_qty = max( 0.0, (float) $item->get_quantity() );
                    $item_cost = (float) $cost_info['cost'];
                    if ( $orig_qty > 0 && $net_qty < $orig_qty ) {
                        $item_cost *= ( $net_qty / $orig_qty );
                    }
                    $days[ $date ]['profit'] += $item_revenue - $item_cost;
                    $days[ $date ]['profit_known'] = true;
                    $profit_known_revenue += max( 0, (float) $item->get_total() );
                    if ( ! empty( $cost_info['exact'] ) ) {
                        $profit_exact_revenue += max( 0, (float) $item->get_total() );
                    }
                }

                if ( ! isset( $product_rows[ $product_id ] ) ) {
                    $product_rows[ $product_id ] = array(
                        'id' => $product_id,
                        'name' => $item->get_name(),
                        'qty' => 0,
                        'sales' => 0,
                        'stock_status' => $product ? $product->get_stock_status() : 'unknown',
                    );
                }
                $product_rows[ $product_id ]['qty'] += $net_qty;
                $product_rows[ $product_id ]['sales'] += $item_revenue;

                $term = self::primary_category( $item->get_product_id() );
                $cat_id = $term ? (int) $term->term_id : 0;
                $cat_name = $term ? $term->name : 'بدون دسته';
                if ( ! isset( $category_rows[ $cat_id ] ) ) {
                    $category_rows[ $cat_id ] = array( 'id' => $cat_id, 'name' => $cat_name, 'orders_set' => array(), 'orders' => 0, 'sales' => 0, 'share' => 0 );
                }
                $category_rows[ $cat_id ]['orders_set'][ $order->get_id() ] = true;
                $category_rows[ $cat_id ]['sales'] += $item_revenue;
                $category_total_sales += $item_revenue;
            }
        }

        // Single canonical summary implementation. Never rebuild headline KPIs
        // a second way inside this report.
        $summary = self::summary( $start, $end, $filters );

        // Align daily series with WooCommerce Analytics. This fixes refund timing:
        // returns are recorded on the refund event date, not retroactively on
        // the parent order's original date.
        $reference = HGR_Reference::primary_stats( $start, $end, $filters, 'day' );
        $daily_reference_exact = ! empty( $summary['reference_exact'] ) && ! is_wp_error( $reference );
        if ( $daily_reference_exact ) {
            foreach ( $reference['intervals'] as $interval ) {
                $date = isset( $interval['date'] ) ? $interval['date'] : '';
                if ( ! $date || ! isset( $days[ $date ] ) ) continue;
                $days[ $date ]['orders'] = (int) $interval['orders_count'];
                $days[ $date ]['gross'] = (float) $interval['gross_sales'];
                $days[ $date ]['refunds'] = (float) $interval['refunds'];
                $days[ $date ]['discounts'] = (float) $interval['coupons'];
                $days[ $date ]['net'] = (float) $interval['net_revenue'];
                $days[ $date ]['tax'] = (float) $interval['taxes'];
                $days[ $date ]['shipping'] = (float) $interval['shipping'];
                $days[ $date ]['total_sales'] = (float) $interval['total_sales'];
                $days[ $date ]['items'] = (float) $interval['num_items_sold'];
                $days[ $date ]['aov'] = (float) $interval['avg_order_value'];
            }
        } else {
            $daily_refunds = self::refund_metrics( $start, $end, $filters, false );
            foreach ( (array) ( $daily_refunds['daily'] ?? array() ) as $date => $rr ) {
                if ( ! isset( $days[ $date ] ) ) continue;
                $returns = (float) ( $rr['returns'] ?? 0 );
                $rtax = (float) ( $rr['taxes'] ?? 0 );
                $rship = (float) ( $rr['shipping'] ?? 0 );
                $ritems = (float) ( $rr['items'] ?? 0 );
                $days[ $date ]['refunds'] += $returns;
                $days[ $date ]['net'] -= $returns;
                $days[ $date ]['tax'] -= $rtax;
                $days[ $date ]['shipping'] -= $rship;
                $days[ $date ]['total_sales'] -= ( $returns + $rtax + $rship );
                $days[ $date ]['items'] -= $ritems;
            }
            foreach ( $days as &$row ) {
                $row['aov'] = $row['orders'] ? $row['net'] / $row['orders'] : 0;
            }
            unset( $row );
        }

        $best = null;
        $worst = null;
        foreach ( $days as $row ) {
            if ( $row['orders'] > 0 && ( null === $best || $row['net'] > $best['net'] ) ) $best = $row;
            if ( $row['orders'] > 0 && ( null === $worst || $row['net'] < $worst['net'] ) ) $worst = $row;
        }

        $hour_rows = array();
        foreach ( $hours as $hour => $row ) {
            $row['hour'] = sprintf( '%02d:00', $hour );
            $row['aov'] = $row['orders'] ? $row['net'] / $row['orders'] : 0;
            $hour_rows[] = $row;
        }

        $top_products = array_values( $product_rows );
        usort( $top_products, static function ( $a, $b ) { return $b['sales'] <=> $a['sales']; } );
        $top_products = array_slice( $top_products, 0, 5 );

        $top_categories = array_values( $category_rows );
        foreach ( $top_categories as &$row ) {
            $row['orders'] = count( $row['orders_set'] );
            unset( $row['orders_set'] );
            $row['share'] = $category_total_sales > 0 ? 100 * $row['sales'] / $category_total_sales : 0;
        }
        unset( $row );
        usort( $top_categories, static function ( $a, $b ) { return $b['sales'] <=> $a['sales']; } );
        $top_categories = array_slice( $top_categories, 0, 5 );

        return self::set_cached( 'sales', $start, $end, $filters, array(
            'daily' => array_values( $days ),
            'hourly' => $hour_rows,
            'best_day' => $best,
            'worst_day' => $worst,
            'summary' => $summary,
            'top_products' => $top_products,
            'top_categories' => $top_categories,
            'money' => self::money_meta(),
            'meta' => array(
                'truncated' => ! empty( $summary['truncated'] ),
                'engine' => 'analytics_first_v33_multi_reference_streaming',
                'sales_statuses' => self::paid_statuses(),
                'data_source' => isset( $summary['data_source'] ) ? $summary['data_source'] : 'unknown',
                'reference_exact' => ! empty( $summary['reference_exact'] ),
                'canonical_kpi' => ! empty( $summary['canonical_kpi'] ),
                'kpi_verification' => $summary['kpi_verification'] ?? 'fallback_unverified',
                'analytics_sync' => $summary['analytics_sync'] ?? '',
                'reference_error' => $summary['reference_error'] ?? '',
                'daily_reference_exact' => $daily_reference_exact,
                'date_type' => HGR_Reference::date_type(),
                'hourly_basis' => 'paid-order cohort; refund events are canonical only in daily/headline KPI',
                'product_category_basis' => 'parent-order cohort; item refunds attached to parent order',
                'profit_basis' => 'historical order-item COGS where available; current product cost is marked fallback',
                'cogs_coverage' => $profit_all_revenue > 0 ? 100 * $profit_known_revenue / $profit_all_revenue : 0,
                'historical_cogs_coverage' => $profit_all_revenue > 0 ? 100 * $profit_exact_revenue / $profit_all_revenue : 0,
            ),
        ) );
    }


    public static function products( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'products', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $paid = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $failed = self::query_orders( $start, $end, self::failed_statuses(), $filters );
        $rows = array();
        foreach ( $paid['orders'] as $order ) {
            foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
                $product_id = $item->get_variation_id() ?: $item->get_product_id();
                $product = $item->get_product();
                if ( ! isset( $rows[ $product_id ] ) ) {
                    $rows[ $product_id ] = array(
                        'id' => $product_id,
                        'parent_id' => $item->get_product_id(),
                        'name' => $item->get_name(),
                        'sku' => $product ? $product->get_sku() : '',
                        'qty' => 0,
                        'orders' => 0,
                        'sales' => 0,
                        'gross_line' => 0,
                        'discount' => 0,
                        'refund_qty' => 0,
                        'refund_amount' => 0,
                        'cancelled_orders' => 0,
                        'cancelled_qty' => 0,
                        'cost' => 0,
                        'cost_known' => true,
                        'profit' => null,
                        'margin' => null,
                        'last_sale' => '',
                        'last_sale_j' => '',
                        'days_since_last_sale' => null,
                        'stock_qty' => $product && $product->managing_stock() ? $product->get_stock_quantity() : null,
                        'stock_status' => $product ? $product->get_stock_status() : 'unknown',
                        '_order_ids' => array(),
                    );
                }
                $qty = (float) $item->get_quantity();
                $rqty = abs( (float) $order->get_qty_refunded_for_item( $item_id ) );
                $net_qty = max( 0, $qty - $rqty );
                $refund_amount = abs( (float) $order->get_total_refunded_for_item( $item_id ) );
                $line_sales = max( 0, (float) $item->get_total() - $refund_amount );
                $subtotal = (float) $item->get_subtotal();
                $rows[ $product_id ]['qty'] += $net_qty;
                $rows[ $product_id ]['sales'] += $line_sales;
                $rows[ $product_id ]['gross_line'] += $subtotal;
                $rows[ $product_id ]['discount'] += max( 0, $subtotal - (float) $item->get_total() );
                $rows[ $product_id ]['refund_qty'] += $rqty;
                $rows[ $product_id ]['refund_amount'] += $refund_amount;
                $rows[ $product_id ]['_order_ids'][ $order->get_id() ] = true;
                $report_date = self::order_report_date( $order );
                $date = $report_date ? $report_date->date_i18n( 'Y-m-d H:i:s' ) : '';
                if ( $date && ( ! $rows[ $product_id ]['last_sale'] || $date > $rows[ $product_id ]['last_sale'] ) ) {
                    $rows[ $product_id ]['last_sale'] = $date;
                    $rows[ $product_id ]['last_sale_j'] = HGR_Jalali::format_gregorian( $date, true );
                }
                $ci = self::order_item_cost( $item, $product );
                if ( null === $ci['cost'] ) {
                    $rows[ $product_id ]['cost_known'] = false;
                } else {
                    $orig_qty = max( 0.0, (float) $item->get_quantity() );
                    $item_cost = (float) $ci['cost'];
                    if ( $orig_qty > 0 && $net_qty < $orig_qty ) $item_cost *= ( $net_qty / $orig_qty );
                    $rows[ $product_id ]['cost'] += $item_cost;
                    if ( ! isset( $rows[ $product_id ]['historical_cost_sales'] ) ) $rows[ $product_id ]['historical_cost_sales'] = 0.0;
                    if ( ! empty( $ci['exact'] ) ) $rows[ $product_id ]['historical_cost_sales'] += $line_sales;
                }
            }
        }
        foreach ( $failed['orders'] as $order ) {
            foreach ( $order->get_items( 'line_item' ) as $item ) {
                $pid = $item->get_variation_id() ?: $item->get_product_id();
                if ( ! isset( $rows[ $pid ] ) ) {
                    $product = $item->get_product();
                    $rows[ $pid ] = array(
                        'id' => $pid, 'parent_id' => $item->get_product_id(), 'name' => $item->get_name(), 'sku' => $product ? $product->get_sku() : '',
                        'qty' => 0, 'orders' => 0, 'sales' => 0, 'gross_line' => 0, 'discount' => 0, 'refund_qty' => 0, 'refund_amount' => 0,
                        'cancelled_orders' => 0, 'cancelled_qty' => 0, 'cost' => 0, 'cost_known' => false, 'profit' => null, 'margin' => null,
                        'last_sale' => '', 'last_sale_j' => '', 'days_since_last_sale' => null,
                        'stock_qty' => $product && $product->managing_stock() ? $product->get_stock_quantity() : null,
                        'stock_status' => $product ? $product->get_stock_status() : 'unknown', '_order_ids' => array(), '_failed_order_ids' => array(),
                    );
                }
                if ( ! isset( $rows[ $pid ]['_failed_order_ids'] ) ) $rows[ $pid ]['_failed_order_ids'] = array();
                $rows[ $pid ]['_failed_order_ids'][ $order->get_id() ] = true;
                $rows[ $pid ]['cancelled_qty'] += (float) $item->get_quantity();
            }
        }
        $now = current_time( 'timestamp' );
        foreach ( $rows as &$row ) {
            $row['orders'] = count( $row['_order_ids'] );
            $row['cancelled_orders'] = isset( $row['_failed_order_ids'] ) ? count( $row['_failed_order_ids'] ) : 0;
            $row['avg_price'] = $row['qty'] > 0 ? $row['sales'] / $row['qty'] : 0;
            if ( $row['cost_known'] && $row['qty'] > 0 ) {
                $row['profit'] = $row['sales'] - $row['cost'];
                $row['margin'] = $row['sales'] > 0 ? 100 * $row['profit'] / $row['sales'] : 0;
            }
            if ( $row['last_sale'] ) {
                $ts = strtotime( $row['last_sale'] );
                if ( $ts ) $row['days_since_last_sale'] = max( 0, floor( ( $now - $ts ) / DAY_IN_SECONDS ) );
            }
            unset( $row['_order_ids'], $row['_failed_order_ids'] );
        }
        unset( $row );
        $rows = array_values( $rows );
        usort( $rows, static function ( $a, $b ) { return $b['sales'] <=> $a['sales']; } );
        return self::set_cached( 'products', $start, $end, $filters, array(
            'rows' => $rows,
            'by_qty' => array_values( array_slice( self::sorted_copy( $rows, 'qty' ), 0, 20 ) ),
            'by_sales' => array_values( array_slice( $rows, 0, 20 ) ),
            'money' => self::money_meta(),
            'meta' => array( 'truncated' => $paid['truncated'] || $failed['truncated'], 'date_type' => HGR_Reference::date_type(), 'sales_basis' => 'parent-order cohort; refund amounts attached to parent orders', 'cost_basis' => 'historical order-item COGS first, current product cost only fallback' ),
        ) );
    }

    private static function sorted_copy( $rows, $key ) {
        usort( $rows, static function ( $a, $b ) use ( $key ) { return ( $b[ $key ] ?? 0 ) <=> ( $a[ $key ] ?? 0 ); } );
        return $rows;
    }

    public static function categories( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'categories', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $rows = array();
        $total_sales = 0;
        foreach ( $q['orders'] as $order ) {
            foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
                $pid = $item->get_product_id();
                $term = self::primary_category( $pid );
                $key = $term ? $term->term_id : 0;
                $name = $term ? $term->name : 'بدون دسته';
                if ( ! isset( $rows[ $key ] ) ) {
                    $rows[ $key ] = array( 'id' => $key, 'name' => $name, 'orders' => array(), 'qty' => 0, 'sales' => 0, 'customers' => array() );
                }
                $qty = max( 0, (float) $item->get_quantity() + (float) $order->get_qty_refunded_for_item( $item_id ) );
                $sales = max( 0, (float) $item->get_total() - abs( (float) $order->get_total_refunded_for_item( $item_id ) ) );
                $rows[ $key ]['orders'][ $order->get_id() ] = true;
                $rows[ $key ]['customers'][ self::customer_key( $order ) ] = true;
                $rows[ $key ]['qty'] += $qty;
                $rows[ $key ]['sales'] += $sales;
                $total_sales += $sales;
            }
        }
        foreach ( $rows as &$row ) {
            $row['orders'] = count( $row['orders'] );
            $row['customers'] = count( $row['customers'] );
            $row['share'] = $total_sales > 0 ? 100 * $row['sales'] / $total_sales : 0;
            $row['aov'] = $row['orders'] ? $row['sales'] / $row['orders'] : 0;
        }
        unset( $row );
        $rows = self::sorted_copy( array_values( $rows ), 'sales' );
        return self::set_cached( 'categories', $start, $end, $filters, array(
            'rows' => $rows,
            'total_sales' => $total_sales,
            'money' => self::money_meta(),
            'meta' => array(
                'truncated' => $q['truncated'],
                'date_type' => HGR_Reference::date_type(),
                'sales_basis' => 'management attribution: each product is assigned to one primary/deepest category to avoid double counting; refunds are attached to parent-order cohorts',
                'canonical_kpi' => false,
            ),
        ) );
    }

    public static function brands( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'brands', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $tax = self::brand_taxonomy();
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $rows = array();
        $total_sales = 0;
        $lifetime = self::lifetime_customer_map( $end );
        foreach ( $q['orders'] as $order ) {
            foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
                $pid = $item->get_product_id();
                $term = $tax ? self::product_brand( $pid ) : null;
                $key = $term ? $term->term_id : 0;
                $name = $term ? $term->name : 'بدون برند';
                if ( ! isset( $rows[ $key ] ) ) {
                    $rows[ $key ] = array( 'id' => $key, 'name' => $name, 'orders' => array(), 'qty' => 0, 'sales' => 0, 'refunds' => 0, 'customers' => array(), 'repeat_customers' => array(), 'cost' => 0, 'cost_known_qty' => 0, 'qty_total' => 0 );
                }
                $qty = max( 0, (float) $item->get_quantity() + (float) $order->get_qty_refunded_for_item( $item_id ) );
                $refund = abs( (float) $order->get_total_refunded_for_item( $item_id ) );
                $sales = max( 0, (float) $item->get_total() - $refund );
                $ck = self::customer_key( $order );
                $rows[ $key ]['orders'][ $order->get_id() ] = true;
                $rows[ $key ]['customers'][ $ck ] = true;
                if ( 'returning' === self::period_customer_type( $ck, $lifetime, $start ) ) $rows[ $key ]['repeat_customers'][ $ck ] = true;
                $rows[ $key ]['qty'] += $qty;
                $rows[ $key ]['qty_total'] += $qty;
                $rows[ $key ]['sales'] += $sales;
                $rows[ $key ]['refunds'] += $refund;
                $ci = self::order_item_cost( $item, $item->get_product() );
                if ( null !== $ci['cost'] ) {
                    $orig_qty = max( 0.0, (float) $item->get_quantity() );
                    $item_cost = (float) $ci['cost'];
                    if ( $orig_qty > 0 && $qty < $orig_qty ) $item_cost *= ( $qty / $orig_qty );
                    $rows[ $key ]['cost'] += $item_cost;
                    $rows[ $key ]['cost_known_qty'] += $qty;
                }
                $total_sales += $sales;
            }
        }
        foreach ( $rows as &$row ) {
            $row['orders'] = count( $row['orders'] );
            $row['customers'] = count( $row['customers'] );
            $row['repeat_customers'] = count( $row['repeat_customers'] );
            $row['aov'] = $row['orders'] ? $row['sales'] / $row['orders'] : 0;
            $row['share'] = $total_sales > 0 ? 100 * $row['sales'] / $total_sales : 0;
            $row['profit'] = $row['cost_known_qty'] > 0 ? $row['sales'] - $row['cost'] : null;
            $row['margin'] = null !== $row['profit'] && $row['sales'] > 0 ? 100 * $row['profit'] / $row['sales'] : null;
            $row['cost_coverage'] = $row['qty_total'] > 0 ? 100 * $row['cost_known_qty'] / $row['qty_total'] : 0;
        }
        unset( $row );
        $rows = self::sorted_copy( array_values( $rows ), 'sales' );
        return self::set_cached( 'brands', $start, $end, $filters, array( 'rows' => $rows, 'taxonomy' => $tax, 'total_sales' => $total_sales, 'money' => self::money_meta(), 'meta' => array( 'truncated' => $q['truncated'] || $lifetime['truncated'], 'date_type' => HGR_Reference::date_type(), 'sales_basis' => 'management attribution: item cohort by configured brand taxonomy; refunds are attached to parent-order cohorts', 'cost_basis' => 'historical order-item COGS first', 'canonical_kpi' => false ) ) );
    }

    private static function period_customer_type( $customer_key, $lifetime, $start ) {
        if ( ! isset( $lifetime['map'][ $customer_key ] ) || empty( $lifetime['map'][ $customer_key ]['first'] ) ) {
            return 'unknown';
        }
        return substr( (string) $lifetime['map'][ $customer_key ]['first'], 0, 10 ) < $start ? 'returning' : 'new';
    }

    private static function segment_for( $life, $end ) {
        $vip = (float) get_option( 'hgr_vip_threshold', 10000000 );
        $risk_days = max( 1, (int) get_option( 'hgr_risk_days', 60 ) );
        $lost_days = max( $risk_days + 1, (int) get_option( 'hgr_lost_days', 180 ) );
        $last_ts = ! empty( $life['last'] ) ? strtotime( $life['last'] ) : 0;
        $end_ts = strtotime( $end . ' 23:59:59' );
        $days = $last_ts ? max( 0, floor( ( $end_ts - $last_ts ) / DAY_IN_SECONDS ) ) : 99999;
        if ( $life['spent'] >= $vip ) return 'VIP';
        if ( $days >= $lost_days ) return 'از دست رفته';
        if ( $days >= $risk_days ) return 'در خطر ریزش';
        if ( $life['orders'] >= 3 ) return 'وفادار';
        if ( 1 === (int) $life['orders'] ) return 'یک‌بار خرید';
        return 'فعال';
    }

    public static function customers( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'customers', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $paid = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $failed = self::query_orders( $start, $end, self::failed_statuses(), $filters );
        $lifetime = self::lifetime_customer_map( $end );
        $rows = array();
        foreach ( $paid['orders'] as $order ) {
            $ck = self::customer_key( $order );
            if ( ! isset( $rows[ $ck ] ) ) {
                $loc = self::city_data( $order );
                $rows[ $ck ] = array(
                    'key' => $ck, 'name' => self::customer_name( $order ), 'phone' => $order->get_billing_phone(), 'email' => $order->get_billing_email(),
                    'city' => $loc['city'], 'state' => $loc['state'], 'orders' => 0, 'spent' => 0, 'items' => 0, 'refunds' => 0,
                    'cancelled' => 0, 'failed' => 0, 'coupons' => array(), 'products' => array(), 'categories' => array(),
                );
            }
            $rows[ $ck ]['orders']++;
            $rows[ $ck ]['spent'] += self::order_net( $order );
            $rows[ $ck ]['items'] += self::order_item_qty( $order );
            $rows[ $ck ]['refunds'] += (float) $order->get_total_refunded();
            foreach ( $order->get_coupon_codes() as $code ) $rows[ $ck ]['coupons'][ $code ] = true;
            foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
                $name = $item->get_name();
                if ( ! isset( $rows[ $ck ]['products'][ $name ] ) ) $rows[ $ck ]['products'][ $name ] = 0;
                $rows[ $ck ]['products'][ $name ] += max( 0, (float) $item->get_quantity() + (float) $order->get_qty_refunded_for_item( $item_id ) );
                $term = self::primary_category( $item->get_product_id() );
                if ( $term ) {
                    if ( ! isset( $rows[ $ck ]['categories'][ $term->name ] ) ) $rows[ $ck ]['categories'][ $term->name ] = 0;
                    $rows[ $ck ]['categories'][ $term->name ] += (float) $item->get_quantity();
                }
            }
        }
        foreach ( $failed['orders'] as $order ) {
            $ck = self::customer_key( $order );
            if ( ! isset( $rows[ $ck ] ) ) {
                $loc = self::city_data( $order );
                $rows[ $ck ] = array(
                    'key' => $ck, 'name' => self::customer_name( $order ), 'phone' => $order->get_billing_phone(), 'email' => $order->get_billing_email(),
                    'city' => $loc['city'], 'state' => $loc['state'], 'orders' => 0, 'spent' => 0, 'items' => 0, 'refunds' => 0,
                    'cancelled' => 0, 'failed' => 0, 'coupons' => array(), 'products' => array(), 'categories' => array(),
                );
            }
            if ( 'cancelled' === $order->get_status() ) $rows[ $ck ]['cancelled']++;
            if ( 'failed' === $order->get_status() ) $rows[ $ck ]['failed']++;
        }
        $segments = array();
        foreach ( $rows as &$row ) {
            $life = isset( $lifetime['map'][ $row['key'] ] ) ? $lifetime['map'][ $row['key'] ] : array( 'orders' => $row['orders'], 'spent' => $row['spent'], 'first' => '', 'last' => '', 'dates' => array() );
            $row['lifetime_orders'] = $life['orders'];
            $row['lifetime_spent'] = $life['spent'];
            $row['first_date'] = $life['first'];
            $row['first_date_j'] = HGR_Jalali::format_gregorian( $life['first'], true );
            $row['last_date'] = $life['last'];
            $row['last_date_j'] = HGR_Jalali::format_gregorian( $life['last'], true );
            $row['aov'] = $row['orders'] ? $row['spent'] / $row['orders'] : 0;
            arsort( $row['products'] );
            arsort( $row['categories'] );
            $row['favorite_products'] = implode( '، ', array_slice( array_keys( $row['products'] ), 0, 3 ) );
            $row['favorite_categories'] = implode( '، ', array_slice( array_keys( $row['categories'] ), 0, 2 ) );
            $row['coupons'] = implode( '، ', array_keys( $row['coupons'] ) );
            $row['segment'] = self::segment_for( $life, $end );
            if ( ! isset( $segments[ $row['segment'] ] ) ) $segments[ $row['segment'] ] = 0;
            $segments[ $row['segment'] ]++;
            unset( $row['products'], $row['categories'], $row['key'] );
        }
        unset( $row );
        if ( ! empty( $filters['customer_segment'] ) ) {
            $rows = array_values( array_filter( $rows, static function ( $r ) use ( $filters ) { return $r['segment'] === $filters['customer_segment']; } ) );
        } else {
            $rows = array_values( $rows );
        }
        usort( $rows, static function ( $a, $b ) { return $b['lifetime_spent'] <=> $a['lifetime_spent']; } );
        return self::set_cached( 'customers', $start, $end, $filters, array(
            'rows' => $rows,
            'segments' => $segments,
            'money' => self::money_meta(),
            'meta' => array( 'truncated' => $paid['truncated'] || $failed['truncated'] || $lifetime['truncated'] ),
        ) );
    }

    public static function retention( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'retention', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $life = self::lifetime_customer_map( $end, true );
        $total = count( $life['map'] );
        $second = $third = $fourth = 0;
        $first_to_second_sum = 0;
        $first_to_second_n = 0;
        $interval_sum = 0;
        $interval_n = 0;
        foreach ( $life['map'] as $row ) {
            if ( $row['orders'] >= 2 ) $second++;
            if ( $row['orders'] >= 3 ) $third++;
            if ( $row['orders'] >= 4 ) $fourth++;
            $dates = $row['dates'];
            if ( count( $dates ) >= 2 ) {
                $t0 = strtotime( $dates[0] );
                $t1 = strtotime( $dates[1] );
                if ( $t0 && $t1 ) {
                    $first_to_second_sum += ( $t1 - $t0 ) / DAY_IN_SECONDS;
                    $first_to_second_n++;
                }
                for ( $i = 1; $i < count( $dates ); $i++ ) {
                    $a = strtotime( $dates[ $i - 1 ] );
                    $b = strtotime( $dates[ $i ] );
                    if ( $a && $b ) {
                        $interval_sum += ( $b - $a ) / DAY_IN_SECONDS;
                        $interval_n++;
                    }
                }
            }
        }
        $period_customers = self::customers( $start, $end, $filters );
        $period_total = count( $period_customers['rows'] );
        $period_repeat = 0;
        foreach ( $period_customers['rows'] as $row ) if ( $row['lifetime_orders'] >= 2 ) $period_repeat++;
        return self::set_cached( 'retention', $start, $end, $filters, array(
            'lifetime_customers' => $total,
            'second_purchase' => $second,
            'third_purchase' => $third,
            'fourth_purchase' => $fourth,
            'second_rate' => $total ? 100 * $second / $total : 0,
            'third_rate' => $total ? 100 * $third / $total : 0,
            'fourth_rate' => $total ? 100 * $fourth / $total : 0,
            'avg_days_first_to_second' => $first_to_second_n ? $first_to_second_sum / $first_to_second_n : null,
            'avg_days_between_orders' => $interval_n ? $interval_sum / $interval_n : null,
            'period_customers' => $period_total,
            'period_repeat_customers' => $period_repeat,
            'period_repeat_rate' => $period_total ? 100 * $period_repeat / $period_total : 0,
            'segments' => $period_customers['segments'],
            'meta' => array( 'truncated' => $life['truncated'] || $period_customers['meta']['truncated'] ),
        ) );
    }

    public static function geography( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'geography', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $rows = array();
        $shiraz = array( 'orders' => 0, 'sales' => 0 );
        $other = array( 'orders' => 0, 'sales' => 0 );
        foreach ( $q['orders'] as $order ) {
            $loc = self::city_data( $order );
            $key = $loc['state'] . '|' . $loc['city'];
            if ( ! isset( $rows[ $key ] ) ) $rows[ $key ] = array( 'state' => $loc['state'], 'city' => $loc['city'], 'orders' => 0, 'sales' => 0, 'customers' => array() );
            $sales = self::order_net( $order );
            $rows[ $key ]['orders']++;
            $rows[ $key ]['sales'] += $sales;
            $rows[ $key ]['customers'][ self::customer_key( $order ) ] = true;
            $city_normalized = str_replace( array( 'ي', 'ك' ), array( 'ی', 'ک' ), $loc['city'] );
            if ( false !== self::ipos( $city_normalized, 'شیراز' ) ) {
                $shiraz['orders']++;
                $shiraz['sales'] += $sales;
            } else {
                $other['orders']++;
                $other['sales'] += $sales;
            }
        }
        foreach ( $rows as &$row ) {
            $row['customers'] = count( $row['customers'] );
            $row['aov'] = $row['orders'] ? $row['sales'] / $row['orders'] : 0;
        }
        unset( $row );
        foreach ( array( 'shiraz', 'other' ) as $dummy ) {}
        $shiraz['aov'] = $shiraz['orders'] ? $shiraz['sales'] / $shiraz['orders'] : 0;
        $other['aov'] = $other['orders'] ? $other['sales'] / $other['orders'] : 0;
        $rows = self::sorted_copy( array_values( $rows ), 'sales' );
        return self::set_cached( 'geography', $start, $end, $filters, array( 'rows' => $rows, 'shiraz' => $shiraz, 'other' => $other, 'money' => self::money_meta(), 'meta' => array( 'truncated' => $q['truncated'] ) ) );
    }

    public static function channels( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'channels', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $paid = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $failed = self::query_orders( $start, $end, self::failed_statuses(), $filters );
        $life = self::lifetime_customer_map( $end );
        $payments = array();
        $shipping = array();
        $all_payment_failed = array();
        foreach ( $paid['orders'] as $order ) {
            $pk = $order->get_payment_method() ?: 'unknown';
            if ( ! isset( $payments[ $pk ] ) ) $payments[ $pk ] = array( 'method' => $pk, 'title' => $order->get_payment_method_title() ?: 'نامشخص', 'orders' => 0, 'sales' => 0, 'refunds' => 0, 'new_customers' => array(), 'repeat_customers' => array(), 'failed' => 0, 'cancelled' => 0 );
            $payments[ $pk ]['orders']++;
            $payments[ $pk ]['sales'] += (float) $order->get_total();
            $payments[ $pk ]['refunds'] += (float) $order->get_total_refunded();
            $ck = self::customer_key( $order );
            if ( isset( $life['map'][ $ck ] ) && $life['map'][ $ck ]['orders'] > 1 ) $payments[ $pk ]['repeat_customers'][ $ck ] = true;
            else $payments[ $pk ]['new_customers'][ $ck ] = true;
            $sk = self::shipping_method( $order );
            if ( ! isset( $shipping[ $sk ] ) ) $shipping[ $sk ] = array( 'title' => $sk, 'orders' => 0, 'sales' => 0, 'refunds' => 0, 'cancelled' => 0, 'failed' => 0 );
            $shipping[ $sk ]['orders']++;
            $shipping[ $sk ]['sales'] += (float) $order->get_total();
            $shipping[ $sk ]['refunds'] += (float) $order->get_total_refunded();
        }
        foreach ( $failed['orders'] as $order ) {
            $pk = $order->get_payment_method() ?: 'unknown';
            if ( ! isset( $payments[ $pk ] ) ) $payments[ $pk ] = array( 'method' => $pk, 'title' => $order->get_payment_method_title() ?: 'نامشخص', 'orders' => 0, 'sales' => 0, 'refunds' => 0, 'new_customers' => array(), 'repeat_customers' => array(), 'failed' => 0, 'cancelled' => 0 );
            $payments[ $pk ][ 'failed' === $order->get_status() ? 'failed' : 'cancelled' ]++;
            $sk = self::shipping_method( $order );
            if ( ! isset( $shipping[ $sk ] ) ) $shipping[ $sk ] = array( 'title' => $sk, 'orders' => 0, 'sales' => 0, 'refunds' => 0, 'cancelled' => 0, 'failed' => 0 );
            $shipping[ $sk ][ 'failed' === $order->get_status() ? 'failed' : 'cancelled' ]++;
            $all_payment_failed[ $pk ] = true;
        }
        foreach ( $payments as &$row ) {
            $row['net'] = max( 0, $row['sales'] - $row['refunds'] );
            $row['aov'] = $row['orders'] ? $row['net'] / $row['orders'] : 0;
            $row['new_customers'] = count( $row['new_customers'] );
            $row['repeat_customers'] = count( $row['repeat_customers'] );
            $den = $row['orders'] + $row['failed'] + $row['cancelled'];
            $row['failure_rate'] = $den ? 100 * ( $row['failed'] + $row['cancelled'] ) / $den : 0;
        }
        unset( $row );
        foreach ( $shipping as &$row ) {
            $row['net'] = max( 0, $row['sales'] - $row['refunds'] );
            $row['aov'] = $row['orders'] ? $row['net'] / $row['orders'] : 0;
        }
        unset( $row );
        return self::set_cached( 'channels', $start, $end, $filters, array(
            'payments' => self::sorted_copy( array_values( $payments ), 'net' ),
            'shipping' => self::sorted_copy( array_values( $shipping ), 'net' ),
            'money' => self::money_meta(),
            'meta' => array( 'truncated' => $paid['truncated'] || $failed['truncated'] || $life['truncated'] ),
        ) );
    }

    public static function cancellations( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'cancellations', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $fail_filters = $filters;
        unset( $fail_filters['statuses'] );
        $failed = self::query_orders( $start, $end, self::failed_statuses(), $fail_filters );
        $all = self::query_orders( $start, $end, self::all_statuses(), $fail_filters, self::MAX_ORDERS, 'date_created' );
        $life = self::lifetime_customer_map( $end );
        $rows = array();
        $reasons = array();
        $status_counts = array( 'cancelled' => 0, 'failed' => 0 );
        $total_value = 0;
        foreach ( $failed['orders'] as $order ) {
            $reason = trim( (string) $order->get_meta( '_hgr_cancel_reason', true ) );
            if ( ! $reason ) $reason = 'ثبت نشده';
            if ( ! isset( $reasons[ $reason ] ) ) $reasons[ $reason ] = array( 'reason' => $reason, 'count' => 0, 'value' => 0 );
            $reasons[ $reason ]['count']++;
            $reasons[ $reason ]['value'] += (float) $order->get_total();
            $status = $order->get_status();
            if ( isset( $status_counts[ $status ] ) ) $status_counts[ $status ]++;
            $total_value += (float) $order->get_total();
            $loc = self::city_data( $order );
            $ck = self::customer_key( $order );
            $products = array();
            foreach ( $order->get_items( 'line_item' ) as $item ) $products[] = $item->get_name() . ' × ' . $item->get_quantity();
            $date = $order->get_date_created() ? $order->get_date_created()->date_i18n( 'Y-m-d H:i' ) : '';
            $modified = $order->get_date_modified() ? $order->get_date_modified()->date_i18n( 'Y-m-d H:i' ) : '';
            $rows[] = array(
                'id' => $order->get_id(),
                'date' => $date,
                'date_j' => HGR_Jalali::format_gregorian( $date, true ),
                'modified' => $modified,
                'modified_j' => HGR_Jalali::format_gregorian( $modified, true ),
                'name' => self::customer_name( $order ),
                'phone' => $order->get_billing_phone(),
                'email' => $order->get_billing_email(),
                'city' => $loc['city'],
                'state' => $loc['state'],
                'total' => (float) $order->get_total(),
                'status' => $status,
                'payment' => $order->get_payment_method_title() ?: 'نامشخص',
                'payment_id' => $order->get_payment_method(),
                'products' => implode( '، ', $products ),
                'reason' => $reason,
                'customer_type' => isset( $life['map'][ $ck ] ) && $life['map'][ $ck ]['orders'] > 1 ? 'مشتری قبلی' : 'مشتری جدید/بدون خرید موفق',
                'edit_url' => $order->get_edit_order_url(),
            );
        }
        $reason_rows = array_values( $reasons );
        usort( $reason_rows, static function ( $a, $b ) { return $b['count'] <=> $a['count']; } );
        $den = count( $all['orders'] );
        return self::set_cached( 'cancellations', $start, $end, $filters, array(
            'rows' => $rows,
            'reasons' => $reason_rows,
            'cancelled' => $status_counts['cancelled'],
            'failed' => $status_counts['failed'],
            'count' => count( $rows ),
            'value' => $total_value,
            'cancellation_rate' => $den ? 100 * $status_counts['cancelled'] / $den : 0,
            'failure_rate' => $den ? 100 * $status_counts['failed'] / $den : 0,
            'money' => self::money_meta(),
            'meta' => array( 'truncated' => $failed['truncated'] || $all['truncated'] || $life['truncated'] ),
        ) );
    }

    public static function funnel( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'funnel', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $q = self::query_orders( $start, $end, self::all_statuses(), $filters, self::MAX_ORDERS, 'date_created' );
        $statuses = array();
        $created_orders = 0;
        foreach ( $q['orders'] as $order ) {
            $status = $order->get_status();
            if ( ! isset( $statuses[ $status ] ) ) $statuses[ $status ] = array( 'status' => $status, 'count' => 0, 'value' => 0 );
            $statuses[ $status ]['count']++;
            $statuses[ $status ]['value'] += (float) $order->get_total();
            $created_orders++;
        }
        global $wpdb;
        $cart_table = HGR_Tracker::cart_table();
        $minutes = max( 15, (int) get_option( 'hgr_abandoned_minutes', 60 ) );
        $start_dt = $start . ' 00:00:00';
        $end_dt = $end . ' 23:59:59';
        $cutoff = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp', true ) - $minutes * MINUTE_IN_SECONDS );
        $cart_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$cart_table} WHERE first_seen BETWEEN %s AND %s ORDER BY first_seen DESC LIMIT 10000",
            $start_dt,
            $end_dt
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $carts = 0;
        $converted = 0;
        $abandoned = 0;
        $abandoned_value = 0;
        $active = 0;
        foreach ( $cart_rows as $row ) {
            if ( (int) $row['item_count'] <= 0 ) continue;
            $carts++;
            if ( (int) $row['converted_order_id'] > 0 ) {
                $converted++;
            } elseif ( $row['last_seen'] <= $cutoff ) {
                $abandoned++;
                $abandoned_value += (float) $row['cart_total'];
            } else {
                $active++;
            }
        }
        return self::set_cached( 'funnel', $start, $end, $filters, array(
            'statuses' => array_values( $statuses ),
            'orders_created' => $created_orders,
            'carts_tracked' => $carts,
            'carts_converted' => $converted,
            'carts_abandoned' => $abandoned,
            'carts_active' => $active,
            'abandoned_value' => $abandoned_value,
            'cart_conversion_rate' => $carts ? 100 * $converted / $carts : 0,
            'tracking_started_at' => get_option( 'hgr_tracking_started_at', '' ),
            'abandoned_minutes' => $minutes,
            'money' => self::money_meta(),
            'meta' => array( 'truncated' => $q['truncated'], 'cart_limit' => count( $cart_rows ) >= 10000 ),
        ) );
    }

    public static function coupons( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'coupons', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $life = self::lifetime_customer_map( $end );
        $rows = array();
        foreach ( $q['orders'] as $order ) {
            $codes = $order->get_coupon_codes();
            if ( ! $codes ) continue;
            foreach ( $codes as $code ) {
                $code = strtolower( $code );
                if ( ! isset( $rows[ $code ] ) ) $rows[ $code ] = array( 'code' => $code, 'orders' => 0, 'sales' => 0, 'discount' => 0, 'new_customers' => array(), 'repeat_customers' => array(), 'products' => array() );
                $rows[ $code ]['orders']++;
                $rows[ $code ]['sales'] += self::order_net( $order );
                $rows[ $code ]['discount'] += (float) $order->get_discount_total();
                $ck = self::customer_key( $order );
                if ( isset( $life['map'][ $ck ] ) && $life['map'][ $ck ]['orders'] > 1 ) $rows[ $code ]['repeat_customers'][ $ck ] = true;
                else $rows[ $code ]['new_customers'][ $ck ] = true;
                foreach ( $order->get_items( 'line_item' ) as $item ) {
                    $name = $item->get_name();
                    if ( ! isset( $rows[ $code ]['products'][ $name ] ) ) $rows[ $code ]['products'][ $name ] = 0;
                    $rows[ $code ]['products'][ $name ] += (float) $item->get_quantity();
                }
            }
        }
        foreach ( $rows as &$row ) {
            $row['aov'] = $row['orders'] ? $row['sales'] / $row['orders'] : 0;
            $row['new_customers'] = count( $row['new_customers'] );
            $row['repeat_customers'] = count( $row['repeat_customers'] );
            arsort( $row['products'] );
            $row['top_products'] = implode( '، ', array_slice( array_keys( $row['products'] ), 0, 4 ) );
            unset( $row['products'] );
        }
        unset( $row );
        $rows = self::sorted_copy( array_values( $rows ), 'sales' );
        return self::set_cached( 'coupons', $start, $end, $filters, array( 'rows' => $rows, 'money' => self::money_meta(), 'meta' => array( 'truncated' => $q['truncated'] || $life['truncated'] ) ) );
    }

    public static function bundles( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'bundles', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $pairs = array();
        $product_orders = array();
        foreach ( $q['orders'] as $order ) {
            $products = array();
            foreach ( $order->get_items( 'line_item' ) as $item ) {
                $pid = $item->get_variation_id() ?: $item->get_product_id();
                $products[ $pid ] = $item->get_name();
                if ( ! isset( $product_orders[ $pid ] ) ) $product_orders[ $pid ] = 0;
            }
            $ids = array_keys( $products );
            foreach ( $ids as $pid ) $product_orders[ $pid ]++;
            $n = count( $ids );
            for ( $i = 0; $i < $n; $i++ ) {
                for ( $j = $i + 1; $j < $n; $j++ ) {
                    $a = min( $ids[ $i ], $ids[ $j ] );
                    $b = max( $ids[ $i ], $ids[ $j ] );
                    $key = $a . ':' . $b;
                    if ( ! isset( $pairs[ $key ] ) ) $pairs[ $key ] = array( 'product_a_id' => $a, 'product_b_id' => $b, 'product_a' => $products[ $a ], 'product_b' => $products[ $b ], 'orders' => 0 );
                    $pairs[ $key ]['orders']++;
                }
            }
        }
        foreach ( $pairs as &$row ) {
            $base = min( isset( $product_orders[ $row['product_a_id'] ] ) ? $product_orders[ $row['product_a_id'] ] : 0, isset( $product_orders[ $row['product_b_id'] ] ) ? $product_orders[ $row['product_b_id'] ] : 0 );
            $row['support'] = count( $q['orders'] ) ? 100 * $row['orders'] / count( $q['orders'] ) : 0;
            $row['affinity'] = $base ? 100 * $row['orders'] / $base : 0;
        }
        unset( $row );
        $rows = self::sorted_copy( array_values( $pairs ), 'orders' );
        return self::set_cached( 'bundles', $start, $end, $filters, array( 'rows' => array_slice( $rows, 0, 200 ), 'meta' => array( 'truncated' => $q['truncated'] ) ) );
    }

    public static function attribution( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'attribution', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $q = self::query_orders( $start, $end, self::paid_statuses(), $filters );
        $sources = array();
        $campaigns = array();
        $devices = array();
        foreach ( $q['orders'] as $order ) {
            $source = self::attribution_source( $order );
            $medium = trim( (string) $order->get_meta( '_wc_order_attribution_utm_medium', true ) );
            $campaign = trim( (string) $order->get_meta( '_wc_order_attribution_utm_campaign', true ) );
            $device = self::attribution_device( $order );
            if ( ! isset( $sources[ $source ] ) ) $sources[ $source ] = array( 'source' => $source, 'orders' => 0, 'sales' => 0, 'mediums' => array() );
            $sources[ $source ]['orders']++;
            $sources[ $source ]['sales'] += self::order_net( $order );
            if ( $medium ) $sources[ $source ]['mediums'][ $medium ] = true;
            $ckey = $campaign ?: '(بدون کمپین)';
            if ( ! isset( $campaigns[ $ckey ] ) ) $campaigns[ $ckey ] = array( 'campaign' => $ckey, 'orders' => 0, 'sales' => 0 );
            $campaigns[ $ckey ]['orders']++;
            $campaigns[ $ckey ]['sales'] += self::order_net( $order );
            if ( ! isset( $devices[ $device ] ) ) $devices[ $device ] = array( 'device' => $device, 'orders' => 0, 'sales' => 0 );
            $devices[ $device ]['orders']++;
            $devices[ $device ]['sales'] += self::order_net( $order );
        }
        foreach ( $sources as &$row ) {
            $row['aov'] = $row['orders'] ? $row['sales'] / $row['orders'] : 0;
            $row['mediums'] = implode( '، ', array_keys( $row['mediums'] ) );
        }
        unset( $row );
        foreach ( $campaigns as &$row ) $row['aov'] = $row['orders'] ? $row['sales'] / $row['orders'] : 0;
        unset( $row );
        foreach ( $devices as &$row ) $row['aov'] = $row['orders'] ? $row['sales'] / $row['orders'] : 0;
        unset( $row );
        return self::set_cached( 'attribution', $start, $end, $filters, array(
            'sources' => self::sorted_copy( array_values( $sources ), 'sales' ),
            'campaigns' => self::sorted_copy( array_values( $campaigns ), 'sales' ),
            'devices' => self::sorted_copy( array_values( $devices ), 'sales' ),
            'money' => self::money_meta(),
            'note' => 'منبع/دستگاه فقط برای سفارش‌هایی دقیق است که WooCommerce Order Attribution آن را ثبت کرده باشد.',
            'meta' => array( 'truncated' => $q['truncated'] ),
        ) );
    }

    public static function profit( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'profit', $start, $end, $filters );
        if ( false !== $cached ) return $cached;

        // Headline profit is calculated by the event-period ledger so refunds
        // affect the period in which the refund happened. Product allocation is
        // supplemental and may be unavailable for manual refunds without lines.
        $metrics = self::profit_metrics( $start, $end, $filters, HGR_Reference::supports_filters( $filters ) );
        $products = self::products( $start, $end, $filters );
        $rows = array_values( array_filter( $products['rows'], static function( $row ){ return null !== ($row['profit']??null); } ) );
        usort( $rows, static function ( $a, $b ) { return $b['profit'] <=> $a['profit']; } );

        return self::set_cached( 'profit', $start, $end, $filters, array(
            'rows'=>$rows,
            'sales'=>(float)$metrics['merch_revenue'],
            'known_sales'=>(float)$metrics['coverage_known'],
            'cost'=>(float)$metrics['net_cogs'],
            'profit'=>$metrics['profit'],
            'margin'=>$metrics['margin'],
            'coverage'=>$metrics['cost_coverage'],
            'historical_coverage'=>$metrics['historical_cogs_coverage'],
            'cost_source'=>self::native_cogs_enabled() ? 'WooCommerce historical order-item COGS; current cost only fallback' : ( get_option( 'hgr_cost_meta_key', '' ) ?: 'Custom cost meta; without historical COGS old profit is approximate' ),
            'money'=>self::money_meta(),
            'meta'=>array_merge($products['meta'],array(
                'truncated'=>!empty($products['meta']['truncated'])||!empty($metrics['truncated']),
                'headline_basis'=>'refund-event-period + historical order-item COGS',
                'product_allocation_basis'=>'supplemental parent-order/product allocation; manual refunds without line items cannot be allocated to a product',
                'historical_cogs_coverage'=>$metrics['historical_cogs_coverage'],
            )),
        ) );
    }

    private static function tracked_out_days( $product_id, $start, $end ) {
        global $wpdb;
        $table = HGR_Tracker::stock_table();
        $events = $wpdb->get_results( $wpdb->prepare(
            "SELECT stock_status, happened_at FROM {$table} WHERE product_id=%d AND happened_at <= %s ORDER BY happened_at ASC",
            $product_id,
            $end . ' 23:59:59'
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $events ) return null;
        $start_ts = strtotime( $start . ' 00:00:00' );
        $end_ts = strtotime( $end . ' 23:59:59' );
        $state = null;
        $cursor = $start_ts;
        $out_seconds = 0;
        foreach ( $events as $event ) {
            $ts = strtotime( $event['happened_at'] );
            if ( $ts < $start_ts ) {
                $state = $event['stock_status'];
                continue;
            }
            if ( $ts > $end_ts ) break;
            if ( 'outofstock' === $state ) $out_seconds += max( 0, $ts - $cursor );
            $cursor = max( $cursor, $ts );
            $state = $event['stock_status'];
        }
        if ( 'outofstock' === $state ) $out_seconds += max( 0, $end_ts - $cursor );
        return round( $out_seconds / DAY_IN_SECONDS, 2 );
    }

    public static function inventory( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'inventory', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $sales_report = self::products( $start, $end, $filters );
        $sold = array();
        foreach ( $sales_report['rows'] as $row ) $sold[ $row['id'] ] = $row;
        $products = array();
        $page = 1;
        do {
            $batch = wc_get_products( array( 'status' => array( 'publish', 'private' ), 'limit' => 250, 'page' => $page, 'paginate' => true, 'orderby' => 'title', 'order' => 'ASC', 'return' => 'objects' ) );
            if ( empty( $batch->products ) ) break;
            foreach ( $batch->products as $p ) if ( $p instanceof WC_Product ) $products[ $p->get_id() ] = $p;
            $page++;
        } while ( $page <= (int) $batch->max_num_pages && count( $products ) < 10000 );
        $vpage = 1;
        do {
            $batch = wc_get_products( array( 'type' => 'variation', 'status' => array( 'publish', 'private' ), 'limit' => 250, 'page' => $vpage, 'paginate' => true, 'return' => 'objects' ) );
            if ( empty( $batch->products ) ) break;
            foreach ( $batch->products as $p ) if ( $p instanceof WC_Product ) $products[ $p->get_id() ] = $p;
            $vpage++;
        } while ( $vpage <= (int) $batch->max_num_pages && count( $products ) < 15000 );
        $days = max( 1, (int) ( ( strtotime( $end ) - strtotime( $start ) ) / DAY_IN_SECONDS ) + 1 );
        $global_low = (int) get_option( 'woocommerce_notify_low_stock_amount', 2 );
        $rows = array();
        foreach ( $products as $product ) {
            $id = $product->get_id();
            $s = isset( $sold[ $id ] ) ? $sold[ $id ] : null;
            $qty_sold = $s ? $s['qty'] : 0;
            $stock_qty = $product->managing_stock() ? $product->get_stock_quantity() : null;
            $low = $product->get_low_stock_amount();
            if ( '' === $low || null === $low ) $low = $global_low;
            $out_days = self::tracked_out_days( $id, $start, $end );
            $avg_daily = $qty_sold / $days;
            $lost_qty = null !== $out_days ? $avg_daily * $out_days : null;
            $avg_price = $s && $s['qty'] > 0 ? $s['sales'] / $s['qty'] : 0;
            $rows[] = array(
                'id' => $id,
                'name' => $product->get_name(),
                'sku' => $product->get_sku(),
                'type' => $product->get_type(),
                'sold' => $qty_sold,
                'sales' => $s ? $s['sales'] : 0,
                'stock_status' => $product->get_stock_status(),
                'stock_qty' => $stock_qty,
                'low_amount' => (int) $low,
                'is_out' => 'outofstock' === $product->get_stock_status(),
                'is_low' => null !== $stock_qty && $stock_qty <= (int) $low,
                'no_sale' => 'instock' === $product->get_stock_status() && $qty_sold <= 0,
                'avg_daily_qty' => $avg_daily,
                'out_days_tracked' => $out_days,
                'lost_qty_estimate' => $lost_qty,
                'lost_sales_estimate' => null !== $lost_qty ? $lost_qty * $avg_price : null,
                'edit_url' => get_edit_post_link( $id, '' ),
            );
        }
        usort( $rows, static function ( $a, $b ) {
            if ( $a['is_out'] !== $b['is_out'] ) return $a['is_out'] ? -1 : 1;
            if ( $a['is_low'] !== $b['is_low'] ) return $a['is_low'] ? -1 : 1;
            return $b['sold'] <=> $a['sold'];
        } );
        return self::set_cached( 'inventory', $start, $end, $filters, array(
            'rows' => $rows,
            'out_count' => count( array_filter( $rows, static function ( $r ) { return $r['is_out']; } ) ),
            'low_count' => count( array_filter( $rows, static function ( $r ) { return $r['is_low'] && ! $r['is_out']; } ) ),
            'no_sale_count' => count( array_filter( $rows, static function ( $r ) { return $r['no_sale']; } ) ),
            'tracking_started_at' => get_option( 'hgr_tracking_started_at', '' ),
            'money' => self::money_meta(),
            'meta' => array( 'truncated' => $sales_report['meta']['truncated'], 'product_limit' => count( $products ) >= 15000 ),
        ) );
    }

    public static function alerts( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'alerts', $start, $end, $filters );
        if ( false !== $cached ) return $cached;
        $dashboard = self::dashboard( $start, $end, $filters );
        $inventory = self::inventory( $start, $end, $filters );
        $customers = self::customers( $start, $end, $filters );
        $alerts = array();
        $drop = abs( min( 0, (float) ( $dashboard['changes']['net'] ?? 0 ) ) );
        $drop_threshold = (float) get_option( 'hgr_alert_sales_drop', 20 );
        if ( $drop >= $drop_threshold ) $alerts[] = array( 'severity' => 'danger', 'title' => 'افت فروش', 'message' => sprintf( 'فروش خالص نسبت به دوره مقایسه %.1f٪ افت کرده است.', $drop ) );
        $cancel_threshold = (float) get_option( 'hgr_alert_cancel_rate', 8 );
        if ( $dashboard['summary']['cancel_rate'] >= $cancel_threshold ) $alerts[] = array( 'severity' => 'danger', 'title' => 'نرخ لغو بالا', 'message' => sprintf( 'نرخ لغو %.1f٪ است و از آستانه %.1f٪ عبور کرده.', $dashboard['summary']['cancel_rate'], $cancel_threshold ) );
        $failed_threshold = (float) get_option( 'hgr_alert_failed_rate', 6 );
        if ( $dashboard['summary']['failed_rate'] >= $failed_threshold ) $alerts[] = array( 'severity' => 'warning', 'title' => 'پرداخت ناموفق', 'message' => sprintf( 'نرخ سفارش ناموفق %.1f٪ است.', $dashboard['summary']['failed_rate'] ) );
        $refund_threshold = (float) get_option( 'hgr_alert_refund_rate', 5 );
        if ( $dashboard['summary']['refund_rate'] >= $refund_threshold ) $alerts[] = array( 'severity' => 'warning', 'title' => 'مرجوعی بالا', 'message' => sprintf( 'نرخ سفارش‌های دارای مرجوعی %.1f٪ است.', $dashboard['summary']['refund_rate'] ) );
        $top_out = array_values( array_filter( $inventory['rows'], static function ( $r ) { return $r['is_out'] && $r['sold'] > 0; } ) );
        if ( $top_out ) {
            usort( $top_out, static function ( $a, $b ) { return $b['sold'] <=> $a['sold']; } );
            foreach ( array_slice( $top_out, 0, 5 ) as $row ) $alerts[] = array( 'severity' => 'danger', 'title' => 'پرفروش ناموجود', 'message' => $row['name'] . ' در بازه ' . $row['sold'] . ' عدد فروش داشته اما اکنون ناموجود است.' );
        }
        $risk = 0;
        $vip_risk = 0;
        foreach ( $customers['rows'] as $row ) {
            if ( 'در خطر ریزش' === $row['segment'] || 'از دست رفته' === $row['segment'] ) $risk++;
            if ( 'VIP' === $row['segment'] && $row['last_date'] && ( time() - strtotime( $row['last_date'] ) ) / DAY_IN_SECONDS >= (int) get_option( 'hgr_risk_days', 60 ) ) $vip_risk++;
        }
        if ( $risk ) $alerts[] = array( 'severity' => 'info', 'title' => 'مشتریان در معرض ریزش', 'message' => number_format_i18n( $risk ) . ' مشتری در دسته «در خطر ریزش/از دست رفته» قرار گرفته‌اند.' );
        if ( $vip_risk ) $alerts[] = array( 'severity' => 'warning', 'title' => 'VIP غیرفعال', 'message' => number_format_i18n( $vip_risk ) . ' مشتری VIP مدت قابل‌توجهی خرید نکرده‌اند.' );
        if ( ! $alerts ) $alerts[] = array( 'severity' => 'success', 'title' => 'هشدار مهمی نیست', 'message' => 'با آستانه‌های فعلی، هشدار مدیریتی مهمی در این بازه پیدا نشد.' );
        return self::set_cached( 'alerts', $start, $end, $filters, array( 'rows' => $alerts, 'meta' => array( 'truncated' => $dashboard['meta']['truncated'] || $inventory['meta']['truncated'] || $customers['meta']['truncated'] ) ) );
    }


    public static function data_health( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'data_health', $start, $end, array() );
        if ( false !== $cached ) return $cached;

        $sync = HGR_Reference::analytics_sync_status( $start, $end );
        $analytics_ref = HGR_Reference::stats( $start, $end, array(), 'day' );
        $legacy_ref = HGR_Legacy_Reference::stats( $start, $end, array() );
        $ledger = self::financial_fallback_ledger( $start, $end, array() );
        $analytics = is_wp_error( $analytics_ref ) ? null : HGR_Reference::map_to_hgr_summary( $analytics_ref['totals'] );
        $legacy = is_wp_error( $legacy_ref ) ? null : HGR_Legacy_Reference::map_to_hgr_summary( $legacy_ref['totals'] );

        global $wpdb;
        $stats_table = $wpdb->prefix . 'wc_order_stats';
        $date_col = HGR_Reference::analytics_date_type();
        if ( ! in_array( $date_col, array( 'date_created','date_paid','date_completed' ), true ) ) $date_col = 'date_paid';
        $lookup_by_status = array();
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stats_table ) ) === $stats_table ) {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT status, COUNT(*) AS c FROM {$stats_table} WHERE parent_id=0 AND `{$date_col}` BETWEEN %s AND %s GROUP BY status",
                $start . ' 00:00:00', $end . ' 23:59:59'
            ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            foreach ( (array) $rows as $row ) {
                $slug = str_replace( 'wc-', '', sanitize_key( $row['status'] ?? '' ) );
                if ( $slug ) $lookup_by_status[ $slug ] = (int) ( $row['c'] ?? 0 );
            }
        }

        $status_rows = array();
        foreach ( wc_get_order_statuses() as $key => $label ) {
            $slug = str_replace( 'wc-', '', $key );
            $raw = null;
            try {
                $args = array( 'status'=>array( $slug ), 'limit'=>1, 'paginate'=>true, 'return'=>'ids' );
                $args[ $date_col ] = $start . '...' . $end;
                $q = wc_get_orders( $args );
                if ( is_object( $q ) && isset( $q->total ) ) $raw = (int) $q->total;
            } catch ( Throwable $e ) {}
            $lookup = isset( $lookup_by_status[ $slug ] ) ? (int) $lookup_by_status[ $slug ] : 0;
            $status_rows[] = array(
                'status'=>$slug, 'label'=>wp_strip_all_tags( $label ), 'analytics_lookup'=>$lookup,
                'crud'=>$raw, 'difference'=>null === $raw ? null : $lookup-$raw,
                'included'=>in_array( $slug, HGR_Reference::analytics_included_statuses(), true ) ? 'بله' : 'خیر',
            );
        }

        $recommendations = array();
        if ( empty( $sync['ready'] ) ) {
            $recommendations[] = 'درون‌ریزی/به‌روزرسانی WooCommerce Analytics را کامل کن؛ تا آن زمان KPI پایه «تأییدشده» نیست.';
        } else {
            $recommendations[] = 'ساختار Analytics در این بازه با سفارش‌های خام تطبیق دارد و می‌تواند مرجع KPI پایه باشد.';
        }
        if ( ! empty( get_option( 'hgr_sales_statuses', array() ) ) ) $recommendations[] = 'Override دستی وضعیت فروش را پاک کن تا Analytics Exact فعال بماند.';
        if ( is_wp_error( $analytics_ref ) ) $recommendations[] = 'DataStore Analytics در دسترس نیست: ' . $analytics_ref->get_error_message();
        if ( ! is_wp_error( $legacy_ref ) && null !== $analytics && (int)$legacy['orders'] !== (int)$analytics['orders'] ) {
            $recommendations[] = 'اختلاف Legacy و Analytics لزوماً خطا نیست؛ تاریخ مبنا و تعریف وضعیت‌ها متفاوت است. برای KPI آینده Analytics را مبنا نگه دار.';
        }

        $result = array(
            'ready'=>!empty($sync['ready']), 'state'=>$sync['state'], 'sync'=>$sync,
            'analytics'=>$analytics, 'legacy'=>$legacy,
            'independent'=>array(
                'orders'=>(int)$ledger['orders'], 'items'=>(float)$ledger['items'], 'gross'=>(float)$ledger['gross'],
                'refunds'=>(float)$ledger['refunds'], 'discounts'=>(float)$ledger['discounts'], 'net'=>(float)$ledger['net'],
                'tax'=>(float)$ledger['tax'], 'shipping'=>(float)$ledger['shipping'], 'total_sales'=>(float)$ledger['total_sales'], 'aov'=>(float)$ledger['aov'],
            ),
            'status_rows'=>$status_rows, 'recommendations'=>$recommendations,
            'analytics_error'=>is_wp_error($analytics_ref)?$analytics_ref->get_error_message():'',
            'legacy_error'=>is_wp_error($legacy_ref)?$legacy_ref->get_error_message():'',
            'money'=>self::money_meta(),
            'meta'=>array( 'truncated'=>!empty($ledger['truncated']), 'engine'=>'analytics_first_data_health_v33', 'canonical_kpi'=>!empty($sync['ready']), 'date_type'=>$date_col ),
        );
        return self::set_cached( 'data_health', $start, $end, array(), $result );
    }

    public static function audit( $start, $end, $filters = array() ) {
        list( $start, $end ) = self::normalize_range( $start, $end );
        $filters = self::sanitize_filters( $filters );
        $cached = self::get_cached( 'audit', $start, $end, $filters );
        if ( false !== $cached ) return $cached;

        $ledger = self::financial_fallback_ledger( $start, $end, $filters );
        $legacy_ref = HGR_Legacy_Reference::stats( $start, $end, $filters );
        $analytics_ref = HGR_Reference::stats( $start, $end, $filters, 'day' );

        $legacy = is_wp_error( $legacy_ref ) ? null : HGR_Legacy_Reference::map_to_hgr_summary( $legacy_ref['totals'] );
        $analytics = is_wp_error( $analytics_ref ) ? null : HGR_Reference::map_to_hgr_summary( $analytics_ref['totals'] );
        $active_mode = HGR_Reference::mode();
        $active = 'legacy' === $active_mode ? $legacy : $analytics;

        $definitions = array(
            'orders'=>'تعداد سفارش', 'items'=>'تعداد کالای فروخته‌شده', 'gross'=>'فروش ناخالص/کل طبق مرجع',
            'refunds'=>'مرجوعی', 'discounts'=>'تخفیف/کوپن', 'net'=>'فروش خالص',
            'tax'=>'مالیات', 'shipping'=>'ارسال', 'total_sales'=>'فروش کل', 'aov'=>'AOV مشتق‌شده',
        );
        $rows = array();
        foreach ( $definitions as $key=>$label ) {
            $independent = isset( $ledger[$key] ) ? (float) $ledger[$key] : 0.0;
            $legacy_value = null !== $legacy && isset( $legacy[$key] ) ? (float) $legacy[$key] : null;
            $analytics_value = null !== $analytics && isset( $analytics[$key] ) ? (float) $analytics[$key] : null;
            $active_value = null !== $active && isset( $active[$key] ) ? (float) $active[$key] : null;
            $not_comparable = ( 'legacy' === $active_mode && 'gross' === $key );
            $delta = ( null === $active_value || $not_comparable ) ? null : $independent - $active_value;
            $base = null === $active_value ? 0.0 : abs( $active_value );
            $delta_pct = null === $delta ? null : ( $base > 0.000001 ? 100*$delta/$base : ( abs($delta)<0.000001 ? 0.0 : null ) );
            $tolerance = in_array( $key, array( 'orders','items' ), true ) ? 0.00001 : 1.0;
            $status = $not_comparable ? 'definition' : ( null === $active_value ? 'unavailable' : ( abs( $delta ) <= $tolerance ? 'match' : 'diff' ) );
            $rows[] = array(
                'key'=>$key, 'label'=>$label, 'active'=>$active_value,
                'legacy'=>$legacy_value, 'analytics'=>$analytics_value, 'independent'=>$independent,
                'delta'=>$delta, 'delta_pct'=>$delta_pct, 'status'=>$status,
            );
        }

        $diffs = count( array_filter( $rows, static function($r){ return 'diff'===$r['status']; } ) );
        $matches = count( array_filter( $rows, static function($r){ return 'match'===$r['status']; } ) );
        $unavailable = count( array_filter( $rows, static function($r){ return in_array($r['status'],array('unavailable','definition'),true); } ) );
        $legacy_orders = null !== $legacy ? (int) $legacy['orders'] : null;
        $analytics_orders = null !== $analytics ? (int) $analytics['orders'] : null;

        $result = array(
            'rows'=>$rows,
            'active_mode'=>$active_mode,
            'active_label'=>'legacy'===$active_mode ? 'WooCommerce Legacy Exact' : 'WooCommerce Analytics',
            'legacy_available'=>null!==$legacy,
            'analytics_available'=>null!==$analytics,
            'legacy_error'=>is_wp_error($legacy_ref)?$legacy_ref->get_error_message():'',
            'analytics_error'=>is_wp_error($analytics_ref)?$analytics_ref->get_error_message():'',
            'legacy_source'=>is_wp_error($legacy_ref)?'':$legacy_ref['source'],
            'analytics_source'=>is_wp_error($analytics_ref)?'':$analytics_ref['source'],
            'date_type'=>HGR_Reference::date_type(),
            'status_basis'=>self::paid_statuses(),
            'cohort'=>array(
                'legacy_orders'=>$legacy_orders,
                'analytics_orders'=>$analytics_orders,
                'order_difference'=>( null!==$legacy_orders && null!==$analytics_orders ) ? $legacy_orders-$analytics_orders : null,
                'legacy_date_type'=>'date_created',
                'legacy_statuses'=>HGR_Legacy_Reference::statuses(),
                'analytics_date_type'=>HGR_Reference::analytics_date_type(),
                'analytics_statuses'=>HGR_Reference::analytics_included_statuses(),
            ),
            'definitions'=>array(
                'legacy'=>'WooCommerce > Reports > Sales by date: تاریخ ایجاد سفارش + completed/processing/on-hold/refunded. Net = Total after refunds - shipping - taxes. Legacy gross label is its Total Sales after refunds.',
                'analytics'=>'WooCommerce Analytics: Orders Stats DataStore با date type و excluded statuses تنظیم‌شده در Analytics.',
                'independent'=>'محاسبه CRUD مستقل افزونه برای کنترل؛ مرجع اصلی نیست مگر اینکه مرجع انتخابی در دسترس نباشد.',
                'aov'=>'در Legacy Exact، AOV = Net Sales ÷ Orders و یک KPI مشتق‌شده است؛ خود گزارش کلاسیک AOV سفارشی نمایش نمی‌دهد.',
            ),
            'summary'=>array('matches'=>$matches,'differences'=>$diffs,'unavailable'=>$unavailable),
            'money'=>self::money_meta(),
            'meta'=>array(
                'truncated'=>$ledger['truncated'],
                'engine'=>'three-source-kpi-reconciliation-v33',
                'legacy_supported_filters'=>HGR_Legacy_Reference::supports_filters($filters),
                'analytics_supported_filters'=>HGR_Reference::supports_filters($filters),
            ),
        );
        return self::set_cached( 'audit', $start, $end, $filters, $result );
    }

    public static function get_report( $type, $start, $end, $filters = array() ) {
        $allowed = array( 'dashboard', 'sales', 'products', 'categories', 'brands', 'customers', 'retention', 'geography', 'channels', 'cancellations', 'funnel', 'coupons', 'bundles', 'attribution', 'profit', 'inventory', 'alerts', 'data_health', 'audit' );
        if ( ! in_array( $type, $allowed, true ) ) return new WP_Error( 'hgr_invalid_report', 'گزارش درخواستی معتبر نیست.' );
        return self::{$type}( $start, $end, $filters );
    }

    public static function filter_options() {
        // Keep admin boot light on large stores. Product search is AJAX-backed;
        // only a small recent sample is preloaded for convenience.
        $products = wc_get_products( array( 'status'=>array( 'publish','private' ), 'limit'=>50, 'orderby'=>'date', 'order'=>'DESC', 'return'=>'objects' ) );
        $product_options = array();
        foreach ( $products as $p ) $product_options[] = array( 'id'=>$p->get_id(), 'name'=>$p->get_name(), 'sku'=>$p->get_sku() );
        $categories = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        $cat_options = array();
        if ( ! is_wp_error( $categories ) ) foreach ( $categories as $term ) $cat_options[] = array( 'id' => $term->term_id, 'name' => $term->name );
        $brand_tax = self::brand_taxonomy();
        $brand_options = array();
        if ( $brand_tax ) {
            $terms = get_terms( array( 'taxonomy' => $brand_tax, 'hide_empty' => false ) );
            if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) $brand_options[] = array( 'id' => $term->term_id, 'name' => $term->name );
        }
        $payments = array();
        if ( WC()->payment_gateways() ) {
            foreach ( WC()->payment_gateways()->payment_gateways() as $id => $gateway ) $payments[] = array( 'id' => $id, 'name' => $gateway->get_title() ?: $id );
        }
        $shipping = array();
        if ( class_exists( 'WC_Shipping_Zones' ) ) {
            $zones = WC_Shipping_Zones::get_zones();
            $zones[] = array( 'zone_id' => 0, 'shipping_methods' => WC_Shipping_Zones::get_zone( 0 )->get_shipping_methods( true ) );
            foreach ( $zones as $zone ) {
                if ( empty( $zone['shipping_methods'] ) ) continue;
                foreach ( $zone['shipping_methods'] as $method ) {
                    $id = $method->id . ':' . $method->instance_id;
                    $shipping[ $id ] = array( 'id' => $id, 'name' => $method->get_title() ?: $method->id );
                }
            }
        }
        $states = array();
        $ir_states = isset( WC()->countries->states['IR'] ) ? WC()->countries->states['IR'] : array();
        foreach ( $ir_states as $code => $name ) $states[] = array( 'id' => $code, 'name' => $name );
        $statuses = array();
        foreach ( wc_get_order_statuses() as $key => $label ) $statuses[] = array( 'id' => str_replace( 'wc-', '', $key ), 'name' => $label );
        return array(
            'products' => $product_options,
            'categories' => $cat_options,
            'brands' => $brand_options,
            'brandTaxonomy' => $brand_tax,
            'payments' => $payments,
            'shipping' => array_values( $shipping ),
            'states' => $states,
            'statuses' => $statuses,
            'segments' => array( 'VIP', 'وفادار', 'فعال', 'یک‌بار خرید', 'در خطر ریزش', 'از دست رفته' ),
        );
    }
}
