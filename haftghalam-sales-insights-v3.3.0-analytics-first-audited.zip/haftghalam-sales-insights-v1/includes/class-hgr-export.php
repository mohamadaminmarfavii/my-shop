<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class HGR_Export {
    public static function handle() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( 'دسترسی کافی ندارید.', 403 );
        }
        check_admin_referer( 'hgr_export', 'nonce' );
        $type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : 'dashboard';
        $start = isset( $_POST['start'] ) ? sanitize_text_field( wp_unslash( $_POST['start'] ) ) : '';
        $end = isset( $_POST['end'] ) ? sanitize_text_field( wp_unslash( $_POST['end'] ) ) : '';
        $format = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'csv';
        $filters = isset( $_POST['filters'] ) ? HGR_Reports::sanitize_filters( $_POST['filters'] ) : array();
        $search = isset( $_POST['row_search'] ) ? sanitize_text_field( wp_unslash( $_POST['row_search'] ) ) : '';
        $report = HGR_Reports::get_report( $type, $start, $end, $filters );
        if ( is_wp_error( $report ) ) {
            wp_die( esc_html( $report->get_error_message() ), 400 );
        }
        $truncated = ! empty( $report['meta']['truncated'] ) || ! empty( $report['summary']['truncated'] );
        if ( $truncated ) {
            wp_die( 'این گزارش به سقف محافظتی داده رسیده و ناقص است؛ برای جلوگیری از خروجی KPI گمراه‌کننده Export مسدود شد. بازه یا فیلتر را محدودتر کن.', 409 );
        }
        $sections = self::sections( $type, $report, $search );
        array_unshift( $sections, self::metadata_section( $type, $start, $end, $filters, $report ) );
        $filename = 'haftghalam-kpi-' . $type . '-' . $start . '-' . $end;
        nocache_headers();
        if ( 'xls' === $format ) {
            self::output_xls( $filename . '.xls', $sections );
        }
        self::output_csv( $filename . '.csv', $sections );
    }

    private static function metadata_section( $type, $start, $end, $filters, $report ) {
        $money = isset( $report['money'] ) && is_array( $report['money'] ) ? $report['money'] : array();
        $summary = isset( $report['summary'] ) && is_array( $report['summary'] ) ? $report['summary'] : array();
        $meta = isset( $report['meta'] ) && is_array( $report['meta'] ) ? $report['meta'] : array();
        $rows = array(
            array( 'field'=>'report', 'value'=>$type ),
            array( 'field'=>'range', 'value'=>$start . ' تا ' . $end ),
            array( 'field'=>'date_type', 'value'=>$summary['date_type'] ?? $meta['date_type'] ?? HGR_Reference::date_type() ),
            array( 'field'=>'data_source', 'value'=>$summary['data_source'] ?? $meta['data_source'] ?? '' ),
            array( 'field'=>'reference_exact', 'value'=>! empty( $summary['reference_exact'] ) || ! empty( $meta['reference_exact'] ) ? 'yes' : 'no' ),
            array( 'field'=>'analytics_sync', 'value'=>$summary['analytics_sync'] ?? '' ),
            array( 'field'=>'canonical_kpi', 'value'=>!empty($summary['canonical_kpi']) || !empty($meta['canonical_kpi']) ? 'yes' : 'no' ),
            array( 'field'=>'statuses', 'value'=>implode( ',', HGR_Reports::sales_statuses_for_diagnostics() ) ),
            array( 'field'=>'filters', 'value'=>wp_json_encode( $filters, JSON_UNESCAPED_UNICODE ) ),
            array( 'field'=>'stored_currency', 'value'=>$money['currency'] ?? get_woocommerce_currency() ),
            array( 'field'=>'ui_divisor', 'value'=>$money['divisor'] ?? 1 ),
            array( 'field'=>'ui_label', 'value'=>$money['label'] ?? '' ),
            array( 'field'=>'amount_note', 'value'=>'اعداد این فایل در واحد خام ذخیره‌شده ووکامرس هستند؛ ui_divisor فقط نحوه نمایش داخل داشبورد را مشخص می‌کند.' ),
        );
        return array( 'title'=>'مرجع و تعریف گزارش', 'columns'=>array( 'field'=>'فیلد', 'value'=>'مقدار' ), 'rows'=>$rows );
    }

    private static function filter_rows( $rows, $search ) {
        if ( ! $search ) return $rows;
        $needle = function_exists( 'mb_strtolower' ) ? mb_strtolower( $search, 'UTF-8' ) : strtolower( $search );
        return array_values( array_filter( $rows, static function ( $row ) use ( $needle ) {
            $raw = wp_json_encode( $row, JSON_UNESCAPED_UNICODE );
            $text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $raw, 'UTF-8' ) : strtolower( $raw );
            return false !== strpos( $text, $needle );
        } ) );
    }

    private static function sections( $type, $r, $search ) {
        $s = array();
        $money = isset( $r['money'] ) ? $r['money'] : array();
        switch ( $type ) {
            case 'dashboard':
                $rows = array();
                foreach ( $r['summary'] as $k => $v ) if ( is_scalar( $v ) || null === $v ) $rows[] = array( 'metric' => $k, 'value' => $v );
                $s[] = array( 'title' => 'KPI Dashboard', 'columns' => array( 'metric' => 'شاخص', 'value' => 'مقدار' ), 'rows' => $rows );
                break;
            case 'sales':
                $s[] = array( 'title' => 'فروش روزانه', 'columns' => array( 'date_j' => 'تاریخ شمسی', 'orders' => 'سفارش', 'gross' => 'Gross Sales', 'refunds' => 'Returns', 'discounts' => 'Coupons', 'net' => 'Net Sales', 'tax' => 'Tax', 'shipping' => 'Shipping', 'total_sales' => 'Total Sales', 'items' => 'Items Sold', 'aov' => 'AOV', 'profit' => 'سود / COGS' ), 'rows' => self::filter_rows( $r['daily'], $search ) );
                $s[] = array( 'title' => 'فروش ساعتی', 'columns' => array( 'hour' => 'ساعت', 'orders' => 'سفارش', 'net' => 'فروش خالص', 'items' => 'کالا', 'aov' => 'AOV' ), 'rows' => $r['hourly'] );
                break;
            case 'products':
                $s[] = array( 'title' => 'محصولات', 'columns' => array( 'id' => 'ID', 'name' => 'محصول', 'sku' => 'SKU', 'qty' => 'تعداد فروش', 'orders' => 'سفارش', 'sales' => 'فروش خالص', 'avg_price' => 'میانگین قیمت', 'discount' => 'تخفیف', 'refund_qty' => 'تعداد مرجوع', 'refund_amount' => 'مبلغ مرجوع', 'cancelled_orders' => 'سفارش لغو/ناموفق', 'profit' => 'سود', 'margin' => 'حاشیه سود %', 'stock_qty' => 'موجودی', 'stock_status' => 'وضعیت موجودی', 'last_sale_j' => 'آخرین فروش شمسی', 'days_since_last_sale' => 'روز از آخرین فروش' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'categories':
                $s[] = array( 'title' => 'دسته‌بندی‌ها', 'columns' => array( 'name' => 'دسته', 'orders' => 'سفارش', 'qty' => 'تعداد کالا', 'sales' => 'فروش', 'share' => 'سهم فروش %', 'aov' => 'AOV', 'customers' => 'مشتری' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'brands':
                $s[] = array( 'title' => 'برندها', 'columns' => array( 'name' => 'برند', 'orders' => 'سفارش', 'qty' => 'کالا', 'sales' => 'فروش', 'share' => 'سهم %', 'aov' => 'AOV', 'customers' => 'مشتری', 'repeat_customers' => 'مشتری تکراری', 'refunds' => 'مرجوعی', 'profit' => 'سود', 'margin' => 'حاشیه سود %', 'cost_coverage' => 'پوشش هزینه %' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'customers':
                $s[] = array( 'title' => 'مشتریان', 'columns' => array( 'name' => 'مشتری', 'phone' => 'موبایل', 'email' => 'ایمیل', 'state' => 'استان', 'city' => 'شهر', 'orders' => 'سفارش بازه', 'spent' => 'خرید بازه', 'aov' => 'AOV', 'lifetime_orders' => 'کل سفارش', 'lifetime_spent' => 'کل خرید', 'first_date_j' => 'اولین خرید', 'last_date_j' => 'آخرین خرید', 'segment' => 'سگمنت', 'cancelled' => 'لغو', 'failed' => 'ناموفق', 'refunds' => 'مرجوعی', 'favorite_products' => 'محصولات محبوب', 'favorite_categories' => 'دسته محبوب', 'coupons' => 'کد تخفیف' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'retention':
                $rows = array();
                foreach ( $r as $k => $v ) if ( is_scalar( $v ) || null === $v ) $rows[] = array( 'metric' => $k, 'value' => $v );
                $s[] = array( 'title' => 'خرید مجدد و سگمنت', 'columns' => array( 'metric' => 'شاخص', 'value' => 'مقدار' ), 'rows' => $rows );
                break;
            case 'geography':
                $s[] = array( 'title' => 'جغرافیا', 'columns' => array( 'state' => 'استان', 'city' => 'شهر', 'orders' => 'سفارش', 'sales' => 'فروش', 'aov' => 'AOV', 'customers' => 'مشتری' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'channels':
                $s[] = array( 'title' => 'روش پرداخت', 'columns' => array( 'title' => 'روش', 'method' => 'شناسه', 'orders' => 'سفارش موفق', 'net' => 'فروش خالص', 'aov' => 'AOV', 'new_customers' => 'مشتری جدید', 'repeat_customers' => 'مشتری تکراری', 'cancelled' => 'لغو', 'failed' => 'ناموفق', 'failure_rate' => 'نرخ شکست %' ), 'rows' => self::filter_rows( $r['payments'], $search ) );
                $s[] = array( 'title' => 'روش ارسال', 'columns' => array( 'title' => 'روش', 'orders' => 'سفارش', 'net' => 'فروش خالص', 'aov' => 'AOV', 'cancelled' => 'لغو', 'failed' => 'ناموفق' ), 'rows' => $r['shipping'] );
                break;
            case 'cancellations':
                $s[] = array( 'title' => 'لغو و ناموفق', 'columns' => array( 'id' => 'سفارش', 'date_j' => 'تاریخ', 'name' => 'مشتری', 'phone' => 'موبایل', 'city' => 'شهر', 'payment' => 'پرداخت', 'total' => 'مبلغ', 'status' => 'وضعیت', 'reason' => 'دلیل', 'customer_type' => 'نوع مشتری', 'products' => 'محصولات', 'modified_j' => 'آخرین تغییر' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                $s[] = array( 'title' => 'دلایل لغو', 'columns' => array( 'reason' => 'دلیل', 'count' => 'تعداد', 'value' => 'ارزش' ), 'rows' => $r['reasons'] );
                break;
            case 'funnel':
                $s[] = array( 'title' => 'وضعیت سفارش‌ها', 'columns' => array( 'status' => 'وضعیت', 'count' => 'تعداد', 'value' => 'ارزش' ), 'rows' => $r['statuses'] );
                $s[] = array( 'title' => 'سبد خرید', 'columns' => array( 'metric' => 'شاخص', 'value' => 'مقدار' ), 'rows' => array(
                    array( 'metric' => 'سبد ردیابی‌شده', 'value' => $r['carts_tracked'] ), array( 'metric' => 'تبدیل‌شده', 'value' => $r['carts_converted'] ), array( 'metric' => 'رهاشده', 'value' => $r['carts_abandoned'] ), array( 'metric' => 'فعال', 'value' => $r['carts_active'] ), array( 'metric' => 'ارزش رهاشده', 'value' => $r['abandoned_value'] ), array( 'metric' => 'نرخ تبدیل', 'value' => $r['cart_conversion_rate'] ),
                ) );
                break;
            case 'coupons':
                $s[] = array( 'title' => 'کوپن‌ها', 'columns' => array( 'code' => 'کد', 'orders' => 'سفارش', 'sales' => 'فروش', 'discount' => 'تخفیف', 'aov' => 'AOV', 'new_customers' => 'جدید', 'repeat_customers' => 'تکراری', 'top_products' => 'محصولات' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'bundles':
                $s[] = array( 'title' => 'خرید باهم', 'columns' => array( 'product_a' => 'محصول اول', 'product_b' => 'محصول دوم', 'orders' => 'سفارش مشترک', 'support' => 'سهم از سفارش‌ها %', 'affinity' => 'همبستگی %' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'attribution':
                $s[] = array( 'title' => 'منبع فروش', 'columns' => array( 'source' => 'منبع', 'mediums' => 'Medium', 'orders' => 'سفارش', 'sales' => 'فروش', 'aov' => 'AOV' ), 'rows' => self::filter_rows( $r['sources'], $search ) );
                $s[] = array( 'title' => 'کمپین', 'columns' => array( 'campaign' => 'کمپین', 'orders' => 'سفارش', 'sales' => 'فروش', 'aov' => 'AOV' ), 'rows' => $r['campaigns'] );
                $s[] = array( 'title' => 'دستگاه', 'columns' => array( 'device' => 'دستگاه', 'orders' => 'سفارش', 'sales' => 'فروش', 'aov' => 'AOV' ), 'rows' => $r['devices'] );
                break;
            case 'profit':
                $s[] = array( 'title' => 'سود محصولات', 'columns' => array( 'name' => 'محصول', 'qty' => 'تعداد', 'sales' => 'فروش', 'cost' => 'بهای کالا', 'profit' => 'سود', 'margin' => 'حاشیه سود %' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'inventory':
                $s[] = array( 'title' => 'موجودی', 'columns' => array( 'id' => 'ID', 'name' => 'محصول', 'sku' => 'SKU', 'sold' => 'فروش تعدادی', 'sales' => 'فروش مبلغی', 'stock_status' => 'وضعیت', 'stock_qty' => 'موجودی', 'low_amount' => 'حد هشدار', 'no_sale' => 'بدون فروش', 'out_days_tracked' => 'روز ناموجود ردیابی‌شده', 'lost_qty_estimate' => 'تعداد فروش از دست رفته تخمینی', 'lost_sales_estimate' => 'مبلغ فروش از دست رفته تخمینی' ), 'rows' => self::filter_rows( $r['rows'], $search ) );
                break;
            case 'alerts':
                $s[] = array( 'title' => 'هشدارها', 'columns' => array( 'severity' => 'شدت', 'title' => 'عنوان', 'message' => 'شرح' ), 'rows' => $r['rows'] );
                break;
            case 'data_health':
                $s[] = array( 'title'=>'سلامت داده', 'columns'=>array( 'label'=>'وضعیت', 'status'=>'slug', 'included'=>'در Analytics', 'analytics_lookup'=>'Lookup', 'crud'=>'CRUD', 'difference'=>'اختلاف' ), 'rows'=>self::filter_rows( $r['status_rows'], $search ) );
                break;
            case 'audit':
                $s[] = array( 'title'=>'ممیزی KPI', 'columns'=>array( 'label'=>'KPI', 'legacy'=>'WooCommerce Reports Legacy', 'analytics'=>'WooCommerce Analytics', 'independent'=>'محاسبه مستقل', 'delta'=>'اختلاف مستقل با مرجع فعال', 'delta_pct'=>'اختلاف %', 'status'=>'وضعیت' ), 'rows'=>self::filter_rows( $r['rows'], $search ) );
                break;
        }
        return $s;
    }


    private static function safe_cell( $value ) {
        if ( is_bool( $value ) ) $value = $value ? 'بله' : 'خیر';
        if ( is_array( $value ) || is_object( $value ) ) $value = wp_json_encode( $value, JSON_UNESCAPED_UNICODE );
        $value = (string) $value;
        if ( preg_match( '/^[=+\-@]/u', $value ) ) $value = "'" . $value;
        return $value;
    }

    private static function output_csv( $filename, $sections ) {
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
        echo "\xEF\xBB\xBF";
        $out = fopen( 'php://output', 'w' );
        foreach ( $sections as $section ) {
            fputcsv( $out, array( $section['title'] ) );
            fputcsv( $out, array_values( $section['columns'] ) );
            foreach ( $section['rows'] as $row ) {
                $line = array();
                foreach ( array_keys( $section['columns'] ) as $key ) {
                    $v = isset( $row[ $key ] ) ? $row[ $key ] : '';
                    $line[] = self::safe_cell( $v );
                }
                fputcsv( $out, $line );
            }
            fputcsv( $out, array() );
        }
        fclose( $out );
        exit;
    }

    private static function output_xls( $filename, $sections ) {
        header( 'Content-Type: application/vnd.ms-excel; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
        echo "\xEF\xBB\xBF";
        echo '<html><head><meta charset="utf-8"></head><body dir="rtl">';
        foreach ( $sections as $section ) {
            echo '<h2>' . esc_html( $section['title'] ) . '</h2><table border="1"><thead><tr>';
            foreach ( $section['columns'] as $label ) echo '<th>' . esc_html( $label ) . '</th>';
            echo '</tr></thead><tbody>';
            foreach ( $section['rows'] as $row ) {
                echo '<tr>';
                foreach ( array_keys( $section['columns'] ) as $key ) {
                    $v = isset( $row[ $key ] ) ? $row[ $key ] : '';
                    echo '<td>' . esc_html( self::safe_cell( $v ) ) . '</td>';
                }
                echo '</tr>';
            }
            echo '</tbody></table><br><br>';
        }
        echo '</body></html>';
        exit;
    }
}
