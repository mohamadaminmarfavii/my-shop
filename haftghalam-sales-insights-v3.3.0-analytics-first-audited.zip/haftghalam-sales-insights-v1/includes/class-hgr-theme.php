<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class HGR_Theme {
    const OPTION_THEME = 'hgr_theme';
    const OPTION_CSS   = 'hgr_custom_css';

    public static function get_theme() {
        $theme = sanitize_key( (string) get_option( self::OPTION_THEME, 'default' ) );
        return in_array( $theme, array( 'default', 'compact', 'dark' ), true ) ? $theme : 'default';
    }

    public static function get_custom_css() {
        return (string) get_option( self::OPTION_CSS, '' );
    }

    public static function sanitize_css( $css ) {
        $css = wp_strip_all_tags( (string) $css, false );
        $css = preg_replace( '/@import\s+[^;]+;?/i', '', $css );
        $css = preg_replace( '/expression\s*\(/i', '', $css );
        $css = preg_replace( '/javascript\s*:/i', '', $css );
        $css = preg_replace( '/-moz-binding\s*:/i', '', $css );
        $css = preg_replace( '/behavior\s*:/i', '', $css );
        return trim( $css );
    }

    public static function render( $relative, array $vars = array() ) {
        $relative = ltrim( $relative, '/\\' );
        $override = trailingslashit( get_stylesheet_directory() ) . 'haftghalam-reports/' . $relative;
        $builtin  = HGR_PATH . 'templates/' . $relative;
        $file     = is_readable( $override ) ? $override : $builtin;
        if ( ! is_readable( $file ) ) {
            return;
        }
        extract( $vars, EXTR_SKIP );
        include $file;
    }
}
