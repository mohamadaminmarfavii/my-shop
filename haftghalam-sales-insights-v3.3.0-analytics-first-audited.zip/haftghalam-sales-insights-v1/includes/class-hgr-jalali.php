<?php
if ( ! defined( 'ABSPATH' ) && PHP_SAPI !== 'cli' ) {
    exit;
}

final class HGR_Jalali {
    private static function div( $a, $b ) {
        return intdiv( (int) $a, (int) $b );
    }

    private static function mod( $a, $b ) {
        return $a - self::div( $a, $b ) * $b;
    }

    private static function g2d( $gy, $gm, $gd ) {
        $d = self::div( ( $gy + self::div( $gm - 8, 6 ) + 100100 ) * 1461, 4 )
            + self::div( 153 * self::mod( $gm + 9, 12 ) + 2, 5 )
            + $gd - 34840408;
        $d = $d - self::div( self::div( $gy + 100100 + self::div( $gm - 8, 6 ), 100 ) * 3, 4 ) + 752;
        return $d;
    }

    private static function d2g( $jdn ) {
        $j = 4 * $jdn + 139361631;
        $j = $j + self::div( self::div( 4 * $jdn + 183187720, 146097 ) * 3, 4 ) * 4 - 3908;
        $i = self::div( self::mod( $j, 1461 ), 4 ) * 5 + 308;
        $gd = self::div( self::mod( $i, 153 ), 5 ) + 1;
        $gm = self::mod( self::div( $i, 153 ), 12 ) + 1;
        $gy = self::div( $j, 1461 ) - 100100 + self::div( 8 - $gm, 6 );
        return array( $gy, $gm, $gd );
    }

    private static function jal_cal( $jy ) {
        $breaks = array( -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178 );
        $bl = count( $breaks );
        $gy = $jy + 621;
        $leap_j = -14;
        $jp = $breaks[0];
        $jump = 0;
        if ( $jy < $jp || $jy >= $breaks[ $bl - 1 ] ) {
            return false;
        }
        for ( $i = 1; $i < $bl; $i++ ) {
            $jm = $breaks[ $i ];
            $jump = $jm - $jp;
            if ( $jy < $jm ) {
                break;
            }
            $leap_j += self::div( $jump, 33 ) * 8 + self::div( self::mod( $jump, 33 ), 4 );
            $jp = $jm;
        }
        $n = $jy - $jp;
        $leap_j += self::div( $n, 33 ) * 8 + self::div( self::mod( $n, 33 ) + 3, 4 );
        if ( 4 === self::mod( $jump, 33 ) && $jump - $n === 4 ) {
            $leap_j++;
        }
        $leap_g = self::div( $gy, 4 ) - self::div( ( self::div( $gy, 100 ) + 1 ) * 3, 4 ) - 150;
        $march = 20 + $leap_j - $leap_g;
        if ( $jump - $n < 6 ) {
            $n = $n - $jump + self::div( $jump + 4, 33 ) * 33;
        }
        $leap = self::mod( self::mod( $n + 1, 33 ) - 1, 4 );
        if ( -1 === $leap ) {
            $leap = 4;
        }
        return array( 'leap' => $leap, 'gy' => $gy, 'march' => $march );
    }

    private static function j2d( $jy, $jm, $jd ) {
        $r = self::jal_cal( $jy );
        if ( false === $r ) {
            return 0;
        }
        return self::g2d( $r['gy'], 3, $r['march'] ) + ( $jm - 1 ) * 31 - self::div( $jm, 7 ) * ( $jm - 7 ) + $jd - 1;
    }

    private static function d2j( $jdn ) {
        list( $gy, $gm, $gd ) = self::d2g( $jdn );
        $jy = $gy - 621;
        $r = self::jal_cal( $jy );
        $jdn1f = self::g2d( $gy, 3, $r['march'] );
        $k = $jdn - $jdn1f;
        if ( $k >= 0 ) {
            if ( $k <= 185 ) {
                $jm = 1 + self::div( $k, 31 );
                $jd = self::mod( $k, 31 ) + 1;
                return array( $jy, $jm, $jd );
            }
            $k -= 186;
        } else {
            $jy--;
            $k += 179;
            if ( 1 === $r['leap'] ) {
                $k++;
            }
        }
        $jm = 7 + self::div( $k, 30 );
        $jd = self::mod( $k, 30 ) + 1;
        return array( $jy, $jm, $jd );
    }

    public static function gregorian_to_jalali( $gy, $gm, $gd ) {
        return self::d2j( self::g2d( (int) $gy, (int) $gm, (int) $gd ) );
    }

    public static function jalali_to_gregorian( $jy, $jm, $jd ) {
        return self::d2g( self::j2d( (int) $jy, (int) $jm, (int) $jd ) );
    }

    public static function format_gregorian( $date, $with_time = false ) {
        if ( ! $date ) {
            return '';
        }
        if ( $date instanceof DateTimeInterface ) {
            $gy = (int) $date->format( 'Y' );
            $gm = (int) $date->format( 'm' );
            $gd = (int) $date->format( 'd' );
            $time = $with_time ? ' ' . $date->format( 'H:i' ) : '';
        } else {
            $str = (string) $date;
            if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/', $str, $m ) ) {
                return $str;
            }
            $gy = (int) $m[1];
            $gm = (int) $m[2];
            $gd = (int) $m[3];
            $time = $with_time && isset( $m[4] ) ? ' ' . $m[4] . ':' . $m[5] : '';
        }
        list( $jy, $jm, $jd ) = self::gregorian_to_jalali( $gy, $gm, $gd );
        return sprintf( '%04d/%02d/%02d%s', $jy, $jm, $jd, $time );
    }
}
