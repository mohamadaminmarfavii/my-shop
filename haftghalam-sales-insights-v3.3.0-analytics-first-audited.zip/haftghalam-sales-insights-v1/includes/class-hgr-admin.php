<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class HGR_Admin {
    private static $instance = null;
    private $page_hook = '';

    public static function instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', array( $this, 'menu' ), 56 );
        add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
        add_action( 'wp_ajax_hgr_get_report', array( $this, 'ajax_report' ) );
        add_action( 'wp_ajax_hgr_save_ui', array( $this, 'ajax_save_ui' ) );
        add_action( 'wp_ajax_hgr_save_settings', array( $this, 'ajax_save_settings' ) );
        add_action( 'wp_ajax_hgr_save_cancel_reason', array( $this, 'ajax_save_cancel_reason' ) );
        add_action( 'wp_ajax_hgr_clear_cache', array( $this, 'ajax_clear_cache' ) );
        add_action( 'wp_ajax_hgr_health', array( $this, 'ajax_health' ) );
        add_action( 'wp_ajax_hgr_repair_tables', array( $this, 'ajax_repair_tables' ) );
        add_action( 'wp_ajax_hgr_search_products', array( $this, 'ajax_search_products' ) );
        add_action( 'admin_post_hgr_export', array( 'HGR_Export', 'handle' ) );
    }

    public function menu() {
        $this->page_hook = add_menu_page(
            'مرکز تحلیل فروش و KPI هفت‌قلم',
            'تحلیل فروش',
            'manage_woocommerce',
            'hgr-sales-insights',
            array( $this, 'render' ),
            'dashicons-chart-area',
            56
        );
    }

    public function assets( $hook ) {
        if ( $hook !== $this->page_hook ) return;
        wp_enqueue_style( 'hgr-admin', HGR_URL . 'assets/css/admin.css', array(), HGR_VERSION );
        wp_enqueue_script( 'hgr-admin', HGR_URL . 'assets/js/admin.js', array(), HGR_VERSION, true );
        wp_localize_script( 'hgr-admin', 'HGR_DATA', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'exportUrl' => admin_url( 'admin-post.php' ),
            'nonce' => wp_create_nonce( 'hgr_admin' ),
            'exportNonce' => wp_create_nonce( 'hgr_export' ),
            'theme' => HGR_Theme::get_theme(),
            'today' => current_time( 'Y-m-d' ),
            'currency' => get_woocommerce_currency(),
            'canManageOptions' => current_user_can( 'manage_options' ),
            'options' => HGR_Reports::filter_options(),
            'settings' => $this->settings_payload(),
        ) );
        $css = HGR_Theme::get_custom_css();
        if ( $css ) wp_add_inline_style( 'hgr-admin', $css );
    }

    public function render() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( 'دسترسی کافی ندارید.' );
        HGR_Theme::render( 'admin/app.php', array( 'theme' => HGR_Theme::get_theme(), 'custom_css' => HGR_Theme::get_custom_css(), 'can_manage_options' => current_user_can( 'manage_options' ) ) );
    }

    private function verify_reports() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) wp_send_json_error( array( 'message' => 'دسترسی کافی ندارید.' ), 403 );
        check_ajax_referer( 'hgr_admin', 'nonce' );
    }

    private function verify_settings() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( array( 'message' => 'فقط مدیر سایت اجازه تغییر این تنظیمات را دارد.' ), 403 );
        check_ajax_referer( 'hgr_admin', 'nonce' );
    }

    public function ajax_report() {
        $this->verify_reports();
        nocache_headers();
        $type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : 'dashboard';
        $start = isset( $_POST['start'] ) ? sanitize_text_field( wp_unslash( $_POST['start'] ) ) : '';
        $end = isset( $_POST['end'] ) ? sanitize_text_field( wp_unslash( $_POST['end'] ) ) : '';
        $filters = isset( $_POST['filters'] ) ? HGR_Reports::sanitize_filters( $_POST['filters'] ) : array();
        try {
            $report = HGR_Reports::get_report( $type, $start, $end, $filters );
            if ( is_wp_error( $report ) ) wp_send_json_error( array( 'message' => $report->get_error_message() ), 400 );
            wp_send_json_success( $report );
        } catch ( Throwable $e ) {
            error_log( '[HGR 3.3 report error] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            wp_send_json_error( array(
                'message' => 'گزارش روی سرور با خطا متوقف شد. جزئیات در لاگ وردپرس ثبت شد: ' . sanitize_text_field( $e->getMessage() ),
                'type'    => $type,
            ), 500 );
        }
    }

    public function ajax_search_products() {
        $this->verify_reports();
        $term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
        if ( function_exists( 'mb_strlen' ) ? mb_strlen( $term, 'UTF-8' ) < 2 : strlen( $term ) < 2 ) {
            wp_send_json_success( array( 'items' => array() ) );
        }
        $items = array();
        try {
            $ids = array();
            if ( class_exists( 'WC_Data_Store' ) ) {
                try {
                    $store = WC_Data_Store::load( 'product' );
                    if ( is_object( $store ) && method_exists( $store, 'search_products' ) ) {
                        $ids = (array) $store->search_products( $term, '', true, false, 30, array() );
                    }
                } catch ( Throwable $search_error ) {
                    // WooCommerce has changed the product data-store search signature across versions.
                    // Fall through to the public product query rather than failing the report UI.
                    $ids = array();
                }
            }
            if ( ! $ids ) {
                $products = wc_get_products( array( 'status'=>array('publish','private'), 'limit'=>30, 'orderby'=>'title', 'order'=>'ASC', 'return'=>'objects', 's'=>$term ) );
                foreach ( (array) $products as $product ) if ( $product instanceof WC_Product ) $ids[]=$product->get_id();
            }
            foreach ( array_slice( array_values( array_unique( array_map( 'absint', $ids ) ) ), 0, 30 ) as $id ) {
                $product=wc_get_product($id);
                if(!$product)continue;
                $items[$product->get_id()]=array('id'=>$product->get_id(),'name'=>$product->get_name(),'sku'=>$product->get_sku());
            }
            // SKU fallback for stores where the product query search only matches title/content.
            if ( count( $items ) < 30 && function_exists( 'wc_get_product_id_by_sku' ) ) {
                $sku_id = wc_get_product_id_by_sku( $term );
                if ( $sku_id ) {
                    $product = wc_get_product( $sku_id );
                    if ( $product ) $items[ $product->get_id() ] = array( 'id'=>$product->get_id(), 'name'=>$product->get_name(), 'sku'=>$product->get_sku() );
                }
            }
        } catch ( Throwable $e ) {
            wp_send_json_error( array( 'message'=>'جستجوی محصول ناموفق بود: ' . sanitize_text_field( $e->getMessage() ) ), 500 );
        }
        wp_send_json_success( array( 'items'=>array_values( $items ) ) );
    }

    public function ajax_save_cancel_reason() {
        $this->verify_reports();
        $order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
        $reason = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '';
        $allowed = array( 'ثبت نشده', 'عدم پرداخت', 'انصراف مشتری', 'مشکل اسنپ‌پی', 'مشکل درگاه', 'عدم موجودی', 'قیمت', 'عدم پاسخ مشتری', 'اشتباه مشتری', 'سفارش تست', 'سایر' );
        if ( ! $order_id || ! in_array( $reason, $allowed, true ) ) wp_send_json_error( array( 'message' => 'اطلاعات نامعتبر است.' ), 400 );
        $order = wc_get_order( $order_id );
        if ( ! $order ) wp_send_json_error( array( 'message' => 'سفارش پیدا نشد.' ), 404 );
        if ( ! in_array( $order->get_status(), array( 'cancelled', 'failed' ), true ) ) wp_send_json_error( array( 'message' => 'دلیل لغو فقط برای سفارش لغوشده یا ناموفق قابل ثبت است.' ), 409 );
        if ( 'ثبت نشده' === $reason ) $order->delete_meta_data( '_hgr_cancel_reason' );
        else $order->update_meta_data( '_hgr_cancel_reason', $reason );
        $order->save();
        self::audit_note( $order, 'دلیل لغو در مرکز تحلیل فروش: ' . $reason );
        HGR_Reports::bump_cache_version();
        wp_send_json_success( array( 'message' => 'دلیل ذخیره شد.' ) );
    }

    private static function audit_note( $order, $text ) {
        if ( $order instanceof WC_Order ) $order->add_order_note( $text, false, false );
    }

    public function ajax_clear_cache() {
        $this->verify_reports();
        HGR_Reports::bump_cache_version();
        wp_send_json_success( array( 'message' => 'کش گزارش‌ها تازه شد.' ) );
    }

    public function ajax_save_ui() {
        $this->verify_settings();
        $theme = isset( $_POST['theme'] ) ? sanitize_key( wp_unslash( $_POST['theme'] ) ) : 'default';
        if ( ! in_array( $theme, array( 'default', 'compact', 'dark' ), true ) ) $theme = 'default';
        $css = isset( $_POST['css'] ) ? HGR_Theme::sanitize_css( wp_unslash( $_POST['css'] ) ) : '';
        update_option( HGR_Theme::OPTION_THEME, $theme, false );
        update_option( HGR_Theme::OPTION_CSS, $css, false );
        wp_send_json_success( array( 'message' => 'ظاهر افزونه ذخیره شد.' ) );
    }

    public function ajax_save_settings() {
        $this->verify_settings();
        $brand = isset( $_POST['brand_taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['brand_taxonomy'] ) ) : '';
        if ( $brand && ! taxonomy_exists( $brand ) ) $brand = '';
        $sales_statuses = array();
        if ( isset( $_POST['sales_statuses'] ) ) {
            $decoded_statuses = json_decode( wp_unslash( $_POST['sales_statuses'] ), true );
            if ( is_array( $decoded_statuses ) ) {
                $available = array_map( static function ( $s ) { return str_replace( 'wc-', '', $s ); }, array_keys( wc_get_order_statuses() ) );
                foreach ( $decoded_statuses as $st ) {
                    $st = str_replace( 'wc-', '', sanitize_key( $st ) );
                    if ( in_array( $st, $available, true ) ) $sales_statuses[] = $st;
                }
                $sales_statuses = array_values( array_unique( $sales_statuses ) );
            }
        }
        update_option( 'hgr_sales_statuses', $sales_statuses, false );
        $reference_mode = isset( $_POST['reference_mode'] ) ? sanitize_key( wp_unslash( $_POST['reference_mode'] ) ) : 'analytics';
        if ( ! in_array( $reference_mode, array( 'legacy', 'analytics' ), true ) ) $reference_mode = 'analytics';
        update_option( 'hgr_reference_mode', $reference_mode, false );
        $date_type = isset( $_POST['date_type'] ) ? sanitize_key( wp_unslash( $_POST['date_type'] ) ) : 'analytics';
        if ( ! in_array( $date_type, array( 'analytics', 'date_created', 'date_paid', 'date_completed' ), true ) ) $date_type = 'analytics';
        update_option( 'hgr_date_type_override', $date_type, false );
        update_option( 'hgr_enable_cart_tracking', isset( $_POST['enable_cart_tracking'] ) && 'yes' === sanitize_key( wp_unslash( $_POST['enable_cart_tracking'] ) ) ? 'yes' : 'no', false );
        $cost = isset( $_POST['cost_meta_key'] ) ? sanitize_key( wp_unslash( $_POST['cost_meta_key'] ) ) : '';
        $divisor = isset( $_POST['money_divisor'] ) ? sanitize_text_field( wp_unslash( $_POST['money_divisor'] ) ) : 'auto';
        if ( ! in_array( $divisor, array( 'auto', '1', '10' ), true ) ) $divisor = 'auto';
        $label = isset( $_POST['money_label'] ) ? sanitize_text_field( wp_unslash( $_POST['money_label'] ) ) : 'تومان';
        $map = array(
            'hgr_brand_taxonomy' => $brand,
            'hgr_cost_meta_key' => $cost,
            'hgr_money_divisor' => $divisor,
            'hgr_money_label' => $label,
            'hgr_vip_threshold' => max( 0, (float) ( $_POST['vip_threshold'] ?? 0 ) ),
            'hgr_risk_days' => max( 1, absint( $_POST['risk_days'] ?? 60 ) ),
            'hgr_lost_days' => max( 2, absint( $_POST['lost_days'] ?? 180 ) ),
            'hgr_abandoned_minutes' => max( 15, absint( $_POST['abandoned_minutes'] ?? 60 ) ),
            'hgr_tracking_retention_days' => max( 30, min( 3650, absint( $_POST['tracking_retention_days'] ?? 730 ) ) ),
            'hgr_alert_sales_drop' => max( 0, (float) ( $_POST['alert_sales_drop'] ?? 20 ) ),
            'hgr_alert_cancel_rate' => max( 0, (float) ( $_POST['alert_cancel_rate'] ?? 8 ) ),
            'hgr_alert_failed_rate' => max( 0, (float) ( $_POST['alert_failed_rate'] ?? 6 ) ),
            'hgr_alert_refund_rate' => max( 0, (float) ( $_POST['alert_refund_rate'] ?? 5 ) ),
        );
        if ( $map['hgr_lost_days'] <= $map['hgr_risk_days'] ) $map['hgr_lost_days'] = $map['hgr_risk_days'] + 30;
        foreach ( $map as $k => $v ) update_option( $k, $v, false );
        HGR_Reports::bump_cache_version();
        wp_send_json_success( array( 'message' => 'تنظیمات تحلیل ذخیره شد.', 'settings' => $this->settings_payload() ) );
    }

    private function settings_payload() {
        return array(
            'brand_taxonomy' => get_option( 'hgr_brand_taxonomy', '' ),
            'reference_mode' => get_option( 'hgr_reference_mode', 'analytics' ),
            'sales_statuses' => get_option( 'hgr_sales_statuses', array() ),
            'date_type' => get_option( 'hgr_date_type_override', 'analytics' ),
            'cost_meta_key' => get_option( 'hgr_cost_meta_key', '' ),
            'money_divisor' => get_option( 'hgr_money_divisor', 'auto' ),
            'money_label' => get_option( 'hgr_money_label', 'تومان' ),
            'vip_threshold' => get_option( 'hgr_vip_threshold', '10000000' ),
            'risk_days' => get_option( 'hgr_risk_days', '60' ),
            'lost_days' => get_option( 'hgr_lost_days', '180' ),
            'abandoned_minutes' => get_option( 'hgr_abandoned_minutes', '60' ),
            'tracking_retention_days' => get_option( 'hgr_tracking_retention_days', '730' ),
            'enable_cart_tracking' => get_option( 'hgr_enable_cart_tracking', 'yes' ),
            'alert_sales_drop' => get_option( 'hgr_alert_sales_drop', '20' ),
            'alert_cancel_rate' => get_option( 'hgr_alert_cancel_rate', '8' ),
            'alert_failed_rate' => get_option( 'hgr_alert_failed_rate', '6' ),
            'alert_refund_rate' => get_option( 'hgr_alert_refund_rate', '5' ),
            'tracking_started_at' => get_option( 'hgr_tracking_started_at', '' ),
        );
    }

    public function ajax_health() {
        $this->verify_reports();
        wp_send_json_success( HGR_Health::run() );
    }

    public function ajax_repair_tables() {
        $this->verify_settings();
        HGR_Tracker::install_tables();
        wp_send_json_success( array( 'message' => 'ساختار جدول‌های داخلی بررسی/تعمیر شد.', 'health' => HGR_Health::run() ) );
    }
}
