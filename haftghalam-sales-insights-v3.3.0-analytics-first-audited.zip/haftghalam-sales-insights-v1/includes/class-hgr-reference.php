<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WooCommerce Analytics reference adapter + active KPI profile selector.
 *
 * Active profiles:
 * - legacy: exact parity with WooCommerce > Reports > Sales by date.
 * - analytics: WooCommerce Analytics Orders Stats DataStore.
 */
final class HGR_Reference {
    public static function mode() {
        $mode = sanitize_key( (string) get_option( 'hgr_reference_mode', 'analytics' ) );
        return in_array( $mode, array( 'legacy', 'analytics' ), true ) ? $mode : 'analytics';
    }

    public static function analytics_date_type() {
        $override = sanitize_key( (string) get_option( 'hgr_date_type_override', 'analytics' ) );
        if ( in_array( $override, array( 'date_created', 'date_paid', 'date_completed' ), true ) ) {
            return $override;
        }
        $type = sanitize_key( (string) get_option( 'woocommerce_date_type', 'date_paid' ) );
        return in_array( $type, array( 'date_created', 'date_paid', 'date_completed' ), true ) ? $type : 'date_paid';
    }

    /** Date basis used by the active KPI profile and its CRUD supplements. */
    public static function date_type() {
        if ( 'legacy' === self::mode() ) return 'date_created';
        return self::analytics_date_type();
    }

    public static function date_type_source() {
        if ( 'legacy' === self::mode() ) return 'woocommerce_legacy_fixed_date_created';
        $override = sanitize_key( (string) get_option( 'hgr_date_type_override', 'analytics' ) );
        return in_array( $override, array( 'date_created', 'date_paid', 'date_completed' ), true ) ? 'hgr_override' : 'woocommerce_analytics';
    }

    public static function excluded_statuses() {
        $excluded = get_option( 'woocommerce_excluded_report_order_statuses', array( 'pending', 'failed', 'cancelled' ) );
        if ( ! is_array( $excluded ) ) $excluded = array( 'pending', 'failed', 'cancelled' );
        $excluded = array_map( static function ( $s ) {
            return str_replace( 'wc-', '', sanitize_key( $s ) );
        }, $excluded );
        $excluded = array_values( array_unique( array_merge( array( 'auto-draft', 'trash', 'checkout-draft' ), $excluded ) ) );
        return apply_filters( 'hgr_analytics_excluded_statuses', $excluded );
    }

    public static function analytics_included_statuses() {
        $excluded = self::excluded_statuses();
        $out = array();
        if ( function_exists( 'wc_get_order_statuses' ) ) {
            foreach ( array_keys( wc_get_order_statuses() ) as $key ) {
                $slug = str_replace( 'wc-', '', $key );
                if ( ! in_array( $slug, $excluded, true ) ) $out[] = $slug;
            }
        }
        return array_values( array_unique( $out ) );
    }

    /** Statuses used by the active KPI profile and CRUD supplements. */
    public static function included_statuses() {
        $manual = get_option( 'hgr_sales_statuses', array() );
        if ( is_string( $manual ) ) $manual = preg_split( '/[,\s]+/', $manual );
        if ( is_array( $manual ) && $manual ) {
            $out = array();
            foreach ( $manual as $s ) {
                $s = str_replace( 'wc-', '', sanitize_key( $s ) );
                if ( $s ) $out[] = $s;
            }
            return array_values( array_unique( $out ) );
        }
        if ( 'legacy' === self::mode() && class_exists( 'HGR_Legacy_Reference' ) ) {
            return HGR_Legacy_Reference::statuses();
        }
        return self::analytics_included_statuses();
    }

    public static function can_use_core() {
        if ( ! class_exists( 'WC_Data_Store' ) ) return false;
        global $wpdb;
        $table = $wpdb->prefix . 'wc_order_stats';
        return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
    }

    /** Filters natively supported by Woo Orders Stats DataStore. */
    public static function supports_filters( $filters ) {
        if ( ! is_array( $filters ) ) return true;
        $unsupported = array(
            'payment_methods', 'shipping_methods', 'state', 'city', 'brand_term_id',
            'source', 'device', 'customer_segment', 'min_total', 'max_total', 'search',
        );
        foreach ( $unsupported as $key ) {
            if ( isset( $filters[ $key ] ) && $filters[ $key ] !== '' && $filters[ $key ] !== array() ) return false;
        }
        return true;
    }

    private static function to_wc_datetime( $value ) {
        try {
            return new WC_DateTime( $value, wp_timezone() );
        } catch ( Throwable $e ) {
            return wc_string_to_datetime( $value );
        }
    }

    private static function query_args( $start, $end, $filters, $interval ) {
        $args = array(
            'after'      => self::to_wc_datetime( $start . ' 00:00:00' ),
            'before'     => self::to_wc_datetime( $end . ' 23:59:59' ),
            'interval'   => $interval,
            'page'       => 1,
            'per_page'   => 1000,
            'orderby'    => 'date',
            'order'      => 'asc',
            'date_type'  => self::analytics_date_type(),
            'fields'     => '*',
            'match'      => 'all',
        );

        if ( ! empty( $filters['statuses'] ) ) {
            // Explicit report filters are supported by the DataStore, but the
            // Analytics reference itself never inherits HGR's manual status override.
            $args['status_is'] = array_map( static function ( $s ) { return str_replace( 'wc-', '', sanitize_key( $s ) ); }, (array) $filters['statuses'] );
        }
        if ( ! empty( $filters['product_id'] ) ) {
            $pid = absint( $filters['product_id'] );
            $product = wc_get_product( $pid );
            if ( $product && $product->is_type( 'variation' ) ) $args['variation_includes'] = array( $pid );
            else $args['product_includes'] = array( $pid );
        }
        if ( ! empty( $filters['category_id'] ) ) $args['category_includes'] = array( absint( $filters['category_id'] ) );
        if ( ! empty( $filters['coupon'] ) && function_exists( 'wc_get_coupon_id_by_code' ) ) {
            $cid = wc_get_coupon_id_by_code( (string) $filters['coupon'] );
            $args['coupon_includes'] = array( $cid ? absint( $cid ) : 0 );
        }
        return $args;
    }

    private static function normalize_totals( $totals ) {
        $t = is_object( $totals ) ? get_object_vars( $totals ) : (array) $totals;
        $keys = array(
            'orders_count', 'num_items_sold', 'gross_sales', 'total_sales', 'coupons',
            'coupons_count', 'refunds', 'taxes', 'shipping', 'net_revenue',
            'avg_items_per_order', 'avg_order_value', 'total_customers', 'products',
        );
        $out = array();
        foreach ( $keys as $key ) $out[ $key ] = isset( $t[ $key ] ) && is_numeric( $t[ $key ] ) ? (float) $t[ $key ] : 0.0;
        $out['orders_count'] = (int) $out['orders_count'];
        $out['total_customers'] = (int) $out['total_customers'];
        $out['products'] = (int) $out['products'];
        return $out;
    }

    /** Always returns the WooCommerce Analytics reference, independent of active profile. */
    public static function stats( $start, $end, $filters = array(), $interval = 'day' ) {
        if ( ! self::can_use_core() || ! self::supports_filters( $filters ) ) {
            return new WP_Error( 'hgr_reference_unavailable', 'WooCommerce Analytics reference is unavailable for these filters.' );
        }
        try {
            $store = WC_Data_Store::load( 'report-orders-stats' );
            if ( ! is_object( $store ) || ! method_exists( $store, 'get_data' ) ) {
                return new WP_Error( 'hgr_reference_store_missing', 'WooCommerce Orders Stats DataStore is not available.' );
            }
            $data = $store->get_data( self::query_args( $start, $end, $filters, $interval ) );
            if ( is_wp_error( $data ) ) return $data;
            if ( ! is_object( $data ) || ! isset( $data->totals ) ) {
                return new WP_Error( 'hgr_reference_invalid', 'WooCommerce Analytics returned an unexpected payload.' );
            }
            $intervals = array();
            foreach ( (array) ( $data->intervals ?? array() ) as $row ) {
                $r = is_object( $row ) ? get_object_vars( $row ) : (array) $row;
                $sub = isset( $r['subtotals'] ) ? self::normalize_totals( $r['subtotals'] ) : self::normalize_totals( $r );
                $date = ! empty( $r['date_start'] ) ? substr( (string) $r['date_start'], 0, 10 ) : '';
                $intervals[] = array_merge( array(
                    'date'       => $date,
                    'date_start' => isset( $r['date_start'] ) ? (string) $r['date_start'] : '',
                    'date_end'   => isset( $r['date_end'] ) ? (string) $r['date_end'] : '',
                ), $sub );
            }
            return array(
                'totals' => self::normalize_totals( $data->totals ),
                'intervals' => $intervals,
                'source' => 'woocommerce_analytics_orders_stats',
                'date_type' => self::analytics_date_type(),
                'statuses' => self::analytics_included_statuses(),
                'uses_manual_statuses' => false,
                'definition_profile' => 'woocommerce_analytics',
            );
        } catch ( Throwable $e ) {
            return new WP_Error( 'hgr_reference_exception', $e->getMessage() );
        }
    }

    /** Return the active primary reference profile. */
    public static function primary_stats( $start, $end, $filters = array(), $interval = 'day' ) {
        if ( 'legacy' === self::mode() && class_exists( 'HGR_Legacy_Reference' ) ) {
            return HGR_Legacy_Reference::stats( $start, $end, $filters );
        }
        if ( ! empty( get_option( 'hgr_sales_statuses', array() ) ) ) {
            return new WP_Error( 'hgr_analytics_manual_status_override', 'Analytics Exact غیرفعال است چون وضعیت‌های فروش به‌صورت دستی Override شده‌اند.' );
        }
        return self::stats( $start, $end, $filters, $interval );
    }

    /**
     * Structural reconciliation for WooCommerce Analytics.
     *
     * This intentionally compares only the order cohort (same date basis and
     * included statuses) between Analytics lookup tables and the canonical
     * WooCommerce CRUD API. Financial definitions such as refund timing are
     * audited separately in the KPI audit report.
     */
    public static function analytics_sync_status( $start, $end ) {
        $cache_key = 'hgr33_sync_' . md5( get_option( 'hgr_cache_version', '1' ) . '|' . $start . '|' . $end . '|' . self::analytics_date_type() );
        $cached = get_transient( $cache_key );
        if ( false !== $cached && is_array( $cached ) ) return $cached;
        $out = array(
            'ready' => false, 'state' => 'unavailable', 'analytics_orders' => null,
            'crud_orders' => null, 'difference' => null, 'difference_pct' => null,
            'date_type' => self::analytics_date_type(), 'statuses' => self::analytics_included_statuses(),
            'latest_lookup_date' => '', 'message' => '',
        );
        if ( ! empty( get_option( 'hgr_sales_statuses', array() ) ) ) {
            $out['state'] = 'manual_override';
            $out['message'] = 'وضعیت‌های فروش در افزونه دستی Override شده‌اند؛ تطبیق Exact با Analytics ممکن نیست.';
            return $out;
        }
        $ref = self::stats( $start, $end, array(), 'day' );
        if ( is_wp_error( $ref ) ) {
            $out['message'] = $ref->get_error_message();
            return $out;
        }
        $out['analytics_orders'] = (int) ( $ref['totals']['orders_count'] ?? 0 );
        try {
            $args = array(
                'status' => $out['statuses'], 'limit' => 1, 'paginate' => true, 'return' => 'ids',
            );
            $args[ $out['date_type'] ] = $start . '...' . $end;
            $query = wc_get_orders( $args );
            if ( ! is_object( $query ) || ! isset( $query->total ) ) {
                $out['state'] = 'crud_unavailable';
                $out['message'] = 'WooCommerce CRUD تعداد سفارش قابل مقایسه برنگرداند.';
                return $out;
            }
            $out['crud_orders'] = (int) $query->total;
        } catch ( Throwable $e ) {
            $out['state'] = 'crud_error';
            $out['message'] = $e->getMessage();
            return $out;
        }

        $out['difference'] = $out['analytics_orders'] - $out['crud_orders'];
        $out['difference_pct'] = $out['crud_orders'] > 0 ? 100 * $out['difference'] / $out['crud_orders'] : ( 0 === $out['analytics_orders'] ? 0 : null );
        $out['ready'] = ( 0 === $out['difference'] );
        $out['state'] = $out['ready'] ? 'synced' : 'out_of_sync';
        $out['message'] = $out['ready']
            ? 'تعداد سفارش Analytics با Cohort متناظر WooCommerce CRUD تطبیق دارد.'
            : sprintf( 'Analytics=%d و CRUD=%d؛ اختلاف %+d سفارش.', $out['analytics_orders'], $out['crud_orders'], $out['difference'] );

        global $wpdb;
        $table = $wpdb->prefix . 'wc_order_stats';
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
            $col = in_array( $out['date_type'], array( 'date_created','date_paid','date_completed' ), true ) ? $out['date_type'] : 'date_paid';
            $latest = $wpdb->get_var( "SELECT MAX(`{$col}`) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $out['latest_lookup_date'] = $latest ? (string) $latest : '';
        }
        set_transient( $cache_key, $out, 5 * MINUTE_IN_SECONDS );
        return $out;
    }

    public static function map_to_hgr_summary( array $totals ) {
        return array(
            'orders'          => (int) ( $totals['orders_count'] ?? 0 ),
            'items'           => (float) ( $totals['num_items_sold'] ?? 0 ),
            'gross'           => (float) ( $totals['gross_sales'] ?? 0 ),
            'refunds'         => (float) ( $totals['refunds'] ?? 0 ),
            'discounts'       => (float) ( $totals['coupons'] ?? 0 ),
            'net'             => (float) ( $totals['net_revenue'] ?? 0 ),
            'tax'             => (float) ( $totals['taxes'] ?? 0 ),
            'shipping'        => (float) ( $totals['shipping'] ?? 0 ),
            'total_sales'     => (float) ( $totals['total_sales'] ?? 0 ),
            'aov'             => (float) ( $totals['avg_order_value'] ?? 0 ),
            'items_per_order' => (float) ( $totals['avg_items_per_order'] ?? 0 ),
            'customers_core'  => (int) ( $totals['total_customers'] ?? 0 ),
        );
    }
}
