<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class HGR_Plugin {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', array( $this, 'boot' ), 20 );
        add_action( 'hgr_daily_cleanup', array( 'HGR_Tracker', 'cleanup' ) );
    }

    public function boot() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            add_action( 'admin_notices', array( $this, 'woocommerce_notice' ) );
            return;
        }
        $installed = (string) get_option( 'hgr_plugin_version', '' );
        if ( HGR_VERSION !== $installed ) {
            HGR_Tracker::install_tables();
            self::install_defaults();
            self::migrate_reference_policy( $installed );
            update_option( 'hgr_plugin_version', HGR_VERSION, false );
        }
        if ( ! wp_next_scheduled( 'hgr_daily_cleanup' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'hgr_daily_cleanup' );
        }
        HGR_Admin::instance();
        HGR_Tracker::instance();
    }

    public function woocommerce_notice() {
        if ( current_user_can( 'activate_plugins' ) ) {
            echo '<div class="notice notice-error"><p>افزونه «مرکز تحلیل فروش هفت‌قلم» برای اجرا به WooCommerce نیاز دارد.</p></div>';
        }
    }

    public static function activate() {
        HGR_Tracker::install_tables();
        self::install_defaults();
        self::migrate_reference_policy( (string) get_option( 'hgr_plugin_version', '' ) );
        update_option( 'hgr_plugin_version', HGR_VERSION, false );
        if ( ! wp_next_scheduled( 'hgr_daily_cleanup' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'hgr_daily_cleanup' );
        }
    }

    public static function deactivate() {
        $timestamp = wp_next_scheduled( 'hgr_daily_cleanup' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'hgr_daily_cleanup' );
        }
    }

    private static function migrate_reference_policy( $installed ) {
        // v3.3 establishes the final Analytics-first policy requested for KPI:
        // Analytics = canonical base, CRUD = advanced/supplemental analysis,
        // Legacy = reconciliation/control. Run this once per upgraded install.
        if ( false === get_option( 'hgr_reference_policy_v33', false ) ) {
            update_option( 'hgr_reference_mode', 'analytics', false );
            update_option( 'hgr_date_type_override', 'analytics', false );
            add_option( 'hgr_reference_policy_v33', 'analytics_first', '', false );
        }
    }

    private static function install_defaults() {
        $defaults = array(
            'hgr_cache_version'          => '1',
            'hgr_theme'                  => 'default',
            'hgr_custom_css'             => '',
            'hgr_brand_taxonomy'         => '',
            'hgr_sales_statuses'          => array(),
            'hgr_reference_mode'           => 'analytics',
            'hgr_date_type_override'      => 'analytics',
            'hgr_tracking_retention_days' => '730',
            'hgr_enable_cart_tracking'    => 'yes',
            'hgr_cost_meta_key'          => '',
            'hgr_money_divisor'          => 'auto',
            'hgr_money_label'            => 'تومان',
            'hgr_vip_threshold'          => '10000000',
            'hgr_risk_days'              => '60',
            'hgr_lost_days'              => '180',
            'hgr_abandoned_minutes'      => '60',
            'hgr_alert_sales_drop'       => '20',
            'hgr_alert_cancel_rate'      => '8',
            'hgr_alert_failed_rate'      => '6',
            'hgr_alert_refund_rate'      => '5',
            'hgr_tracking_started_at'    => current_time( 'mysql' ),
        );
        foreach ( $defaults as $key => $value ) {
            if ( false === get_option( $key, false ) ) {
                add_option( $key, $value, '', false );
            }
        }
    }
}
