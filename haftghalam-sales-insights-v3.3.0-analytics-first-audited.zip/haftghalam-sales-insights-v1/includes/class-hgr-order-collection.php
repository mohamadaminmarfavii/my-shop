<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Lightweight order collection for high-volume stores.
 *
 * Stores only order IDs in memory and hydrates WC_Order objects one at a time
 * while iterating. This avoids retaining thousands of WC_Order objects in RAM.
 */
final class HGR_Order_Collection implements IteratorAggregate, Countable {
    /** @var int[] */
    private $ids = array();

    public function __construct( $ids = array() ) {
        $this->ids = array_values( array_unique( array_map( 'absint', is_array( $ids ) ? $ids : array() ) ) );
    }

    public function getIterator(): Traversable {
        foreach ( $this->ids as $id ) {
            $order = wc_get_order( $id );
            if ( $order instanceof WC_Order ) {
                yield $id => $order;
            }
            // Give PHP a chance to reclaim the hydrated order before the next one.
            unset( $order );
        }
    }

    public function count(): int {
        return count( $this->ids );
    }

    public function ids(): array {
        return $this->ids;
    }
}
