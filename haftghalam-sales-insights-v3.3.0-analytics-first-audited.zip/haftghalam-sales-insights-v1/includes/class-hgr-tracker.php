<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class HGR_Tracker {
    private static $instance = null;
    private static $cache_invalidated = false;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'woocommerce_cart_updated', array( $this, 'capture_cart' ), 20 );
        add_action( 'woocommerce_add_to_cart', array( $this, 'capture_cart' ), 20 );
        add_action( 'woocommerce_cart_emptied', array( $this, 'capture_empty_cart' ), 20 );

        // A checkout order is not necessarily a successful conversion. Record
        // its id first; mark the cart converted only after payment/success.
        add_action( 'woocommerce_checkout_order_created', array( $this, 'mark_order_created' ), 20 );
        add_action( 'woocommerce_payment_complete', array( $this, 'mark_paid_conversion' ), 20 );
        add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 20, 4 );

        add_action( 'woocommerce_product_set_stock_status', array( $this, 'record_stock_status' ), 20, 3 );
        add_action( 'woocommerce_variation_set_stock_status', array( $this, 'record_stock_status' ), 20, 3 );
        add_action( 'woocommerce_product_set_stock', array( $this, 'record_stock_qty' ), 20 );
        add_action( 'woocommerce_variation_set_stock', array( $this, 'record_stock_qty' ), 20 );

        // KPI cache must never remain stale after order/refund mutations.
        foreach ( array( 'woocommerce_new_order', 'woocommerce_update_order', 'woocommerce_delete_order' ) as $hook ) {
            add_action( $hook, array( $this, 'invalidate_reports' ), 50 );
        }
        add_action( 'woocommerce_order_refunded', array( $this, 'invalidate_reports' ), 50, 2 );
        add_action( 'woocommerce_order_partially_refunded', array( $this, 'invalidate_reports' ), 50, 2 );
        add_action( 'woocommerce_order_fully_refunded', array( $this, 'invalidate_reports' ), 50, 2 );
        add_action( 'woocommerce_delete_order_refund', array( $this, 'invalidate_reports' ), 50 );
    }

    public static function cart_table() {
        global $wpdb;
        return $wpdb->prefix . 'hgr_cart_sessions';
    }

    public static function stock_table() {
        global $wpdb;
        return $wpdb->prefix . 'hgr_stock_events';
    }

    public static function install_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $cart = self::cart_table();
        $stock = self::stock_table();

        $sql_cart = "CREATE TABLE {$cart} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_key varchar(64) NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            email varchar(190) NOT NULL DEFAULT '',
            phone varchar(80) NOT NULL DEFAULT '',
            cart_total decimal(20,4) NOT NULL DEFAULT 0,
            item_count int(11) NOT NULL DEFAULT 0,
            items longtext NULL,
            source varchar(190) NOT NULL DEFAULT '',
            device varchar(40) NOT NULL DEFAULT '',
            first_seen datetime NOT NULL,
            last_seen datetime NOT NULL,
            created_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            converted_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
            converted_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_key (session_key),
            KEY last_seen (last_seen),
            KEY created_order_id (created_order_id),
            KEY converted_order_id (converted_order_id),
            KEY user_id (user_id)
        ) {$charset};";

        $sql_stock = "CREATE TABLE {$stock} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            product_id bigint(20) unsigned NOT NULL,
            stock_status varchar(30) NOT NULL DEFAULT '',
            stock_qty decimal(20,4) NULL,
            happened_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY product_time (product_id,happened_at),
            KEY happened_at (happened_at)
        ) {$charset};";

        dbDelta( $sql_cart );
        dbDelta( $sql_stock );
    }

    private function session_key() {
        if ( ! function_exists( 'WC' ) || ! WC()->session ) return '';
        $raw = (string) WC()->session->get_customer_id();
        return '' === $raw ? '' : hash_hmac( 'sha256', $raw, wp_salt( 'auth' ) );
    }

    private function device_type() {
        $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) ) : '';
        if ( false !== strpos( $ua, 'tablet' ) || false !== strpos( $ua, 'ipad' ) ) return 'tablet';
        if ( wp_is_mobile() ) return 'mobile';
        return $ua ? 'desktop' : 'unknown';
    }

    /** First-touch source; do not replace it with an internal referrer later. */
    private function source() {
        foreach ( array( 'utm_source', 'gclid', 'fbclid' ) as $key ) {
            if ( ! empty( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $v = sanitize_text_field( wp_unslash( $_GET[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                if ( 'utm_source' === $key ) return strtolower( $v );
                return $key;
            }
        }
        $ref = wp_get_raw_referer();
        if ( ! $ref ) return 'direct';
        $host = strtolower( (string) wp_parse_url( $ref, PHP_URL_HOST ) );
        $home_host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
        if ( ! $host || $host === $home_host ) return 'direct';
        return sanitize_text_field( $host );
    }

    private function tracking_enabled() {
        return 'yes' === (string) get_option( 'hgr_enable_cart_tracking', 'yes' );
    }

    private function pii_hash( $value ) {
        $value = strtolower( trim( (string) $value ) );
        return '' === $value ? '' : 'h:' . hash_hmac( 'sha256', $value, wp_salt( 'auth' ) );
    }

    public function capture_cart() {
        if ( ! $this->tracking_enabled() ) return;
        if ( is_admin() && ! wp_doing_ajax() ) return;
        if ( ! function_exists( 'WC' ) || ! WC()->cart ) return;
        $key = $this->session_key();
        if ( ! $key ) return;

        $items = array();
        foreach ( WC()->cart->get_cart() as $cart_item ) {
            $product = isset( $cart_item['data'] ) && $cart_item['data'] instanceof WC_Product ? $cart_item['data'] : null;
            $items[] = array(
                'product_id' => isset( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0,
                'variation_id' => isset( $cart_item['variation_id'] ) ? absint( $cart_item['variation_id'] ) : 0,
                'name' => $product ? $product->get_name() : '',
                'qty' => isset( $cart_item['quantity'] ) ? (float) $cart_item['quantity'] : 0,
            );
        }
        $customer = WC()->customer;
        $email = $customer ? sanitize_email( $customer->get_billing_email() ) : '';
        $phone = $customer ? sanitize_text_field( $customer->get_billing_phone() ) : '';
        $this->upsert_cart( $key, $this->pii_hash( $email ), $this->pii_hash( $phone ), (float) WC()->cart->get_cart_contents_total(), (int) WC()->cart->get_cart_contents_count(), $items );
    }

    public function capture_empty_cart() {
        if ( ! $this->tracking_enabled() ) return;
        $key = $this->session_key();
        if ( ! $key ) return;
        global $wpdb;
        // Mark intentionally emptied carts as empty without destroying the
        // original source attribution or conversion/order linkage.
        $wpdb->update( self::cart_table(), array( 'cart_total'=>0, 'item_count'=>0, 'items'=>'[]', 'last_seen'=>current_time( 'mysql' ) ), array( 'session_key'=>$key ), array( '%f','%d','%s','%s' ), array( '%s' ) );
    }

    private function upsert_cart( $key, $email, $phone, $total, $count, array $items ) {
        global $wpdb;
        $table = self::cart_table();
        $now = current_time( 'mysql' );
        $existing = $wpdb->get_row( $wpdb->prepare( "SELECT id,source FROM {$table} WHERE session_key=%s LIMIT 1", $key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $first_source = $existing && ! empty( $existing['source'] ) ? $existing['source'] : $this->source();
        $data = array(
            'user_id' => get_current_user_id(),
            'email' => $email,
            'phone' => $phone,
            'cart_total' => $total,
            'item_count' => $count,
            'items' => wp_json_encode( $items, JSON_UNESCAPED_UNICODE ),
            'source' => $first_source,
            'device' => $this->device_type(),
            'last_seen' => $now,
        );
        $format = array( '%d','%s','%s','%f','%d','%s','%s','%s','%s' );
        if ( $existing ) {
            $wpdb->update( $table, $data, array( 'id'=>absint( $existing['id'] ) ), $format, array( '%d' ) );
        } else {
            $data['session_key'] = $key;
            $data['first_seen'] = $now;
            $data['created_order_id'] = 0;
            $data['converted_order_id'] = 0;
            $data['converted_at'] = null;
            $wpdb->insert( $table, $data, array_merge( $format, array( '%s','%s','%d','%d','%s' ) ) );
        }
    }

    public function mark_order_created( $order ) {
        if ( ! $this->tracking_enabled() ) return;
        if ( ! $order instanceof WC_Order ) return;
        $key = $this->session_key();
        if ( ! $key ) return;
        global $wpdb;
        $wpdb->update( self::cart_table(), array( 'created_order_id'=>$order->get_id(), 'last_seen'=>current_time( 'mysql' ) ), array( 'session_key'=>$key ), array( '%d','%s' ), array( '%s' ) );
        $this->invalidate_reports();
    }

    public function mark_paid_conversion( $order_or_id ) {
        if ( ! $this->tracking_enabled() ) return;
        $order = $order_or_id instanceof WC_Order ? $order_or_id : wc_get_order( absint( $order_or_id ) );
        if ( ! $order instanceof WC_Order ) return;
        global $wpdb;
        $data = array( 'converted_order_id'=>$order->get_id(), 'converted_at'=>current_time( 'mysql' ), 'last_seen'=>current_time( 'mysql' ) );
        $where = array( 'created_order_id'=>$order->get_id() );
        $updated = $wpdb->update( self::cart_table(), $data, $where, array( '%d','%s','%s' ), array( '%d' ) );
        if ( ! $updated ) {
            $key = $this->session_key();
            if ( $key ) $wpdb->update( self::cart_table(), $data, array( 'session_key'=>$key ), array( '%d','%s','%s' ), array( '%s' ) );
        }
        $this->invalidate_reports();
    }

    public function on_order_status_changed( $order_id, $from, $to, $order ) {
        $to = str_replace( 'wc-', '', sanitize_key( $to ) );
        if ( in_array( $to, HGR_Reports::sales_statuses_for_diagnostics(), true ) ) {
            $this->mark_paid_conversion( $order instanceof WC_Order ? $order : $order_id );
        }
        $this->invalidate_reports();
    }

    public function invalidate_reports() {
        if ( self::$cache_invalidated ) return;
        self::$cache_invalidated = true;
        HGR_Reports::bump_cache_version();
    }

    public function record_stock_status( $product_id, $stock_status, $product = null ) {
        $qty = $product instanceof WC_Product && $product->managing_stock() ? $product->get_stock_quantity() : null;
        self::insert_stock_event( absint( $product_id ), sanitize_key( $stock_status ), $qty );
    }

    public function record_stock_qty( $product ) {
        if ( ! $product instanceof WC_Product ) return;
        self::insert_stock_event( $product->get_id(), $product->get_stock_status(), $product->managing_stock() ? $product->get_stock_quantity() : null );
    }

    private static function insert_stock_event( $product_id, $status, $qty ) {
        if ( ! $product_id ) return;
        global $wpdb;
        $table = self::stock_table();
        $last = $wpdb->get_row( $wpdb->prepare( "SELECT stock_status, stock_qty FROM {$table} WHERE product_id=%d ORDER BY id DESC LIMIT 1", $product_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( $last && $last['stock_status'] === $status && (string) $last['stock_qty'] === (string) $qty ) return;
        $wpdb->insert( $table, array( 'product_id'=>$product_id, 'stock_status'=>$status, 'stock_qty'=>null === $qty ? null : (float) $qty, 'happened_at'=>current_time( 'mysql' ) ), array( '%d','%s','%f','%s' ) );
        HGR_Reports::bump_cache_version();
    }

    public static function cleanup() {
        global $wpdb;
        $days = max( 30, min( 3650, absint( get_option( 'hgr_tracking_retention_days', 730 ) ) ) );
        $cutoff_dt = new DateTimeImmutable( 'now', wp_timezone() );
        $cutoff = $cutoff_dt->modify( '-' . $days . ' days' )->format( 'Y-m-d H:i:s' );
        $cart = self::cart_table();
        $stock = self::stock_table();
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$cart} WHERE last_seen < %s", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$stock} WHERE happened_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }
}
