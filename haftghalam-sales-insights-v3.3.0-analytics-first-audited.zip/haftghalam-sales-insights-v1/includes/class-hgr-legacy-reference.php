<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Exact adapter for WooCommerce > Reports > Sales by date (legacy report).
 *
 * Important: this intentionally delegates the headline figures to WooCommerce's
 * own WC_Report_Sales_By_Date class instead of re-implementing its formulas.
 * Therefore, when the legacy report is available on the store, Orders / Items /
 * Net sales / Total sales / Refunds / Shipping / Coupons use the exact same
 * report engine as wp-admin/admin.php?page=wc-reports&tab=orders&report=sales_by_date.
 */
final class HGR_Legacy_Reference {
    public static function statuses() {
        return array( 'completed', 'processing', 'on-hold', 'refunded' );
    }

    public static function supports_filters( $filters ) {
        if ( ! is_array( $filters ) ) return true;
        $copy = $filters;
        unset( $copy['compare'], $copy['customer_segment'] );
        foreach ( $copy as $value ) {
            if ( is_array( $value ) && $value ) return false;
            if ( ! is_array( $value ) && '' !== (string) $value ) return false;
        }
        return true;
    }

    private static function load_classes() {
        if ( ! function_exists( 'WC' ) || ! WC() ) {
            return new WP_Error( 'hgr_legacy_no_wc', 'WooCommerce is not available.' );
        }
        $base = trailingslashit( WC()->plugin_path() ) . 'includes/admin/reports/';
        if ( ! class_exists( 'WC_Admin_Report' ) ) {
            $file = $base . 'class-wc-admin-report.php';
            if ( ! is_readable( $file ) ) return new WP_Error( 'hgr_legacy_parent_missing', 'WooCommerce legacy report base class is not available.' );
            require_once $file;
        }
        if ( ! class_exists( 'WC_Report_Sales_By_Date' ) ) {
            $file = $base . 'class-wc-report-sales-by-date.php';
            if ( ! is_readable( $file ) ) return new WP_Error( 'hgr_legacy_report_missing', 'WooCommerce Sales by Date legacy report is not available.' );
            require_once $file;
        }
        return true;
    }

    public static function available() {
        return ! is_wp_error( self::load_classes() );
    }

    private static function day_key( $value ) {
        $value = (string) $value;
        return strlen( $value ) >= 10 ? substr( $value, 0, 10 ) : '';
    }

    private static function add_field_by_day( &$days, $rows, $date_field, $value_field, $target, $absolute = false ) {
        foreach ( (array) $rows as $row ) {
            $date = self::day_key( isset( $row->{$date_field} ) ? $row->{$date_field} : '' );
            if ( ! $date || ! isset( $days[ $date ] ) ) continue;
            $v = isset( $row->{$value_field} ) && is_numeric( $row->{$value_field} ) ? (float) $row->{$value_field} : 0.0;
            if ( $absolute ) $v = abs( $v );
            $days[ $date ][ $target ] += $v;
        }
    }

    private static function intervals( $start, $end, $data ) {
        $days = array();
        try {
            $cursor = new DateTimeImmutable( $start, wp_timezone() );
            $last   = new DateTimeImmutable( $end, wp_timezone() );
            while ( $cursor <= $last ) {
                $date = $cursor->format( 'Y-m-d' );
                $days[ $date ] = array(
                    'date' => $date,
                    'orders_count' => 0.0,
                    'num_items_sold' => 0.0,
                    'gross_sales' => 0.0,
                    'total_sales' => 0.0,
                    'coupons' => 0.0,
                    'refunds' => 0.0,
                    'taxes' => 0.0,
                    'shipping' => 0.0,
                    'net_revenue' => 0.0,
                    'avg_items_per_order' => 0.0,
                    'avg_order_value' => 0.0,
                    // Internal pieces used to reconstruct the legacy formulas.
                    '_order_total' => 0.0,
                    '_shipping_original' => 0.0,
                    '_tax_original' => 0.0,
                    '_shipping_refunded' => 0.0,
                    '_tax_refunded' => 0.0,
                    '_net_refund' => 0.0,
                );
                $cursor = $cursor->modify( '+1 day' );
            }
        } catch ( Throwable $e ) {
            return array();
        }

        self::add_field_by_day( $days, $data->order_counts ?? array(), 'post_date', 'count', 'orders_count' );
        self::add_field_by_day( $days, $data->order_items ?? array(), 'post_date', 'order_item_count', 'num_items_sold' );
        self::add_field_by_day( $days, $data->orders ?? array(), 'post_date', 'total_sales', '_order_total' );
        self::add_field_by_day( $days, $data->orders ?? array(), 'post_date', 'total_shipping', '_shipping_original' );
        self::add_field_by_day( $days, $data->orders ?? array(), 'post_date', 'total_tax', '_tax_original' );
        self::add_field_by_day( $days, $data->orders ?? array(), 'post_date', 'total_shipping_tax', '_tax_original' );
        self::add_field_by_day( $days, $data->coupons ?? array(), 'post_date', 'discount_amount', 'coupons' );
        self::add_field_by_day( $days, $data->refund_lines ?? array(), 'post_date', 'total_refund', 'refunds' );
        self::add_field_by_day( $days, $data->refunded_orders ?? array(), 'post_date', 'total_shipping', '_shipping_refunded', true );
        self::add_field_by_day( $days, $data->refunded_orders ?? array(), 'post_date', 'total_tax', '_tax_refunded', true );
        self::add_field_by_day( $days, $data->refunded_orders ?? array(), 'post_date', 'total_shipping_tax', '_tax_refunded', true );
        self::add_field_by_day( $days, $data->refunded_orders ?? array(), 'post_date', 'net_refund', '_net_refund' );

        foreach ( $days as &$row ) {
            // These equations mirror WC_Report_Sales_By_Date::query_report_data().
            $row['shipping'] = $row['_shipping_original'] - $row['_shipping_refunded'];
            $row['taxes'] = $row['_tax_original'] - $row['_tax_refunded'];
            $row['total_sales'] = $row['_order_total'] - $row['refunds'];
            // Legacy UI calls total_sales "gross sales"; preserve that definition
            // in Legacy Exact mode so the plugin can reproduce the same screen.
            $row['gross_sales'] = $row['total_sales'];
            $row['net_revenue'] = $row['total_sales'] - $row['shipping'] - max( 0.0, $row['taxes'] );
            $orders = (int) $row['orders_count'];
            $row['avg_order_value'] = $orders ? $row['net_revenue'] / $orders : 0.0;
            $row['avg_items_per_order'] = $orders ? $row['num_items_sold'] / $orders : 0.0;
            unset( $row['_order_total'], $row['_shipping_original'], $row['_tax_original'], $row['_shipping_refunded'], $row['_tax_refunded'], $row['_net_refund'] );
        }
        unset( $row );
        return array_values( $days );
    }

    public static function stats( $start, $end, $filters = array() ) {
        if ( ! empty( get_option( 'hgr_sales_statuses', array() ) ) ) {
            return new WP_Error( 'hgr_legacy_manual_status_override', 'Legacy Exact غیرفعال است چون وضعیت‌های فروش به‌صورت دستی Override شده‌اند.' );
        }
        if ( ! self::supports_filters( $filters ) ) {
            return new WP_Error( 'hgr_legacy_filters_unsupported', 'WooCommerce Legacy Exact is only available for the unfiltered date report.' );
        }
        $loaded = self::load_classes();
        if ( is_wp_error( $loaded ) ) return $loaded;

        $old_start_exists = array_key_exists( 'start_date', $_GET );
        $old_end_exists   = array_key_exists( 'end_date', $_GET );
        $old_start = $old_start_exists ? $_GET['start_date'] : null;
        $old_end   = $old_end_exists ? $_GET['end_date'] : null;

        try {
            // calculate_current_range('custom') is the same range parser used by
            // the actual WooCommerce legacy report screen.
            $_GET['start_date'] = $start;
            $_GET['end_date']   = $end;
            $report = new WC_Report_Sales_By_Date();
            $report->calculate_current_range( 'custom' );
            $data = $report->get_report_data();
            if ( ! is_object( $data ) ) {
                return new WP_Error( 'hgr_legacy_invalid', 'WooCommerce legacy report returned an unexpected payload.' );
            }

            $total_tax = (float) ( $data->total_tax ?? 0 ) + (float) ( $data->total_shipping_tax ?? 0 );
            $orders = absint( $data->total_orders ?? 0 );
            $items  = absint( $data->total_items ?? 0 );
            $net    = (float) ( $data->net_sales ?? 0 );
            $total  = (float) ( $data->total_sales ?? 0 );
            $totals = array(
                'orders_count' => $orders,
                'num_items_sold' => $items,
                // The legacy report labels total_sales as gross sales. This is
                // intentionally not WooCommerce Analytics' pre-discount Gross.
                'gross_sales' => $total,
                'total_sales' => $total,
                'coupons' => (float) ( $data->total_coupons ?? 0 ),
                'coupons_count' => 0,
                'refunds' => (float) ( $data->total_refunds ?? 0 ),
                'taxes' => $total_tax,
                'shipping' => (float) ( $data->total_shipping ?? 0 ),
                'net_revenue' => $net,
                'avg_items_per_order' => $orders ? $items / $orders : 0.0,
                'avg_order_value' => $orders ? $net / $orders : 0.0,
                'total_customers' => 0,
                'products' => 0,
                'refunded_orders' => absint( $data->total_refunded_orders ?? 0 ),
                'refunded_items' => absint( $data->refunded_order_items ?? 0 ),
                'shipping_tax' => (float) ( $data->total_shipping_tax ?? 0 ),
                'product_tax' => (float) ( $data->total_tax ?? 0 ),
            );

            return array(
                'totals' => $totals,
                'intervals' => self::intervals( $start, $end, $data ),
                'source' => 'woocommerce_legacy_sales_by_date_exact',
                'date_type' => 'date_created',
                'statuses' => self::statuses(),
                'uses_manual_statuses' => false,
                'definition_profile' => 'woocommerce_legacy_sales_by_date',
            );
        } catch ( Throwable $e ) {
            return new WP_Error( 'hgr_legacy_exception', $e->getMessage() );
        } finally {
            if ( $old_start_exists ) $_GET['start_date'] = $old_start; else unset( $_GET['start_date'] );
            if ( $old_end_exists ) $_GET['end_date'] = $old_end; else unset( $_GET['end_date'] );
        }
    }

    public static function map_to_hgr_summary( array $totals ) {
        return array(
            'orders' => (int) ( $totals['orders_count'] ?? 0 ),
            'items' => (float) ( $totals['num_items_sold'] ?? 0 ),
            'gross' => (float) ( $totals['gross_sales'] ?? 0 ),
            'refunds' => (float) ( $totals['refunds'] ?? 0 ),
            'discounts' => (float) ( $totals['coupons'] ?? 0 ),
            'net' => (float) ( $totals['net_revenue'] ?? 0 ),
            'tax' => (float) ( $totals['taxes'] ?? 0 ),
            'shipping' => (float) ( $totals['shipping'] ?? 0 ),
            'total_sales' => (float) ( $totals['total_sales'] ?? 0 ),
            'aov' => (float) ( $totals['avg_order_value'] ?? 0 ),
            'items_per_order' => (float) ( $totals['avg_items_per_order'] ?? 0 ),
            'customers_core' => 0,
        );
    }
}
