<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class HGR_Health {
    public static function run() {
        global $wpdb;
        $checks = array();
        $checks[] = self::check( 'WooCommerce', class_exists( 'WooCommerce' ), class_exists( 'WooCommerce' ) ? 'نسخه ' . WC_VERSION : 'غیرفعال' );
        $checks[] = self::check( 'PHP', version_compare( PHP_VERSION, '7.4', '>=' ), PHP_VERSION );
        $checks[] = array( 'name'=>'نسخه موتور KPI', 'status'=>'pass', 'message'=>'HGR ' . HGR_VERSION . ' | Analytics-First + CRUD + Legacy Control + Sync Gate' );

        $hpos = false; $hpos_known = false;
        if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil' ) && method_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil', 'custom_orders_table_usage_is_enabled' ) ) {
            $hpos_known = true;
            $hpos = \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
        }
        $checks[] = array( 'name'=>'HPOS', 'status'=>$hpos_known ? 'pass' : 'warn', 'message'=>$hpos_known ? ( $hpos ? 'فعال؛ افزونه برای گزارش‌های مدرن از CRUD/Analytics استفاده می‌کند و Legacy Exact فقط در صورت موجود بودن گزارش کلاسیک خود WooCommerce اجرا می‌شود.' : 'غیرفعال؛ مسیر CRUD و Legacy Exact هر دو قابل استفاده‌اند.' ) : 'وضعیت HPOS قابل تشخیص نبود.' );

        $cart = HGR_Tracker::cart_table();
        $stock = HGR_Tracker::stock_table();
        $cart_ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $cart ) ) === $cart;
        $stock_ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stock ) ) === $stock;
        $checks[] = self::check( 'جدول ردیابی سبد', $cart_ok, $cart_ok ? 'آماده' : 'نیازمند تعمیر/فعال‌سازی مجدد' );
        $checks[] = self::check( 'جدول تاریخچه موجودی', $stock_ok, $stock_ok ? 'آماده' : 'نیازمند تعمیر/فعال‌سازی مجدد' );

        if ( $cart_ok ) {
            $columns = $wpdb->get_col( "SHOW COLUMNS FROM {$cart}", 0 ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $schema_ok = in_array( 'created_order_id', $columns, true ) && in_array( 'converted_at', $columns, true );
            $checks[] = self::check( 'Schema سبد v3', $schema_ok, $schema_ok ? 'تفکیک سفارش ایجادشده از تبدیل پرداخت‌شده فعال است.' : 'دکمه تعمیر جدول‌ها را اجرا کن.' );
        }

        $cron = wp_next_scheduled( 'hgr_daily_cleanup' );
        $checks[] = self::check( 'پاکسازی زمان‌بندی‌شده', (bool) $cron, $cron ? 'فعال؛ نگهداری ' . absint( get_option( 'hgr_tracking_retention_days', 730 ) ) . ' روز' : 'برنامه‌ریزی نشده' );

        $override = trailingslashit( get_stylesheet_directory() ) . 'haftghalam-reports/admin/app.php';
        $checks[] = array( 'name'=>'قالب UI سفارشی', 'status'=>'pass', 'message'=>is_readable( $override ) ? 'Override فعال است.' : 'از UI داخلی افزونه استفاده می‌شود.' );

        $query_ok = false; $query_message = '';
        try {
            $sample = wc_get_orders( array( 'limit'=>1, 'return'=>'ids' ) );
            $query_ok = is_array( $sample );
            $query_message = $query_ok ? 'خواندن سفارش با WooCommerce CRUD موفق بود.' : 'پاسخ غیرمنتظره';
        } catch ( Throwable $e ) { $query_message = $e->getMessage(); }
        $checks[] = self::check( 'خواندن سفارش‌ها', $query_ok, $query_message );

        $stats_table = $wpdb->prefix . 'wc_order_stats';
        $customer_table = $wpdb->prefix . 'wc_customer_lookup';
        $product_lookup = $wpdb->prefix . 'wc_order_product_lookup';
        $stats_ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stats_table ) ) === $stats_table;
        $customer_ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $customer_table ) ) === $customer_table;
        $product_ok = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $product_lookup ) ) === $product_lookup;
        $checks[] = array(
            'name'=>'جداول Analytics ووکامرس',
            'status'=>( $stats_ok && $customer_ok && $product_ok ) ? 'pass' : 'warn',
            'message'=>( $stats_ok && $customer_ok && $product_ok ) ? 'wc_order_stats / wc_customer_lookup / wc_order_product_lookup موجودند.' : 'یک یا چند جدول Analytics ناقص است؛ KPI مرجع ممکن است به CRUD fallback برود.',
        );

        $reference_mode = HGR_Reference::mode();
        $date_type = HGR_Reference::date_type();
        $date_source = HGR_Reference::date_type_source();
        $checks[] = array(
            'name'=>'مرجع اصلی KPI',
            'status'=>'pass',
            'message'=>( 'legacy' === $reference_mode ? 'WooCommerce Reports — Legacy Exact' : 'WooCommerce Analytics' ) . ' | date=' . $date_type,
        );
        $checks[] = array(
            'name'=>'مبنای تاریخ KPI',
            'status'=>'pass',
            'message'=>$date_type . ' | منبع تنظیم: ' . $date_source,
        );

        // Compare each WooCommerce report engine against a CRUD cohort built on
        // that engine's own date/status basis. Never compare Analytics totals to
        // a Legacy cohort or vice versa.
        $today = current_time( 'Y-m-d' );
        $start30 = wp_date( 'Y-m-d', strtotime( $today . ' -29 days' ), wp_timezone() );

        $legacy_statuses = HGR_Legacy_Reference::statuses();
        $analytics_statuses = HGR_Reference::analytics_included_statuses();
        $legacy_crud = -1; $analytics_crud = -1;
        try {
            $r = wc_get_orders( array(
                'status'=>$legacy_statuses, 'date_created'=>$start30.'...'.$today,
                'limit'=>1, 'paginate'=>true, 'return'=>'ids'
            ) );
            if ( is_object( $r ) && isset( $r->total ) ) $legacy_crud=(int)$r->total;
        } catch ( Throwable $e ) {}
        try {
            $analytics_date = HGR_Reference::analytics_date_type();
            $args = array( 'status'=>$analytics_statuses, 'limit'=>1, 'paginate'=>true, 'return'=>'ids' );
            $args[$analytics_date] = $start30.'...'.$today;
            $r = wc_get_orders( $args );
            if ( is_object( $r ) && isset( $r->total ) ) $analytics_crud=(int)$r->total;
        } catch ( Throwable $e ) {}

        $legacy_ref = HGR_Legacy_Reference::stats( $start30, $today, array() );
        if ( is_wp_error( $legacy_ref ) ) {
            $checks[] = array( 'name'=>'WooCommerce Legacy Exact', 'status'=>'warn', 'message'=>$legacy_ref->get_error_message() );
        } else {
            $legacy_orders=(int)$legacy_ref['totals']['orders_count'];
            $delta=$legacy_crud>=0 ? $legacy_orders-$legacy_crud : null;
            $checks[] = array(
                'name'=>'Legacy Reports ↔ CRUD cohort',
                'status'=>( null!==$delta && 0===$delta ) ? 'pass' : 'warn',
                'message'=>'Legacy Exact: '.$legacy_orders.' | CRUD date_created/status legacy: '.($legacy_crud>=0?$legacy_crud:'?').' | اختلاف: '.(null===$delta?'?':sprintf('%+d',$delta)),
            );
        }

        $analytics_ref = HGR_Reference::stats( $start30, $today, array(), 'day' );
        if ( is_wp_error( $analytics_ref ) ) {
            $checks[] = array( 'name'=>'WooCommerce Analytics', 'status'=>'warn', 'message'=>$analytics_ref->get_error_message() );
        } else {
            $analytics_orders=(int)$analytics_ref['totals']['orders_count'];
            $delta=$analytics_crud>=0 ? $analytics_orders-$analytics_crud : null;
            $checks[] = array(
                'name'=>'Analytics ↔ CRUD cohort',
                'status'=>( null!==$delta && 0===$delta ) ? 'pass' : 'warn',
                'message'=>'Analytics: '.$analytics_orders.' | CRUD '.HGR_Reference::analytics_date_type().': '.($analytics_crud>=0?$analytics_crud:'?').' | اختلاف: '.(null===$delta?'?':sprintf('%+d',$delta)),
            );
        }

        $sync_gate = HGR_Reference::analytics_sync_status( $start30, $today );
        $checks[] = array(
            'name'=>'آمادگی Analytics برای KPI',
            'status'=>!empty($sync_gate['ready']) ? 'pass' : 'warn',
            'message'=>(!empty($sync_gate['ready']) ? 'آماده و Sync؛ KPI پایه می‌تواند تأییدشده باشد. ' : 'هنوز آماده نیست؛ KPI پایه نباید تأییدشده تلقی شود. ') . ($sync_gate['message'] ?? ''),
        );

        if ( ! is_wp_error( $legacy_ref ) && ! is_wp_error( $analytics_ref ) ) {
            $legacy_orders=(int)$legacy_ref['totals']['orders_count'];
            $analytics_orders=(int)$analytics_ref['totals']['orders_count'];
            $checks[] = array(
                'name'=>'اختلاف دو موتور WooCommerce',
                'status'=>$legacy_orders===$analytics_orders ? 'pass' : 'warn',
                'message'=>sprintf('۳۰ روز اخیر — Legacy=%d | Analytics=%d | اختلاف=%+d. این اختلاف می‌تواند طبیعی باشد چون تاریخ/وضعیت/تعریف گزارش متفاوت است.', $legacy_orders, $analytics_orders, $legacy_orders-$analytics_orders),
            );
        }

        $sales_statuses = HGR_Reports::sales_statuses_for_diagnostics();
        $crud_count = ( 'legacy' === $reference_mode ) ? $legacy_crud : $analytics_crud;
        $created_count = $legacy_crud;
        if ( $stats_ok ) {
            $date_col = in_array( $date_type, array( 'date_created','date_paid','date_completed' ), true ) ? $date_type : 'date_paid';
            $latest = $wpdb->get_var( "SELECT MAX(`{$date_col}`) FROM {$stats_table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $checks[] = array( 'name'=>'تازگی wc_order_stats', 'status'=>$latest ? 'pass' : 'warn', 'message'=>$latest ? 'آخرین رکورد روی مبنای ' . $date_col . ': ' . $latest : 'هیچ تاریخ معتبری در lookup پیدا نشد.' );
        }

        // Sample historical COGS and attribution coverage without scanning the
        // whole store. This tells the user whether profit/source KPIs are truly
        // supported by stored data.
        $cogs_total = 0; $cogs_known = 0; $attr_total = 0; $attr_known = 0;
        try {
            $sample = wc_get_orders( array( 'status'=>$sales_statuses, 'limit'=>100, 'return'=>'objects', 'orderby'=>'date', 'order'=>'DESC' ) );
            foreach ( (array) $sample as $order ) {
                if ( ! $order instanceof WC_Order ) continue;
                foreach ( $order->get_items( 'line_item' ) as $item ) {
                    $cogs_total++;
                    // Historical COGS is considered known only when WooCommerce
                    // actually persisted _cogs_value on the order item. A numeric
                    // getter alone can report zero for missing/disabled COGS.
                    if ( method_exists( $item, 'get_meta' ) ) {
                        $v = $item->get_meta( '_cogs_value', true );
                        if ( '' !== $v && null !== $v && is_numeric( $v ) ) $cogs_known++;
                    }
                }
                $attr_total++;
                $known = false;
                foreach ( array( '_wc_order_attribution_utm_source','_wc_order_attribution_source_type','_wc_order_attribution_referrer' ) as $k ) {
                    if ( trim( (string) $order->get_meta( $k, true ) ) ) { $known=true; break; }
                }
                if ( $known ) $attr_known++;
            }
        } catch ( Throwable $e ) {}
        $cogs_pct = $cogs_total ? round( 100 * $cogs_known / $cogs_total, 1 ) : 0;
        $attr_pct = $attr_total ? round( 100 * $attr_known / $attr_total, 1 ) : 0;
        $checks[] = array( 'name'=>'پوشش COGS تاریخی نمونه', 'status'=>$cogs_pct >= 95 ? 'pass' : 'warn', 'message'=>$cogs_pct . '% از Line Itemهای نمونه COGS تاریخی دارند. سود فقط به اندازه پوشش داده قابل اتکاست.' );
        $checks[] = array( 'name'=>'پوشش Attribution نمونه', 'status'=>$attr_pct >= 80 ? 'pass' : 'warn', 'message'=>$attr_pct . '% از سفارش‌های نمونه منبع/Attribution ذخیره‌شده دارند؛ Unknown حدس زده نمی‌شود.' );

        $memory_limit = ini_get( 'memory_limit' );
        $max_execution = ini_get( 'max_execution_time' );
        $checks[] = array( 'name'=>'ظرفیت PHP گزارش‌گیری', 'status'=>'pass', 'message'=>'memory_limit=' . $memory_limit . ' | max_execution_time=' . $max_execution . 's | موتور سفارش‌ها ID-based/streaming است.' );

        $brand = HGR_Reports::brand_taxonomy();
        $checks[] = array( 'name'=>'برند', 'status'=>$brand ? 'pass' : 'warn', 'message'=>$brand ? 'Taxonomy: ' . $brand : 'Taxonomy برند پیدا نشد؛ گزارش برند قابل تفکیک دقیق نیست تا تنظیم شود.' );

        $fail = count( array_filter( $checks, static function ( $c ) { return 'fail' === $c['status']; } ) );
        $warn = count( array_filter( $checks, static function ( $c ) { return 'warn' === $c['status']; } ) );
        return array(
            'checks'=>$checks,
            'summary'=>array( 'fail'=>$fail, 'warn'=>$warn, 'pass'=>count( $checks )-$fail-$warn ),
            'reference'=>array( 'range'=>array( $start30,$today ), 'mode'=>$reference_mode, 'date_type'=>$date_type, 'statuses'=>$sales_statuses, 'crud_orders'=>$crud_count, 'created_orders'=>$created_count ),
        );
    }

    private static function check( $name, $ok, $message ) {
        return array( 'name'=>$name, 'status'=>$ok ? 'pass' : 'fail', 'message'=>$message );
    }
}
