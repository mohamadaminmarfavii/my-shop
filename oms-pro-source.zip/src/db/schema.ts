// Replaces the current app's single localStorage/IndexedDB blob (and the
// nested LEGACY_HTML string) with real, indexed Dexie tables — one per
// entity from the spec. Nothing here stores a pre-computed total; totals
// are always derived at read time via src/finance/engine.ts.

import Dexie, { type EntityTable } from 'dexie';
import type {
  Order,
  OrderItem,
  CustomerReceipt,
  SnappSettlement,
  SupplierPayment,
  SupplierRefund,
  Expense,
  CustomerRefund,
  ProfitShareRule,
  ProfitSharePayment,
  CashWithdrawal,
  OpeningBalance,
  AuditLogEntry,
} from '../finance/types';

export const SCHEMA_VERSION = 1;

export class OmsProDatabase extends Dexie {
  orders!: EntityTable<Order, 'id'>;
  orderItems!: EntityTable<OrderItem, 'id'>;
  customerReceipts!: EntityTable<CustomerReceipt, 'id'>;
  snappSettlements!: EntityTable<SnappSettlement, 'id'>;
  supplierPayments!: EntityTable<SupplierPayment, 'id'>;
  supplierRefunds!: EntityTable<SupplierRefund, 'id'>;
  expenses!: EntityTable<Expense, 'id'>;
  customerRefunds!: EntityTable<CustomerRefund, 'id'>;
  profitShareRules!: EntityTable<ProfitShareRule, 'id'>;
  profitSharePayments!: EntityTable<ProfitSharePayment, 'id'>;
  cashWithdrawals!: EntityTable<CashWithdrawal, 'id'>;
  openingBalances!: EntityTable<OpeningBalance, 'id'>;
  auditLog!: EntityTable<AuditLogEntry, 'id'>;

  constructor() {
    super('oms_pro_v2');
    // PaymentAllocation is intentionally NOT a persisted table here — it is
    // a derived view, recomputed from supplierPayments + orderItems by
    // recomputeSupplierAllocations() (see src/finance/engine.ts) and cached
    // per-supplier in a plain key/value cache table if needed for
    // performance, never hand-edited.
    this.version(SCHEMA_VERSION).stores({
      orders: 'id, customerCode, orderDateIso, status, channel',
      orderItems: 'id, orderId, productId, supplierId',
      customerReceipts: 'id, orderId, dateIso',
      snappSettlements: 'id, orderId',
      supplierPayments: 'id, supplierId, dateIso, status',
      supplierRefunds: 'id, supplierId, relatedPaymentId, dateIso',
      expenses: 'id, orderId, category, dateIso',
      customerRefunds: 'id, orderId, dateIso',
      profitShareRules: 'id, partnerId, scopeSupplierId, scopeProductId',
      profitSharePayments: 'id, ruleId, dateIso',
      cashWithdrawals: 'id, dateIso',
      openingBalances: 'id, periodKey',
      auditLog: 'id, entity, entityId, action, timestampIso',
    });
  }
}

export const db = new OmsProDatabase();
