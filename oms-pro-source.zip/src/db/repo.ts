// Every mutation in the app goes through this module so that (a) AuditLog
// always gets an entry, and (b) PaymentAllocation is never hand-edited —
// it's always re-derived via recomputeSupplierAllocations from the live
// data. Pages should only ever call functions from here, never touch
// `db` directly.

import { db } from './schema';
import type {
  Order,
  OrderItem,
  SupplierPayment,
  SupplierRefund,
  CustomerReceipt,
  SnappSettlement,
  Expense,
  CustomerRefund,
  ProfitShareRule,
  ProfitSharePayment,
  CashWithdrawal,
  ID,
} from '../finance/types';
import {
  recomputeSupplierAllocations,
  computeOrderEconomics,
  computeConfirmedCollection,
  computeCollectedProfit,
  computeWithdrawableProfit,
  type OpenDebtItem,
} from '../finance/engine';

export function genId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function nowIso(): string {
  return new Date().toISOString();
}

async function audit(
  entity: string,
  entityId: ID,
  action: 'create' | 'update' | 'delete' | 'restore' | 'sync',
  before: unknown,
  after: unknown,
  actor = 'user',
) {
  await db.auditLog.add({
    id: genId(),
    entity,
    entityId,
    action,
    before,
    after,
    actor,
    timestampIso: nowIso(),
  });
}

// ---------------------------------------------------------------------------
// Orders / items
// ---------------------------------------------------------------------------

export async function listOrders(): Promise<Order[]> {
  return db.orders.toArray();
}

export async function listItemsForOrder(orderId: ID): Promise<OrderItem[]> {
  return db.orderItems.where('orderId').equals(orderId).toArray();
}

export async function listAllItems(): Promise<OrderItem[]> {
  return db.orderItems.toArray();
}

export async function getOrder(id: ID): Promise<Order | undefined> {
  return db.orders.get(id);
}

export async function addOrderWithItems(order: Order, items: OrderItem[]): Promise<void> {
  await db.transaction('rw', db.orders, db.orderItems, db.auditLog, async () => {
    await db.orders.add(order);
    await db.orderItems.bulkAdd(items);
    await audit('Order', order.id, 'create', null, { order, items });
  });
}

// ---------------------------------------------------------------------------
// Open debt (order items not yet fully paid to their supplier)
// ---------------------------------------------------------------------------

export async function getOpenDebtItems(supplierId?: ID): Promise<OpenDebtItem[]> {
  const items = supplierId
    ? await db.orderItems.where('supplierId').equals(supplierId).toArray()
    : await db.orderItems.toArray();

  const orderIds = Array.from(new Set(items.map((it) => it.orderId)));
  const orders = await db.orders.bulkGet(orderIds);
  const orderById = new Map(orders.filter((o): o is Order => !!o).map((o) => [o.id, o]));

  return items
    .filter((it) => {
      const order = orderById.get(it.orderId);
      return order && order.status !== 'cancelled';
    })
    .map((it) => ({
      orderItemId: it.id,
      supplierId: it.supplierId,
      orderDateIso: orderById.get(it.orderId)!.orderDateIso,
      cost: it.qty * it.buyPrice,
    }));
}

// ---------------------------------------------------------------------------
// Supplier payments — the only writable table; PaymentAllocation is always
// derived from this + getOpenDebtItems(), never stored as a mutable ledger.
// ---------------------------------------------------------------------------

export interface NewSupplierPaymentInput {
  supplierId: ID;
  amount: number;
  dateIso: string;
  source: string;
  note?: string;
  targetMode: 'fifo' | 'targeted';
  targetItemIds?: ID[];
}

export async function addSupplierPayment(input: NewSupplierPaymentInput): Promise<SupplierPayment> {
  const payment: SupplierPayment = {
    id: genId(),
    status: 'active',
    ...input,
  };
  await db.transaction('rw', db.supplierPayments, db.auditLog, async () => {
    await db.supplierPayments.add(payment);
    await audit('SupplierPayment', payment.id, 'create', null, payment);
  });
  return payment;
}

export async function updateSupplierPayment(
  id: ID,
  patch: Partial<Omit<SupplierPayment, 'id' | 'supplierId'>>,
): Promise<void> {
  await db.transaction('rw', db.supplierPayments, db.auditLog, async () => {
    const before = await db.supplierPayments.get(id);
    if (!before) throw new Error(`Supplier payment ${id} not found`);
    const after: SupplierPayment = { ...before, ...patch };
    await db.supplierPayments.put(after);
    await audit('SupplierPayment', id, 'update', before, after);
  });
}

export async function softDeleteSupplierPayment(id: ID): Promise<void> {
  await db.transaction('rw', db.supplierPayments, db.auditLog, async () => {
    const before = await db.supplierPayments.get(id);
    if (!before) throw new Error(`Supplier payment ${id} not found`);
    const after: SupplierPayment = { ...before, status: 'deleted' };
    await db.supplierPayments.put(after);
    await audit('SupplierPayment', id, 'delete', before, after);
  });
}

export async function restoreSupplierPayment(id: ID): Promise<void> {
  await db.transaction('rw', db.supplierPayments, db.auditLog, async () => {
    const before = await db.supplierPayments.get(id);
    if (!before) throw new Error(`Supplier payment ${id} not found`);
    const after: SupplierPayment = { ...before, status: 'active' };
    await db.supplierPayments.put(after);
    await audit('SupplierPayment', id, 'restore', before, after);
  });
}

export async function listSupplierPayments(supplierId: ID): Promise<SupplierPayment[]> {
  return db.supplierPayments.where('supplierId').equals(supplierId).toArray();
}

export async function listActiveSupplierPayments(supplierId: ID): Promise<SupplierPayment[]> {
  const all = await listSupplierPayments(supplierId);
  return all.filter((p) => p.status === 'active');
}

/**
 * The live, derived allocation view for one supplier. Always recomputed —
 * never read from a stored table — so it is automatically idempotent and
 * automatically correct after any edit/delete/restore.
 */
export async function getSupplierAllocations(supplierId: ID) {
  const [payments, items] = await Promise.all([
    listSupplierPayments(supplierId),
    getOpenDebtItems(supplierId),
  ]);
  return recomputeSupplierAllocations(supplierId, payments, items);
}

export async function runSupplierSync(supplierId: ID): Promise<{
  before: ReturnType<typeof recomputeSupplierAllocations>;
  after: ReturnType<typeof recomputeSupplierAllocations>;
}> {
  // Because allocations are always derived, "sync" has nothing to repair —
  // recomputing twice back to back proves idempotency live, and the audit
  // log records that a sync was requested and confirmed with no changes.
  const before = await getSupplierAllocations(supplierId);
  const after = await getSupplierAllocations(supplierId);
  await audit('SupplierAllocations', supplierId, 'sync', before, after);
  return { before, after };
}

// ---------------------------------------------------------------------------
// Other financial entities — thin, audited CRUD
// ---------------------------------------------------------------------------

export async function addSupplierRefund(input: Omit<SupplierRefund, 'id'>): Promise<SupplierRefund> {
  const refund: SupplierRefund = { id: genId(), ...input };
  await db.supplierRefunds.add(refund);
  await audit('SupplierRefund', refund.id, 'create', null, refund);
  return refund;
}

export async function addCustomerReceipt(input: Omit<CustomerReceipt, 'id'>): Promise<CustomerReceipt> {
  const receipt: CustomerReceipt = { id: genId(), ...input };
  await db.customerReceipts.add(receipt);
  await audit('CustomerReceipt', receipt.id, 'create', null, receipt);
  return receipt;
}

export async function listReceiptsForOrder(orderId: ID): Promise<CustomerReceipt[]> {
  return db.customerReceipts.where('orderId').equals(orderId).toArray();
}

export interface FullOrderData {
  orders: Order[];
  itemsByOrder: Map<ID, OrderItem[]>;
  receiptsByOrder: Map<ID, CustomerReceipt[]>;
  snappByOrder: Map<ID, SnappSettlement>;
}

/** One shared read for every report page — same source, same shape, every time. */
export async function loadFullOrderData(): Promise<FullOrderData> {
  const [orders, items, receipts, snapps] = await Promise.all([
    db.orders.toArray(),
    db.orderItems.toArray(),
    db.customerReceipts.toArray(),
    db.snappSettlements.toArray(),
  ]);

  const itemsByOrder = new Map<ID, OrderItem[]>();
  for (const it of items) {
    const arr = itemsByOrder.get(it.orderId) ?? [];
    arr.push(it);
    itemsByOrder.set(it.orderId, arr);
  }
  const receiptsByOrder = new Map<ID, CustomerReceipt[]>();
  for (const r of receipts) {
    const arr = receiptsByOrder.get(r.orderId) ?? [];
    arr.push(r);
    receiptsByOrder.set(r.orderId, arr);
  }
  const snappByOrder = new Map(snapps.map((s) => [s.orderId, s]));

  return { orders, itemsByOrder, receiptsByOrder, snappByOrder };
}

export async function upsertSnappSettlement(settlement: SnappSettlement): Promise<void> {
  const before = await db.snappSettlements.get(settlement.id);
  await db.snappSettlements.put(settlement);
  await audit('SnappSettlement', settlement.id, before ? 'update' : 'create', before ?? null, settlement);
}

export async function getSnappSettlementForOrder(orderId: ID): Promise<SnappSettlement | undefined> {
  return db.snappSettlements.where('orderId').equals(orderId).first();
}

export async function addExpense(input: Omit<Expense, 'id'>): Promise<Expense> {
  const expense: Expense = { id: genId(), ...input };
  await db.expenses.add(expense);
  await audit('Expense', expense.id, 'create', null, expense);
  return expense;
}

export async function addCustomerRefund(input: Omit<CustomerRefund, 'id'>): Promise<CustomerRefund> {
  const refund: CustomerRefund = { id: genId(), ...input };
  await db.customerRefunds.add(refund);
  await audit('CustomerRefund', refund.id, 'create', null, refund);
  return refund;
}

export async function addProfitShareRule(input: Omit<ProfitShareRule, 'id'>): Promise<ProfitShareRule> {
  const rule: ProfitShareRule = { id: genId(), ...input };
  await db.profitShareRules.add(rule);
  await audit('ProfitShareRule', rule.id, 'create', null, rule);
  return rule;
}

export async function addProfitSharePayment(
  input: Omit<ProfitSharePayment, 'id'>,
): Promise<ProfitSharePayment> {
  const payment: ProfitSharePayment = { id: genId(), ...input };
  await db.profitSharePayments.add(payment);
  await audit('ProfitSharePayment', payment.id, 'create', null, payment);
  return payment;
}

export async function addCashWithdrawal(input: Omit<CashWithdrawal, 'id'>): Promise<CashWithdrawal> {
  const withdrawal: CashWithdrawal = { id: genId(), ...input };
  await db.cashWithdrawals.add(withdrawal);
  await audit('CashWithdrawal', withdrawal.id, 'create', null, withdrawal);
  return withdrawal;
}

// ---------------------------------------------------------------------------
// Cash balance — a real, derived number, never a stored counter.
// ---------------------------------------------------------------------------

export async function computeRealCashBalance(): Promise<number> {
  const [orders, receipts, snapps, payments, expenses, withdrawals, sharePayments, supplierRefunds] =
    await Promise.all([
      db.orders.toArray(),
      db.customerReceipts.toArray(),
      db.snappSettlements.toArray(),
      db.supplierPayments.toArray(),
      db.expenses.toArray(),
      db.cashWithdrawals.toArray(),
      db.profitSharePayments.toArray(),
      db.supplierRefunds.toArray(),
    ]);

  const ordersById = new Map(orders.map((o) => [o.id, o]));
  const isCancelled = (orderId: ID) => ordersById.get(orderId)?.status === 'cancelled';

  const cashIn = receipts
    .filter((r) => !isCancelled(r.orderId))
    .reduce((sum, r) => sum + r.amount, 0);

  const snappIn = snapps.reduce((sum, s) => {
    if (isCancelled(s.orderId) || !s.payoutConfirmed) return sum;
    const net = s.recordedAmount - s.commission - s.vatOnCommission;
    const payout = Math.round(net * (1 - s.holdbackPct / 100));
    const holdback = s.holdbackReleased ? Math.round(net * (s.holdbackPct / 100)) : 0;
    return sum + payout + holdback;
  }, 0);

  const supplierOut = payments
    .filter((p) => p.status === 'active')
    .reduce((sum, p) => sum + p.amount, 0);

  const refundsIn = supplierRefunds.reduce((sum, r) => sum + r.amount, 0);
  const expensesOut = expenses.reduce((sum, e) => sum + e.amount, 0);
  const withdrawalsOut = withdrawals.reduce((sum, w) => sum + w.amount, 0);
  const shareOut = sharePayments.reduce((sum, p) => sum + p.amount, 0);

  return cashIn + snappIn + refundsIn - supplierOut - expensesOut - withdrawalsOut - shareOut;
}

// ---------------------------------------------------------------------------
// Dashboard aggregate — every number here is derived, on every read, from
// the same functions the other pages use. Nothing is a stored total.
// ---------------------------------------------------------------------------

export interface DashboardSummary {
  ordersCount: number;
  grossSale: number;
  cost: number;
  accruedProfit: number;
  collectedProfitRemaining: number;
  cashBalance: number;
  withdrawableProfit: number;
}

export async function getDashboardSummary(): Promise<DashboardSummary> {
  const [orders, items, receipts, snapps, sharePayments] = await Promise.all([
    db.orders.toArray(),
    db.orderItems.toArray(),
    db.customerReceipts.toArray(),
    db.snappSettlements.toArray(),
    db.profitSharePayments.toArray(),
  ]);

  const itemsByOrder = new Map<ID, OrderItem[]>();
  for (const it of items) {
    const arr = itemsByOrder.get(it.orderId) ?? [];
    arr.push(it);
    itemsByOrder.set(it.orderId, arr);
  }
  const receiptsByOrder = new Map<ID, CustomerReceipt[]>();
  for (const r of receipts) {
    const arr = receiptsByOrder.get(r.orderId) ?? [];
    arr.push(r);
    receiptsByOrder.set(r.orderId, arr);
  }
  const snappByOrder = new Map(snapps.map((s) => [s.orderId, s]));

  let grossSale = 0;
  let cost = 0;
  let accruedProfit = 0;
  let collectedProfitTotal = 0;

  for (const order of orders) {
    const orderItems = itemsByOrder.get(order.id) ?? [];
    const snapp = snappByOrder.get(order.id);
    const econ = computeOrderEconomics(order, orderItems, { snapp });
    grossSale += econ.grossSale;
    cost += econ.cost;
    accruedProfit += econ.accruedProfit;
    const collected = computeConfirmedCollection(order, receiptsByOrder.get(order.id) ?? [], snapp);
    collectedProfitTotal += computeCollectedProfit(econ, collected);
  }

  const shareOut = sharePayments.reduce((sum, p) => sum + p.amount, 0);
  const collectedProfitRemaining = Math.max(0, collectedProfitTotal - shareOut);
  const cashBalance = await computeRealCashBalance();
  const withdrawableProfit = computeWithdrawableProfit(cashBalance, collectedProfitRemaining, 0);

  return {
    ordersCount: orders.length,
    grossSale,
    cost,
    accruedProfit,
    collectedProfitRemaining,
    cashBalance,
    withdrawableProfit,
  };
}
