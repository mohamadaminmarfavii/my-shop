import { useEffect, useState } from 'react';

export function useHashRoute(defaultRoute: string): [string, (route: string) => void] {
  const [route, setRoute] = useState(() => window.location.hash.slice(1) || defaultRoute);

  useEffect(() => {
    const onHashChange = () => setRoute(window.location.hash.slice(1) || defaultRoute);
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, [defaultRoute]);

  const navigate = (next: string) => {
    window.location.hash = next;
  };

  return [route, navigate];
}
