import { useRegisterSW } from 'virtual:pwa-register/react';

export function UpdateNotice() {
  const {
    needRefresh: [needRefresh],
    offlineReady: [offlineReady, setOfflineReady],
    updateServiceWorker,
  } = useRegisterSW({});

  if (needRefresh) {
    return (
      <div className="update-banner">
        <span>نسخهٔ جدید برنامه آماده است.</span>
        <button className="btn-primary" onClick={() => updateServiceWorker(true)}>
          به‌روزرسانی برنامه
        </button>
      </div>
    );
  }

  if (offlineReady) {
    return (
      <div className="update-banner subtle">
        <span>برنامه برای اجرای آفلاین آماده است.</span>
        <button className="btn-secondary" onClick={() => setOfflineReady(false)}>
          باشه
        </button>
      </div>
    );
  }

  return null;
}
