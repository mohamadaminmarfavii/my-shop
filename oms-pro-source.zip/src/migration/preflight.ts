// Pure, side-effect-free checks run during the Migration Wizard's Dry Run
// step, before anything is written to the database. Every check here
// mirrors a risk named in the analysis report (duplicate IDs, unresolved
// supplier names, unknown statuses/channels, impossible stored profit).

import type { LegacyOrder } from './mapLegacyOrder';
import { normalizeSupplierName } from './supplierAlias';

export type IssueSeverity = 'error' | 'warning';

export interface MigrationIssue {
  orderId: string;
  code: string;
  severity: IssueSeverity;
  message: string;
}

const KNOWN_STATUSES = new Set(['جدید', 'درحال تامین', 'ارسال شد', 'تحویل شد', 'لغو شد']);
const KNOWN_CHANNELS = new Set(['اسنپ‌پی', 'نقد', 'سایت خودم', 'اعتباری مستقیم']);

function naiveRecomputeProfit(order: LegacyOrder): number {
  const itemCost = order.items.reduce((sum, it) => sum + (it.qty ?? 1) * (it.buyPrice ?? 0), 0);
  const revenue = order.revenue ?? 0;
  const fee = order.snappFee ?? order.paymentGatewayFee ?? 0;
  const discount = order.discount ?? 0;
  return revenue - itemCost - fee - discount;
}

export function runPreflightChecks(orders: LegacyOrder[]): MigrationIssue[] {
  const issues: MigrationIssue[] = [];
  const seenIds = new Map<string, number>();

  for (const order of orders) {
    if (!order.id) {
      issues.push({
        orderId: '(بدون شناسه)',
        code: 'missing-id',
        severity: 'error',
        message: 'سفارش بدون شناسهٔ ثابت — قابل مهاجرت نیست',
      });
    } else {
      seenIds.set(order.id, (seenIds.get(order.id) ?? 0) + 1);
    }

    if (order.status && !KNOWN_STATUSES.has(order.status)) {
      issues.push({
        orderId: order.id,
        code: 'unknown-status',
        severity: 'warning',
        message: `وضعیت ناشناخته: "${order.status}"`,
      });
    }

    if (order.orderChannel && !KNOWN_CHANNELS.has(order.orderChannel)) {
      issues.push({
        orderId: order.id,
        code: 'unknown-channel',
        severity: 'warning',
        message: `کانال فروش ناشناخته: "${order.orderChannel}"`,
      });
    } else if (!order.orderChannel) {
      issues.push({
        orderId: order.id,
        code: 'missing-channel',
        severity: 'warning',
        message: 'کانال فروش ثبت نشده — به‌صورت موقت «نقد» فرض می‌شود',
      });
    }

    if (!normalizeSupplierName(order.supplier)) {
      issues.push({
        orderId: order.id,
        code: 'unresolved-supplier',
        severity: 'warning',
        message: `نام تأمین‌کننده ناشناخته: "${order.supplier || '(خالی)'}"`,
      });
    }

    for (const item of order.items ?? []) {
      if (!Number.isFinite(item.buyPrice) || !Number.isFinite(item.salePrice)) {
        issues.push({
          orderId: order.id,
          code: 'invalid-item-price',
          severity: 'error',
          message: `قلم ${item.id}: بهای خرید یا فروش عدد معتبر نیست`,
        });
      }
    }

    if (order.status !== 'لغو شد' && typeof order.profit === 'number' && typeof order.revenue === 'number') {
      const naive = naiveRecomputeProfit(order);
      if (Math.abs(order.profit - naive) > 1000) {
        issues.push({
          orderId: order.id,
          code: 'suspicious-profit',
          severity: 'warning',
          message: `سود ذخیره‌شدهٔ قدیمی (${order.profit.toLocaleString('fa-IR')} ت) با بازمحاسبهٔ ساده (${naive.toLocaleString('fa-IR')} ت) نمی‌خواند — عدد جدید همیشه از روی اقلام بازمحاسبه می‌شود`,
        });
      }
    }
  }

  for (const [id, count] of seenIds) {
    if (count > 1) {
      issues.push({
        orderId: id,
        code: 'duplicate-id',
        severity: 'error',
        message: `شناسهٔ سفارش تکراری است (${count.toLocaleString('fa-IR')} بار در فایل)`,
      });
    }
  }

  return issues;
}
