// Pure mapping from the legacy backup's order shape (as found in the real
// manual_2026-09-05-21-11-26.json export) to the new Order/OrderItem/
// SnappSettlement types. Never guesses silently — anything it can't map
// with confidence goes into `warnings` for the Migration Wizard's
// pre-flight report, per the "no auto-zeroing real data" rule.

import type { Order, OrderItem, OrderStatus, OrderChannel, SnappSettlement } from '../finance/types';
import { normalizeSupplierName } from './supplierAlias';

export interface LegacyOrderItem {
  id: string;
  qty: number;
  buyPrice: number;
  productId?: string;
  salePrice: number;
}

export interface LegacyOrder {
  id: string;
  items: LegacyOrderItem[];
  status?: string;
  revenue?: number;
  discount?: number;
  discountPct?: number;
  snappFee?: number;
  snappVat?: number;
  snappCommission?: number;
  paymentGatewayFee?: number;
  supplier?: string;
  createdAt?: number; // epoch ms
  orderDate?: number; // epoch ms
  orderDateFa?: string;
  customerCode: string;
  customerName?: string;
  orderChannel?: string;
  settlementStatus?: string;
  /** Legacy-only, unreliable field — read by the Migration Wizard purely for
   * diagnostics (to flag mismatches). Never trusted for real calculations. */
  profit?: number;
}

export interface MappedLegacyOrder {
  order: Order;
  items: OrderItem[];
  snapp?: SnappSettlement;
  /** unresolved fields, ambiguous suppliers, unknown statuses, etc. — for the wizard's report */
  warnings: string[];
}

const STATUS_MAP: Record<string, OrderStatus> = {
  'جدید': 'new',
  'درحال تامین': 'in_supply',
  'ارسال شد': 'shipped',
  'تحویل شد': 'delivered',
  'لغو شد': 'cancelled',
};

const CHANNEL_MAP: Record<string, OrderChannel> = {
  'اسنپ‌پی': 'snapp',
  'نقد': 'cash',
  'سایت خودم': 'site',
  'اعتباری مستقیم': 'credit',
};

function toIsoDate(epochMs: number | undefined, warnings: string[], orderId: string): string {
  if (typeof epochMs !== 'number' || !Number.isFinite(epochMs)) {
    warnings.push(`سفارش ${orderId}: تاریخ معتبر پیدا نشد؛ نیاز به بررسی دستی قبل از مهاجرت`);
    return new Date(0).toISOString();
  }
  return new Date(epochMs).toISOString();
}

export function mapLegacyOrder(raw: LegacyOrder): MappedLegacyOrder {
  const warnings: string[] = [];

  let status: OrderStatus = 'new';
  if (raw.status && STATUS_MAP[raw.status]) {
    status = STATUS_MAP[raw.status];
  } else {
    warnings.push(`سفارش ${raw.id}: وضعیت ناشناخته "${raw.status}" — به‌صورت موقت "جدید" علامت خورد`);
  }

  let channel: OrderChannel = 'cash';
  if (raw.orderChannel && CHANNEL_MAP[raw.orderChannel]) {
    channel = CHANNEL_MAP[raw.orderChannel];
  } else if (raw.orderChannel) {
    warnings.push(`سفارش ${raw.id}: کانال فروش ناشناخته "${raw.orderChannel}"`);
  } else {
    warnings.push(`سفارش ${raw.id}: کانال فروش ثبت نشده — به‌صورت موقت "نقد" فرض شد، لطفاً تأیید کنید`);
  }

  const supplierId = normalizeSupplierName(raw.supplier);
  if (!supplierId) {
    warnings.push(`سفارش ${raw.id}: نام تأمین‌کننده "${raw.supplier ?? '(خالی)'}" شناخته‌شده نیست`);
  }

  const orderDateIso = toIsoDate(raw.orderDate ?? raw.createdAt, warnings, raw.id);

  const order: Order = {
    id: raw.id,
    customerCode: raw.customerCode,
    customerName: raw.customerName,
    orderDateIso,
    status,
    channel,
    discount: raw.discount,
    discountPct: raw.discountPct,
  };

  // NOTE: the legacy data only records one supplier per order, not per item.
  // Every item inherits the order-level supplier. If a single order can
  // legitimately contain items from two different suppliers, this mapping
  // needs to change — flagged as an open decision in the handoff report.
  const items: OrderItem[] = raw.items.map((it) => ({
    id: it.id,
    orderId: raw.id,
    productId: it.productId,
    qty: it.qty,
    buyPrice: it.buyPrice,
    salePrice: it.salePrice,
    supplierId: supplierId ?? 'UNRESOLVED',
  }));

  let snapp: SnappSettlement | undefined;
  if (channel === 'snapp') {
    const commission = raw.snappCommission ?? 0;
    const fee = raw.snappFee ?? 0;
    const vat = fee - commission; // legacy stores fee = commission + vat combined
    if (vat < 0) {
      warnings.push(`سفارش ${raw.id}: snappFee کمتر از snappCommission است — نیاز به بررسی دستی`);
    }
    snapp = {
      id: `snapp-${raw.id}`,
      orderId: raw.id,
      recordedAmount: raw.revenue ?? 0,
      commission,
      vatOnCommission: Math.max(0, vat),
      holdbackPct: 10,
      // The legacy data has no field distinguishing "confirmed payout" from
      // "pending" — everything with settlementStatus "تسویه شده" is treated
      // as confirmed for migration purposes, everything else as pending.
      payoutConfirmed: raw.settlementStatus === 'تسویه شده',
      holdbackReleased: false,
    };
    if (!raw.settlementStatus) {
      warnings.push(`سفارش ${raw.id}: settlementStatus ثبت نشده — واریزی اسنپ‌پی «در انتظار» فرض شد`);
    }
  }

  return { order, items, snapp, warnings };
}
