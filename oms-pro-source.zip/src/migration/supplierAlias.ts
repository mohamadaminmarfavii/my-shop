// Collapses the supplier name variants named in the spec into one canonical
// ID. Returns null (never a guess) for anything unrecognized, so the
// Migration Wizard can surface it for a human decision instead of silently
// merging two different suppliers.

export const SUPPLIER_ALI = 'sup-ali-versace';
export const SUPPLIER_VAHID = 'sup-vahid-nazari';

const ALIASES: Record<string, string> = {
  'علی ورساچ': SUPPLIER_ALI,
  'علی ورساچه': SUPPLIER_ALI,
  'علی‌ورساچ': SUPPLIER_ALI, // contains a ZWNJ between the two words
  'ali versace': SUPPLIER_ALI,
  'وحید نظری': SUPPLIER_VAHID,
  'وحید': SUPPLIER_VAHID,
};

function normalizeKey(raw: string): string {
  return raw.trim().toLowerCase();
}

export function normalizeSupplierName(raw: string | null | undefined): string | null {
  if (!raw) return null;
  return ALIASES[normalizeKey(raw)] ?? null;
}

export function canonicalSupplierLabel(id: string): string {
  if (id === SUPPLIER_ALI) return 'علی ورساچ';
  if (id === SUPPLIER_VAHID) return 'وحید نظری';
  return id;
}
