import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { runPreflightChecks } from '../preflight';
import type { LegacyOrder } from '../mapLegacyOrder';

const SAMPLE_GOOD: LegacyOrder = {
  id: 'order-1',
  items: [{ id: 'item-1', qty: 1, buyPrice: 100_000, salePrice: 150_000 }],
  status: 'تحویل شد',
  revenue: 150_000,
  supplier: 'وحید نظری',
  orderChannel: 'نقد',
  customerCode: 'OMS-A',
};

describe('runPreflightChecks — synthetic cases', () => {
  it('produces no issues for a clean order', () => {
    expect(runPreflightChecks([SAMPLE_GOOD])).toEqual([]);
  });

  it('flags a duplicate order id', () => {
    const issues = runPreflightChecks([SAMPLE_GOOD, SAMPLE_GOOD]);
    expect(issues.some((i) => i.code === 'duplicate-id')).toBe(true);
  });

  it('flags an unresolved supplier name', () => {
    const issues = runPreflightChecks([{ ...SAMPLE_GOOD, supplier: 'یک نام جدید' }]);
    expect(issues.some((i) => i.code === 'unresolved-supplier')).toBe(true);
  });

  it('flags a missing order channel', () => {
    const issues = runPreflightChecks([{ ...SAMPLE_GOOD, orderChannel: undefined }]);
    expect(issues.some((i) => i.code === 'missing-channel')).toBe(true);
  });

  it('flags an unknown status', () => {
    const issues = runPreflightChecks([{ ...SAMPLE_GOOD, status: 'یک وضعیت عجیب' }]);
    expect(issues.some((i) => i.code === 'unknown-status')).toBe(true);
  });

  it('flags an invalid item price', () => {
    const issues = runPreflightChecks([
      { ...SAMPLE_GOOD, items: [{ id: 'item-1', qty: 1, buyPrice: NaN as unknown as number, salePrice: 100 }] },
    ]);
    expect(issues.some((i) => i.code === 'invalid-item-price')).toBe(true);
  });

  it('flags a suspicious stored profit that disagrees with a naive recompute', () => {
    const issues = runPreflightChecks([{ ...SAMPLE_GOOD, profit: 6_269_484_682 }]);
    expect(issues.some((i) => i.code === 'suspicious-profit')).toBe(true);
  });

  it('does not flag suspicious profit for a cancelled order', () => {
    const issues = runPreflightChecks([{ ...SAMPLE_GOOD, status: 'لغو شد', profit: 6_269_484_682 }]);
    expect(issues.some((i) => i.code === 'suspicious-profit')).toBe(false);
  });
});

describe('runPreflightChecks — real backup file', () => {
  it('matches the counts found by manual analysis', () => {
    const raw = JSON.parse(
      readFileSync(
        new URL('./fixtures/real-orders-sample.json', import.meta.url),
        'utf-8',
      ),
    );
    const orders: LegacyOrder[] = raw.orders;
    const issues = runPreflightChecks(orders);

    const errors = issues.filter((i) => i.severity === 'error');
    const warnings = issues.filter((i) => i.severity === 'warning');

    expect(orders).toHaveLength(76);
    expect(errors).toHaveLength(0);
    // 20 unresolved-supplier + 13 missing-channel + 15 suspicious-profit
    // (the same 15 mismatches found by manual analysis of the backup)
    expect(warnings).toHaveLength(48);
    expect(warnings.filter((w) => w.code === 'unresolved-supplier')).toHaveLength(20);
    expect(warnings.filter((w) => w.code === 'missing-channel')).toHaveLength(13);
    expect(warnings.filter((w) => w.code === 'suspicious-profit')).toHaveLength(15);
  });
});
