import { describe, expect, it } from 'vitest';
import { mapLegacyOrder, type LegacyOrder } from '../mapLegacyOrder';
import { normalizeSupplierName, SUPPLIER_VAHID, SUPPLIER_ALI } from '../supplierAlias';
import { computeOrderEconomics } from '../../finance/engine';

// This is the real order "OMS-SWRMRB" (خانم نامجو) taken verbatim from
// manual_2026-09-05-21-11-26.json, used as a concrete regression fixture.
const REAL_SAMPLE_ORDER: LegacyOrder = {
  id: 'mtonu7fb59rhib',
  items: [
    { id: 'mtonsgnxymnrwx', qty: 1, buyPrice: 1_200_000, productId: 'fmwv72u2tbvmr6bcimu', salePrice: 1_600_000 },
    { id: 'mtonvbisjc46vq', qty: 1, buyPrice: 1_200_000, productId: 'neztcmnu28emr6bcimu', salePrice: 1_600_000 },
    { id: 'mtonvbk9jwvuah', qty: 1, buyPrice: 900_000, productId: 'k5pubk5jqjjmr6bcimu', salePrice: 1_250_000 },
    { id: 'mtonviatbkq62q', qty: 1, buyPrice: 380_000, productId: 'mt416xd6dkqt4j', salePrice: 480_000 },
  ],
  status: 'درحال تامین',
  revenue: 4_930_000,
  discount: 0,
  snappFee: 542_300,
  snappVat: 49_300,
  snappCommission: 493_000,
  supplier: 'وحید نظری',
  createdAt: 1_788_510_600_000,
  orderDate: 1_788_510_600_000,
  orderDateFa: '۱۴۰۵/۶/۱۳',
  customerCode: 'OMS-SWRMRB',
  customerName: 'خانم نامجو',
  orderChannel: 'اسنپ‌پی',
  settlementStatus: 'تسویه نشده',
};

describe('mapLegacyOrder — real backup fixture', () => {
  it('maps status, channel, supplier and dates without warnings', () => {
    const { order, items, snapp, warnings } = mapLegacyOrder(REAL_SAMPLE_ORDER);

    expect(order.status).toBe('in_supply');
    expect(order.channel).toBe('snapp');
    expect(order.customerCode).toBe('OMS-SWRMRB');
    expect(order.orderDateIso).toBe(new Date(1_788_510_600_000).toISOString());

    expect(items).toHaveLength(4);
    expect(items.every((it) => it.supplierId === SUPPLIER_VAHID)).toBe(true);

    expect(snapp?.recordedAmount).toBe(4_930_000);
    expect(snapp?.commission).toBe(493_000);
    expect(snapp?.vatOnCommission).toBe(49_300); // 542,300 - 493,000
    expect(snapp?.payoutConfirmed).toBe(false); // settlementStatus was "تسویه نشده"

    expect(warnings).toEqual([]);
  });

  it('recomputed accrued profit differs from the untrustworthy legacy order.profit field', () => {
    const { order, items, snapp } = mapLegacyOrder(REAL_SAMPLE_ORDER);
    const econ = computeOrderEconomics(order, items, { snapp });

    // legacy stored profit was 707,700 (revenue - itemCost - snappFee, no
    // separate VAT/commission split). Our engine treats commission + VAT as
    // the gateway fee and cost as the item sum — same total fee, so the
    // recomputed figure matches here, which is exactly the point: the
    // engine derives it from base data instead of trusting a stored field.
    const itemCost = 1_200_000 + 1_200_000 + 900_000 + 380_000;
    expect(econ.cost).toBe(itemCost);
    expect(econ.grossSale).toBe(1_600_000 + 1_600_000 + 1_250_000 + 480_000);
    expect(econ.accruedProfit).toBe(econ.grossSale - itemCost - econ.gatewayFee);
  });

  it('flags an unresolved supplier name instead of guessing', () => {
    const { items, warnings } = mapLegacyOrder({ ...REAL_SAMPLE_ORDER, supplier: 'یک نام ناشناخته' });
    expect(items.every((it) => it.supplierId === 'UNRESOLVED')).toBe(true);
    expect(warnings.some((w) => w.includes('ناشناخته'))).toBe(true);
  });

  it('flags a missing order channel rather than silently defaulting without a warning', () => {
    const { order, warnings } = mapLegacyOrder({ ...REAL_SAMPLE_ORDER, orderChannel: undefined });
    expect(order.channel).toBe('cash');
    expect(warnings.some((w) => w.includes('کانال فروش ثبت نشده'))).toBe(true);
  });
});

describe('normalizeSupplierName', () => {
  it('collapses known Ali Versace variants', () => {
    expect(normalizeSupplierName('علی ورساچ')).toBe(SUPPLIER_ALI);
    expect(normalizeSupplierName('علی ورساچه')).toBe(SUPPLIER_ALI);
    expect(normalizeSupplierName('Ali Versace')).toBe(SUPPLIER_ALI);
  });
  it('collapses known Vahid variants', () => {
    expect(normalizeSupplierName('وحید نظری')).toBe(SUPPLIER_VAHID);
    expect(normalizeSupplierName('وحید')).toBe(SUPPLIER_VAHID);
  });
  it('returns null instead of guessing for an unknown name', () => {
    expect(normalizeSupplierName('یک تأمین‌کننده جدید')).toBeNull();
    expect(normalizeSupplierName(undefined)).toBeNull();
  });
});
