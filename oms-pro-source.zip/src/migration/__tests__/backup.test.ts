import { describe, expect, it } from 'vitest';
import { validateBackupFile } from '../backup';
import { SCHEMA_VERSION } from '../../db/schema';

function emptyData() {
  return {
    orders: [],
    orderItems: [],
    customerReceipts: [],
    snappSettlements: [],
    supplierPayments: [],
    supplierRefunds: [],
    expenses: [],
    customerRefunds: [],
    profitShareRules: [],
    profitSharePayments: [],
    cashWithdrawals: [],
    openingBalances: [],
    auditLog: [],
  };
}

describe('validateBackupFile', () => {
  it('accepts a well-formed backup at the current schema version', () => {
    const file = { schemaVersion: SCHEMA_VERSION, createdAtIso: new Date().toISOString(), data: emptyData() };
    const result = validateBackupFile(file);
    expect(result.ok).toBe(true);
    expect(result.errors).toEqual([]);
  });

  it('rejects a non-object', () => {
    expect(validateBackupFile('not json').ok).toBe(false);
    expect(validateBackupFile(null).ok).toBe(false);
  });

  it('rejects a mismatched schema version instead of guessing', () => {
    const file = { schemaVersion: SCHEMA_VERSION + 1, createdAtIso: new Date().toISOString(), data: emptyData() };
    const result = validateBackupFile(file);
    expect(result.ok).toBe(false);
    expect(result.errors.some((e) => e.includes('schema'))).toBe(true);
  });

  it('rejects a file missing the data section', () => {
    const result = validateBackupFile({ schemaVersion: SCHEMA_VERSION, createdAtIso: new Date().toISOString() });
    expect(result.ok).toBe(false);
  });

  it('rejects a file where a table is not an array', () => {
    const data = { ...emptyData(), orders: 'not-an-array' };
    const result = validateBackupFile({ schemaVersion: SCHEMA_VERSION, createdAtIso: new Date().toISOString(), data });
    expect(result.ok).toBe(false);
    expect(result.errors.some((e) => e.includes('orders'))).toBe(true);
  });

  it('reports per-table counts on success', () => {
    const data = { ...emptyData(), orders: [{ id: '1' }, { id: '2' }] };
    const result = validateBackupFile({ schemaVersion: SCHEMA_VERSION, createdAtIso: new Date().toISOString(), data });
    expect(result.counts?.orders).toBe(2);
  });
});
