// Native backup & restore for the rewritten app's own data (separate from
// the one-time legacy migration). Implements the spec's "پشتیبان و امنیت
// داده" requirements: full JSON backup, schema version stamped in the
// file, validation before restore, and a count-based preview so a restore
// is never a silent surprise.

import { db, SCHEMA_VERSION } from '../db/schema';
import type {
  Order,
  OrderItem,
  CustomerReceipt,
  SnappSettlement,
  SupplierPayment,
  SupplierRefund,
  Expense,
  CustomerRefund,
  ProfitShareRule,
  ProfitSharePayment,
  CashWithdrawal,
  OpeningBalance,
  AuditLogEntry,
} from '../finance/types';

export interface BackupData {
  orders: Order[];
  orderItems: OrderItem[];
  customerReceipts: CustomerReceipt[];
  snappSettlements: SnappSettlement[];
  supplierPayments: SupplierPayment[];
  supplierRefunds: SupplierRefund[];
  expenses: Expense[];
  customerRefunds: CustomerRefund[];
  profitShareRules: ProfitShareRule[];
  profitSharePayments: ProfitSharePayment[];
  cashWithdrawals: CashWithdrawal[];
  openingBalances: OpeningBalance[];
  auditLog: AuditLogEntry[];
}

export interface BackupFile {
  schemaVersion: number;
  createdAtIso: string;
  data: BackupData;
}

const TABLE_NAMES = Object.keys({
  orders: 0,
  orderItems: 0,
  customerReceipts: 0,
  snappSettlements: 0,
  supplierPayments: 0,
  supplierRefunds: 0,
  expenses: 0,
  customerRefunds: 0,
  profitShareRules: 0,
  profitSharePayments: 0,
  cashWithdrawals: 0,
  openingBalances: 0,
  auditLog: 0,
} satisfies Record<keyof BackupData, 0>) as (keyof BackupData)[];

export async function exportBackup(): Promise<BackupFile> {
  const data: BackupData = {
    orders: await db.orders.toArray(),
    orderItems: await db.orderItems.toArray(),
    customerReceipts: await db.customerReceipts.toArray(),
    snappSettlements: await db.snappSettlements.toArray(),
    supplierPayments: await db.supplierPayments.toArray(),
    supplierRefunds: await db.supplierRefunds.toArray(),
    expenses: await db.expenses.toArray(),
    customerRefunds: await db.customerRefunds.toArray(),
    profitShareRules: await db.profitShareRules.toArray(),
    profitSharePayments: await db.profitSharePayments.toArray(),
    cashWithdrawals: await db.cashWithdrawals.toArray(),
    openingBalances: await db.openingBalances.toArray(),
    auditLog: await db.auditLog.toArray(),
  };
  return { schemaVersion: SCHEMA_VERSION, createdAtIso: new Date().toISOString(), data };
}

export function triggerJsonDownload(filename: string, payload: unknown): void {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export interface BackupValidation {
  ok: boolean;
  errors: string[];
  schemaVersion?: number;
  counts?: Partial<Record<keyof BackupData, number>>;
}

/**
 * Validates a candidate restore file's *shape* before anything touches the
 * database. A schema-version mismatch is treated as a hard error for now —
 * this rewrite has no cross-version migration logic yet, so restoring a
 * file from a different schema version is refused rather than guessed at.
 */
export function validateBackupFile(json: unknown): BackupValidation {
  const errors: string[] = [];

  if (typeof json !== 'object' || json === null) {
    return { ok: false, errors: ['فایل یک شیء JSON معتبر نیست'] };
  }
  const obj = json as Record<string, unknown>;

  if (typeof obj.schemaVersion !== 'number') {
    errors.push('نسخهٔ schema در فایل مشخص نیست');
  } else if (obj.schemaVersion !== SCHEMA_VERSION) {
    errors.push(`نسخهٔ schema فایل (${obj.schemaVersion}) با نسخهٔ فعلی برنامه (${SCHEMA_VERSION}) یکی نیست`);
  }

  if (typeof obj.createdAtIso !== 'string') {
    errors.push('تاریخ ساخت پشتیبان در فایل مشخص نیست');
  }

  if (typeof obj.data !== 'object' || obj.data === null) {
    errors.push('بخش data در فایل پیدا نشد');
    return { ok: false, errors, schemaVersion: obj.schemaVersion as number | undefined };
  }

  const data = obj.data as Record<string, unknown>;
  const counts: Partial<Record<keyof BackupData, number>> = {};
  for (const name of TABLE_NAMES) {
    const arr = data[name];
    if (!Array.isArray(arr)) {
      errors.push(`جدول «${name}» در فایل پشتیبان آرایه نیست یا وجود ندارد`);
      continue;
    }
    counts[name] = arr.length;
  }

  return { ok: errors.length === 0, errors, schemaVersion: obj.schemaVersion as number, counts };
}

export async function getCurrentCounts(): Promise<Record<keyof BackupData, number>> {
  return {
    orders: await db.orders.count(),
    orderItems: await db.orderItems.count(),
    customerReceipts: await db.customerReceipts.count(),
    snappSettlements: await db.snappSettlements.count(),
    supplierPayments: await db.supplierPayments.count(),
    supplierRefunds: await db.supplierRefunds.count(),
    expenses: await db.expenses.count(),
    customerRefunds: await db.customerRefunds.count(),
    profitShareRules: await db.profitShareRules.count(),
    profitSharePayments: await db.profitSharePayments.count(),
    cashWithdrawals: await db.cashWithdrawals.count(),
    openingBalances: await db.openingBalances.count(),
    auditLog: await db.auditLog.count(),
  };
}

/**
 * Restores a full backup: replaces every table's contents with the
 * backup's contents, inside one transaction (all-or-nothing). Must only be
 * called after `validateBackupFile` returned `ok: true` and the person
 * confirmed the preview — this function itself does not ask again.
 */
export async function restoreBackup(backup: BackupFile): Promise<void> {
  await db.transaction(
    'rw',
    [
      db.orders,
      db.orderItems,
      db.customerReceipts,
      db.snappSettlements,
      db.supplierPayments,
      db.supplierRefunds,
      db.expenses,
      db.customerRefunds,
      db.profitShareRules,
      db.profitSharePayments,
      db.cashWithdrawals,
      db.openingBalances,
      db.auditLog,
    ],
    async () => {
      await db.orders.clear();
      await db.orders.bulkAdd(backup.data.orders);
      await db.orderItems.clear();
      await db.orderItems.bulkAdd(backup.data.orderItems);
      await db.customerReceipts.clear();
      await db.customerReceipts.bulkAdd(backup.data.customerReceipts);
      await db.snappSettlements.clear();
      await db.snappSettlements.bulkAdd(backup.data.snappSettlements);
      await db.supplierPayments.clear();
      await db.supplierPayments.bulkAdd(backup.data.supplierPayments);
      await db.supplierRefunds.clear();
      await db.supplierRefunds.bulkAdd(backup.data.supplierRefunds);
      await db.expenses.clear();
      await db.expenses.bulkAdd(backup.data.expenses);
      await db.customerRefunds.clear();
      await db.customerRefunds.bulkAdd(backup.data.customerRefunds);
      await db.profitShareRules.clear();
      await db.profitShareRules.bulkAdd(backup.data.profitShareRules);
      await db.profitSharePayments.clear();
      await db.profitSharePayments.bulkAdd(backup.data.profitSharePayments);
      await db.cashWithdrawals.clear();
      await db.cashWithdrawals.bulkAdd(backup.data.cashWithdrawals);
      await db.openingBalances.clear();
      await db.openingBalances.bulkAdd(backup.data.openingBalances);
      await db.auditLog.clear();
      await db.auditLog.bulkAdd(backup.data.auditLog);
      await db.auditLog.add({
        id: `restore-${Date.now()}`,
        entity: 'Database',
        entityId: 'restore',
        action: 'restore',
        before: null,
        after: { schemaVersion: backup.schemaVersion, createdAtIso: backup.createdAtIso },
        actor: 'user',
        timestampIso: new Date().toISOString(),
      });
    },
  );
}
