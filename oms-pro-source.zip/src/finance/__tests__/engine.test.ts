import { describe, expect, it } from 'vitest';
import { parseAmountToman, formatToman, AmountParseError } from '../../lib/money';
import {
  computeOrderEconomics,
  computeConfirmedCollection,
  computeCollectedProfit,
  computeWithdrawableProfit,
  computeItemBalance,
  computeSupplierTotalDebt,
  recomputeSupplierAllocations,
  computeAliPurchasePrice,
  computeAliBaseSalePrice,
  getVahidSuggestedPrice,
  computeProfitShareAmount,
  isOrderCancelled,
  type OpenDebtItem,
} from '../engine';
import type { Order, OrderItem, SupplierPayment } from '../types';

const ALI = 'sup-ali';
const VAHID = 'sup-vahid';

// -----------------------------------------------------------------------
// Scenario 1 + 2 from the spec: Vahid's 1,650,000 targeted payment for
// Ms. Shabani's two-item order (OMS-FNGSYZ), and Ali's account must be
// completely unaffected.
// -----------------------------------------------------------------------
describe('bug #1 / #2 — targeted supplier payment settles the right items only', () => {
  const shabaniItem1: OpenDebtItem = {
    orderItemId: 'item-mask',
    supplierId: VAHID,
    orderDateIso: '1405-06-10',
    cost: 1_200_000,
  };
  const shabaniItem2: OpenDebtItem = {
    orderItemId: 'item-oil',
    supplierId: VAHID,
    orderDateIso: '1405-06-10',
    cost: 450_000,
  };
  const aliItem: OpenDebtItem = {
    orderItemId: 'item-ali-unrelated',
    supplierId: ALI,
    orderDateIso: '1405-06-05',
    cost: 900_000,
  };

  const items = [shabaniItem1, shabaniItem2, aliItem];

  const vahidPayment: SupplierPayment = {
    id: 'pay-vahid-1',
    supplierId: VAHID,
    amount: 1_650_000,
    dateIso: '1405-06-10',
    source: 'cash',
    targetMode: 'targeted',
    targetItemIds: ['item-mask', 'item-oil'],
    status: 'active',
  };

  it('allocates exactly 1,200,000 and 450,000 to the two Shabani items', () => {
    const allocations = recomputeSupplierAllocations(VAHID, [vahidPayment], items);
    expect(allocations).toEqual(
      expect.arrayContaining([
        { paymentId: 'pay-vahid-1', orderItemId: 'item-mask', amount: 1_200_000 },
        { paymentId: 'pay-vahid-1', orderItemId: 'item-oil', amount: 450_000 },
      ]),
    );
    expect(computeItemBalance(shabaniItem1, allocations)).toBe(0);
    expect(computeItemBalance(shabaniItem2, allocations)).toBe(0);
    expect(computeSupplierTotalDebt([shabaniItem1, shabaniItem2], allocations)).toBe(0);
  });

  it("never touches Ali's account", () => {
    const aliAllocations = recomputeSupplierAllocations(ALI, [vahidPayment], items);
    expect(aliAllocations).toEqual([]);
    expect(computeItemBalance(aliItem, aliAllocations)).toBe(900_000);
  });
});

// -----------------------------------------------------------------------
// Scenario 3: the target-order selection is a stored field, so a
// serialize/deserialize round-trip (equivalent to "close and reload the
// page") must preserve it exactly, with no silent fallback to FIFO.
// -----------------------------------------------------------------------
describe('bug #2 — target selection survives reload', () => {
  it('round-trips targetMode and targetItemIds through JSON', () => {
    const payment: SupplierPayment = {
      id: 'pay-2',
      supplierId: VAHID,
      amount: 500_000,
      dateIso: '1405-06-11',
      source: 'cash',
      targetMode: 'targeted',
      targetItemIds: ['item-x'],
      status: 'active',
    };
    const reloaded = JSON.parse(JSON.stringify(payment)) as SupplierPayment;
    expect(reloaded.targetMode).toBe('targeted');
    expect(reloaded.targetItemIds).toEqual(['item-x']);
  });
});

// -----------------------------------------------------------------------
// Scenario 4: sync must be idempotent — running it twice on the same
// inputs must not change the result.
// -----------------------------------------------------------------------
describe('bug #3 — sync is idempotent', () => {
  it('produces byte-identical allocations on repeated runs', () => {
    const items: OpenDebtItem[] = [
      { orderItemId: 'a', supplierId: VAHID, orderDateIso: '1405-06-01', cost: 300_000 },
      { orderItemId: 'b', supplierId: VAHID, orderDateIso: '1405-06-02', cost: 200_000 },
    ];
    const payments: SupplierPayment[] = [
      {
        id: 'p1',
        supplierId: VAHID,
        amount: 400_000,
        dateIso: '1405-06-03',
        source: 'cash',
        targetMode: 'fifo',
        status: 'active',
      },
    ];
    const first = recomputeSupplierAllocations(VAHID, payments, items);
    const second = recomputeSupplierAllocations(VAHID, payments, items);
    expect(second).toEqual(first);
  });
});

// -----------------------------------------------------------------------
// Scenario: soft delete then restore must apply the payment's effect
// exactly once each time — no duplicate reversal, no drift.
// -----------------------------------------------------------------------
describe('bug #4 — safe delete & restore', () => {
  const items: OpenDebtItem[] = [
    { orderItemId: 'a', supplierId: VAHID, orderDateIso: '1405-06-01', cost: 300_000 },
  ];
  const payment: SupplierPayment = {
    id: 'p1',
    supplierId: VAHID,
    amount: 300_000,
    dateIso: '1405-06-03',
    source: 'cash',
    targetMode: 'fifo',
    status: 'active',
  };

  it('deleting excludes the allocation exactly once', () => {
    const deleted = { ...payment, status: 'deleted' as const };
    const allocations = recomputeSupplierAllocations(VAHID, [deleted], items);
    expect(allocations).toEqual([]);
    expect(computeItemBalance(items[0], allocations)).toBe(300_000);
  });

  it('restoring re-applies it exactly once, matching the original state', () => {
    const original = recomputeSupplierAllocations(VAHID, [payment], items);
    const deleted = { ...payment, status: 'deleted' as const };
    recomputeSupplierAllocations(VAHID, [deleted], items); // simulate the delete step
    const restored = recomputeSupplierAllocations(VAHID, [{ ...payment, status: 'active' }], items);
    expect(restored).toEqual(original);
  });
});

// -----------------------------------------------------------------------
// Scenario: over-paying must never create a negative balance or an
// unexplained record — the surplus is simply left unallocated.
// -----------------------------------------------------------------------
describe('bug — no negative balances on over-payment', () => {
  it('caps allocation at the open debt and leaves the rest unallocated', () => {
    const items: OpenDebtItem[] = [
      { orderItemId: 'a', supplierId: VAHID, orderDateIso: '1405-06-01', cost: 100_000 },
    ];
    const payment: SupplierPayment = {
      id: 'p-over',
      supplierId: VAHID,
      amount: 500_000,
      dateIso: '1405-06-02',
      source: 'cash',
      targetMode: 'fifo',
      status: 'active',
    };
    const allocations = recomputeSupplierAllocations(VAHID, [payment], items);
    const total = allocations.reduce((s, a) => s + a.amount, 0);
    expect(total).toBe(100_000); // not 500,000
    expect(allocations.every((a) => a.amount >= 0)).toBe(true);
    expect(computeItemBalance(items[0], allocations)).toBe(0);
  });
});

// -----------------------------------------------------------------------
// Scenario 16 + 18: cancelled orders and legacy corrupted `profit` fields
// must never leak into the computed numbers.
// -----------------------------------------------------------------------
describe('bug #7 — no more impossible profit numbers', () => {
  const baseItems: OrderItem[] = [
    { id: 'i1', orderId: 'o1', qty: 1, buyPrice: 300_000, salePrice: 500_000, supplierId: ALI },
  ];

  it('cancelled orders contribute zero to sales and profit', () => {
    const order: Order = {
      id: 'o1',
      customerCode: 'OMS-X',
      orderDateIso: '1405-06-01',
      status: 'cancelled',
      channel: 'cash',
    };
    expect(isOrderCancelled(order)).toBe(true);
    const econ = computeOrderEconomics(order, baseItems);
    expect(econ).toEqual({
      grossSale: 0,
      discount: 0,
      refund: 0,
      gatewayFee: 0,
      cost: 0,
      directExpense: 0,
      accruedProfit: 0,
    });
  });

  it('is always recomputed from items, ignoring any legacy stored profit field', () => {
    const order: Order = {
      id: 'o1',
      customerCode: 'OMS-X',
      orderDateIso: '1405-06-01',
      status: 'delivered',
      channel: 'cash',
    };
    // Note: our Order type has no `profit` field at all — there is nothing
    // for a corrupted legacy number to hide in. The type system itself
    // enforces this rule.
    const econ = computeOrderEconomics(order, baseItems);
    expect(econ.accruedProfit).toBe(200_000); // 500,000 - 300,000
  });
});

// -----------------------------------------------------------------------
// Scenario 19: Persian/Arabic/English digits and separators.
// -----------------------------------------------------------------------
describe('bug #7 support — Persian/Arabic amount parsing', () => {
  it('parses Persian digits with "٬" separators', () => {
    expect(parseAmountToman('۱٬۶۵۰٬۰۰۰')).toBe(1_650_000);
  });
  it('parses Arabic-Indic digits', () => {
    expect(parseAmountToman('١٬٢٠٠٬٠٠٠')).toBe(1_200_000);
  });
  it('parses plain English digits with commas', () => {
    expect(parseAmountToman('1,650,000')).toBe(1_650_000);
  });
  it('treats empty input as zero', () => {
    expect(parseAmountToman('')).toBe(0);
    expect(parseAmountToman(undefined)).toBe(0);
  });
  it('rejects garbage instead of silently returning zero', () => {
    expect(() => parseAmountToman('abc')).toThrow(AmountParseError);
  });
  it('formats back for display', () => {
    expect(formatToman(1650000)).toBe((1650000).toLocaleString('fa-IR'));
  });
});

// -----------------------------------------------------------------------
// Scenario 20 + 21: Ali's pricing formula and Vahid's last-price suggestion.
// -----------------------------------------------------------------------
describe('bug — pricing rules', () => {
  it('computes Ali purchase + base price exactly per the spec examples', () => {
    expect(computeAliPurchasePrice(595_000, 10)).toBe(535_500);
    expect(computeAliBaseSalePrice(535_500, 20)).toBe(642_600);

    expect(computeAliPurchasePrice(2_100_000, 10)).toBe(1_890_000);
    expect(computeAliBaseSalePrice(1_890_000, 20)).toBe(2_268_000);
  });

  it("suggests Vahid's own last recorded sale price, not a percentage rule", () => {
    const history: OrderItem[] = [
      { id: 'h1', orderId: 'o1', productId: 'p-vahid-1', qty: 1, buyPrice: 100, salePrice: 140_000, supplierId: VAHID },
      { id: 'h2', orderId: 'o2', productId: 'p-vahid-1', qty: 1, buyPrice: 100, salePrice: 150_000, supplierId: VAHID },
    ];
    expect(getVahidSuggestedPrice('p-vahid-1', history)).toBe(150_000);
    expect(getVahidSuggestedPrice('unknown-product', history)).toBeNull();
  });
});

// -----------------------------------------------------------------------
// Scenario 23 + 24: profit share is separate from purchase debt, and
// withdrawable profit is capped by real cash.
// -----------------------------------------------------------------------
describe('bug — profit share isolation & withdrawable profit cap', () => {
  it('computing a 50% profit share does not touch purchase debt', () => {
    const items: OpenDebtItem[] = [
      { orderItemId: 'a', supplierId: ALI, orderDateIso: '1405-06-01', cost: 1_000_000 },
    ];
    const debtBefore = computeSupplierTotalDebt(items, []);
    const share = computeProfitShareAmount(2_000_000, 50);
    const debtAfter = computeSupplierTotalDebt(items, []);
    expect(share).toBe(1_000_000);
    expect(debtAfter).toBe(debtBefore); // untouched
  });

  it('withdrawable profit is zero when the cash box is empty, even with positive accrued profit', () => {
    const withdrawable = computeWithdrawableProfit(/* cash */ 0, /* collected */ 2_000_000, /* obligations */ 0);
    expect(withdrawable).toBe(0);
  });

  it('withdrawable profit is capped by free cash after immediate obligations', () => {
    const withdrawable = computeWithdrawableProfit(1_000_000, 2_000_000, 700_000);
    expect(withdrawable).toBe(300_000);
  });
});

// -----------------------------------------------------------------------
// Confirmed collection / collected profit waterfall sanity check, using
// numbers shaped like the Snapp example in the spec.
// -----------------------------------------------------------------------
describe('collected profit waterfall', () => {
  it('only counts the confirmed Snapp payout, not the full recorded amount', () => {
    const order: Order = {
      id: 'o-snapp',
      customerCode: 'OMS-S',
      orderDateIso: '1405-06-01',
      status: 'delivered',
      channel: 'snapp',
    };
    const items: OrderItem[] = [
      { id: 'i1', orderId: 'o-snapp', qty: 1, buyPrice: 2_000_000, salePrice: 3_950_000, supplierId: ALI },
    ];
    const snapp = {
      id: 'snapp-1',
      orderId: 'o-snapp',
      recordedAmount: 3_950_000,
      commission: 395_000,
      vatOnCommission: 39_500,
      holdbackPct: 10,
      payoutConfirmed: true,
      holdbackReleased: false,
    };
    const econ = computeOrderEconomics(order, items, { snapp });
    const collected = computeConfirmedCollection(order, [], snapp);
    const collectedProfit = computeCollectedProfit(econ, collected);

    // net = 3,950,000 - 395,000 - 39,500 = 3,515,500; 90% payout = 3,163,950
    expect(collected).toBe(3_163_950);
    // profit isn't fully "collected" yet because the 10% holdback (351,550) is still pending
    expect(collectedProfit).toBeLessThan(econ.accruedProfit);
  });
});
