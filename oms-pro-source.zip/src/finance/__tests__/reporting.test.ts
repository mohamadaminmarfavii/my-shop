import { describe, expect, it } from 'vitest';
import { buildOrderReportRow, groupRowsByPeriod, splitPersonalProfit } from '../reporting';
import type { Order, OrderItem, ProfitShareRule } from '../types';

const VAHID = 'sup-vahid';
const ALI = 'sup-ali';

function makeOrder(id: string, dateIso: string): Order {
  return { id, customerCode: `OMS-${id}`, orderDateIso: dateIso, status: 'delivered', channel: 'cash' };
}

describe('buildOrderReportRow + groupRowsByPeriod', () => {
  it('aggregates two orders in the same period and keeps a later period separate', () => {
    const orderA = makeOrder('a', '2026-06-05T00:00:00.000Z');
    const itemsA: OrderItem[] = [
      { id: 'ia', orderId: 'a', qty: 1, buyPrice: 100_000, salePrice: 150_000, supplierId: ALI },
    ];
    const orderB = makeOrder('b', '2026-06-10T00:00:00.000Z');
    const itemsB: OrderItem[] = [
      { id: 'ib', orderId: 'b', qty: 1, buyPrice: 200_000, salePrice: 260_000, supplierId: ALI },
    ];
    const orderC = makeOrder('c', '2026-07-01T00:00:00.000Z');
    const itemsC: OrderItem[] = [
      { id: 'ic', orderId: 'c', qty: 1, buyPrice: 50_000, salePrice: 90_000, supplierId: VAHID },
    ];

    const rows = [
      buildOrderReportRow(orderA, itemsA, []),
      buildOrderReportRow(orderB, itemsB, []),
      buildOrderReportRow(orderC, itemsC, []),
    ];

    const grouped = groupRowsByPeriod(rows, (row) => row.order.orderDateIso.slice(0, 7));

    const june = grouped.find((g) => g.periodKey === '2026-06')!;
    const july = grouped.find((g) => g.periodKey === '2026-07')!;

    expect(june.ordersCount).toBe(2);
    expect(june.grossSale).toBe(150_000 + 260_000);
    expect(june.cost).toBe(100_000 + 200_000);
    expect(july.ordersCount).toBe(1);
    expect(july.grossSale).toBe(90_000);
  });
});

describe('splitPersonalProfit', () => {
  const order = makeOrder('o1', '2026-06-05T00:00:00.000Z');
  const items: OrderItem[] = [
    { id: 'i1', orderId: 'o1', qty: 1, buyPrice: 100_000, salePrice: 300_000, supplierId: VAHID },
  ];
  const row = buildOrderReportRow(order, items, []); // collectedProfit will be 0 with no receipts

  it('keeps the full collected profit personal when no rule matches the supplier', () => {
    const rules: ProfitShareRule[] = [{ id: 'r1', partnerId: 'p1', scopeSupplierId: ALI, pct: 50 }];
    const split = splitPersonalProfit(row, rules);
    expect(split.matchedRule).toBeNull();
    expect(split.partnerShare).toBe(0);
    expect(split.personalShare).toBe(row.collectedProfit);
  });

  it('splits 50/50 when a rule matches the item supplier, without touching purchase debt', () => {
    // Give the order a real confirmed collection so there is something to split.
    const fundedRow = buildOrderReportRow(
      order,
      items,
      [{ id: 'r-1', orderId: 'o1', amount: 300_000, method: 'cash', dateIso: '2026-06-05T00:00:00.000Z' }],
    );
    const rules: ProfitShareRule[] = [{ id: 'r1', partnerId: 'p1', scopeSupplierId: VAHID, pct: 50 }];
    const split = splitPersonalProfit(fundedRow, rules);
    expect(split.matchedRule?.id).toBe('r1');
    expect(split.partnerShare + split.personalShare).toBe(fundedRow.collectedProfit);
    expect(split.partnerShare).toBe(Math.round(fundedRow.collectedProfit * 0.5));
  });

  it('treats a mixed-supplier order as fully personal (no rule can unambiguously apply)', () => {
    const mixedItems: OrderItem[] = [
      { id: 'm1', orderId: 'o1', qty: 1, buyPrice: 50_000, salePrice: 100_000, supplierId: ALI },
      { id: 'm2', orderId: 'o1', qty: 1, buyPrice: 50_000, salePrice: 100_000, supplierId: VAHID },
    ];
    const mixedRow = buildOrderReportRow(order, mixedItems, [
      { id: 'r-2', orderId: 'o1', amount: 200_000, method: 'cash', dateIso: '2026-06-05T00:00:00.000Z' },
    ]);
    const rules: ProfitShareRule[] = [{ id: 'r1', partnerId: 'p1', scopeSupplierId: ALI, pct: 50 }];
    const split = splitPersonalProfit(mixedRow, rules);
    expect(mixedRow.supplierId).toBeNull();
    expect(split.matchedRule).toBeNull();
    expect(split.personalShare).toBe(mixedRow.collectedProfit);
  });
});
