// Shared reporting layer. Daily report, monthly report, and the personal
// profit page all build on the same per-order row and the same
// computeOrderEconomics / computeCollectedProfit functions the dashboard
// uses — so a single order's numbers can never disagree across pages.

import type { Order, OrderItem, CustomerReceipt, SnappSettlement, ProfitShareRule } from './types';
import {
  computeOrderEconomics,
  computeConfirmedCollection,
  computeCollectedProfit,
  computeProfitShareAmount,
  type OrderEconomics,
} from './engine';

export interface OrderReportRow {
  order: Order;
  economics: OrderEconomics;
  confirmedCollection: number;
  collectedProfit: number;
  /** the single supplier behind every item on this order, or null if items span more than one supplier */
  supplierId: string | null;
}

export function buildOrderReportRow(
  order: Order,
  items: OrderItem[],
  receipts: CustomerReceipt[],
  snapp?: SnappSettlement,
): OrderReportRow {
  const economics = computeOrderEconomics(order, items, { snapp });
  const confirmedCollection = computeConfirmedCollection(order, receipts, snapp);
  const collectedProfit = computeCollectedProfit(economics, confirmedCollection);
  const supplierIds = new Set(items.map((it) => it.supplierId));
  const supplierId = supplierIds.size === 1 ? [...supplierIds][0] : null;
  return { order, economics, confirmedCollection, collectedProfit, supplierId };
}

export interface PeriodTotals {
  periodKey: string;
  ordersCount: number;
  grossSale: number;
  cost: number;
  accruedProfit: number;
  collectedProfit: number;
}

function emptyTotals(periodKey: string): PeriodTotals {
  return { periodKey, ordersCount: 0, grossSale: 0, cost: 0, accruedProfit: 0, collectedProfit: 0 };
}

export function groupRowsByPeriod(
  rows: OrderReportRow[],
  keyFn: (row: OrderReportRow) => string,
): PeriodTotals[] {
  const map = new Map<string, PeriodTotals>();
  for (const row of rows) {
    const key = keyFn(row);
    const totals = map.get(key) ?? emptyTotals(key);
    totals.ordersCount += 1;
    totals.grossSale += row.economics.grossSale;
    totals.cost += row.economics.cost;
    totals.accruedProfit += row.economics.accruedProfit;
    totals.collectedProfit += row.collectedProfit;
    map.set(key, totals);
  }
  return Array.from(map.values()).sort((a, b) => b.periodKey.localeCompare(a.periodKey));
}

export interface PersonalProfitSplit {
  personalShare: number;
  partnerShare: number;
  matchedRule: ProfitShareRule | null;
}

/**
 * Splits an order's collected profit between the owner and a partner, based
 * on ProfitShareRule.scopeSupplierId. Only applies when every item on the
 * order comes from a single supplier (see MappedLegacyOrder's note on
 * per-order vs per-item supplier — the same open decision applies here).
 * No matching rule means the full collected profit is personal.
 */
export function splitPersonalProfit(
  row: OrderReportRow,
  rules: ProfitShareRule[],
): PersonalProfitSplit {
  if (!row.supplierId) {
    return { personalShare: row.collectedProfit, partnerShare: 0, matchedRule: null };
  }
  const rule = rules.find((r) => r.scopeSupplierId === row.supplierId) ?? null;
  if (!rule) {
    return { personalShare: row.collectedProfit, partnerShare: 0, matchedRule: null };
  }
  const partnerShare = computeProfitShareAmount(row.collectedProfit, rule.pct);
  return { personalShare: row.collectedProfit - partnerShare, partnerShare, matchedRule: rule };
}
