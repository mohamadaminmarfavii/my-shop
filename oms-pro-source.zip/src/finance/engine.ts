// The single computational source for every money figure in the app.
// Dashboard, daily/monthly reports, supplier accounts, order items,
// customers, personal profit, and profit-share pages must all call these
// functions instead of reading a stored total. Nothing here ever trusts a
// pre-computed field like the legacy `order.profit`.

import type {
  ID,
  Order,
  OrderItem,
  CustomerReceipt,
  SnappSettlement,
  Expense,
  CustomerRefund,
  SupplierPayment,
  PaymentAllocation,
} from './types';

// ---------------------------------------------------------------------------
// Order economics (سود اقتصادی / سود نهایی-تعهدی)
// ---------------------------------------------------------------------------

export interface OrderEconomics {
  grossSale: number;
  discount: number;
  refund: number;
  gatewayFee: number;
  cost: number;
  directExpense: number;
  /** فروش خالص - بهای خرید - کارمزد - تخفیف - برگشت وجه - هزینه مستقیم سفارش */
  accruedProfit: number;
}

export function isOrderCancelled(order: Order): boolean {
  return order.status === 'cancelled';
}

export function computeOrderEconomics(
  order: Order,
  items: OrderItem[],
  opts: {
    snapp?: SnappSettlement;
    refunds?: CustomerRefund[];
    directExpenses?: Expense[];
  } = {},
): OrderEconomics {
  if (isOrderCancelled(order)) {
    return {
      grossSale: 0,
      discount: 0,
      refund: 0,
      gatewayFee: 0,
      cost: 0,
      directExpense: 0,
      accruedProfit: 0,
    };
  }

  const grossSale = items.reduce((sum, it) => sum + it.qty * it.salePrice, 0);
  const cost = items.reduce((sum, it) => sum + it.qty * it.buyPrice, 0);
  const discount =
    (order.discount || 0) + Math.round((grossSale * (order.discountPct || 0)) / 100);

  const customerRefund = (opts.refunds || []).reduce((sum, r) => sum + r.amount, 0);
  const snappRefund = opts.snapp?.refund?.amount || 0;
  const refund = customerRefund + snappRefund;

  const gatewayFee = opts.snapp
    ? opts.snapp.commission + opts.snapp.vatOnCommission - (opts.snapp.refund?.feeRefund || 0)
    : 0;

  const directExpense = (opts.directExpenses || []).reduce((sum, e) => sum + e.amount, 0);

  const accruedProfit = grossSale - cost - gatewayFee - discount - refund - directExpense;

  return { grossSale, discount, refund, gatewayFee, cost, directExpense, accruedProfit };
}

// ---------------------------------------------------------------------------
// Confirmed collection & collected profit (سود وصول‌شده)
// ---------------------------------------------------------------------------

/**
 * Money that has actually, confirmedly landed for this order — never a
 * promise. Snapp's 90% payout only counts once payoutConfirmed is true, and
 * the 10% holdback only counts once it's released. Cash / card-to-card
 * customer receipts count immediately.
 */
export function computeConfirmedCollection(
  order: Order,
  receipts: CustomerReceipt[],
  snapp?: SnappSettlement,
): number {
  if (isOrderCancelled(order)) return 0;

  let total = receipts.reduce((sum, r) => sum + r.amount, 0);

  if (snapp && snapp.payoutConfirmed) {
    const net = snapp.recordedAmount - snapp.commission - snapp.vatOnCommission;
    const payout = Math.round(net * (1 - snapp.holdbackPct / 100));
    total += payout;
    if (snapp.holdbackReleased) {
      const holdback = Math.round(net * (snapp.holdbackPct / 100));
      total += holdback;
    }
  }

  return total;
}

/**
 * Conservative waterfall required by spec: confirmed collection first
 * covers (1) refunds & discounts, then (2) gateway/Snapp fee, then
 * (3) purchase cost — only the surplus after that can be "collected
 * profit", and it is capped at the accrued profit so it never runs ahead
 * of the true economics of the order.
 */
export function computeCollectedProfit(
  economics: OrderEconomics,
  confirmedCollection: number,
): number {
  let remaining = confirmedCollection;

  remaining -= economics.refund + economics.discount;
  if (remaining < 0) remaining = 0;

  remaining -= economics.gatewayFee;
  if (remaining < 0) remaining = 0;

  remaining -= economics.cost;
  if (remaining < 0) remaining = 0;

  return Math.min(remaining, Math.max(economics.accruedProfit, 0));
}

// ---------------------------------------------------------------------------
// Withdrawable profit (سود قابل برداشت)
// ---------------------------------------------------------------------------

/**
 * Withdrawable profit is capped by BOTH collected profit and real free cash.
 * If the cash box is empty, withdrawable profit is zero even when the
 * order's economic profit is positive — paying a supplier reduces cash
 * without erasing the order's accrued profit.
 */
export function computeWithdrawableProfit(
  cashBalanceReal: number,
  collectedProfitRemaining: number,
  immediateObligations: number,
): number {
  const freeCash = Math.max(0, cashBalanceReal - immediateObligations);
  return Math.max(0, Math.min(collectedProfitRemaining, freeCash));
}

// ---------------------------------------------------------------------------
// Supplier payment allocation
// ---------------------------------------------------------------------------

export interface OpenDebtItem {
  orderItemId: ID;
  supplierId: ID;
  orderDateIso: string;
  cost: number; // qty * buyPrice — what's owed to the supplier for this item
}

export function computeItemPaidAmount(itemId: ID, allocations: PaymentAllocation[]): number {
  return allocations
    .filter((a) => a.orderItemId === itemId)
    .reduce((sum, a) => sum + a.amount, 0);
}

export function computeItemBalance(item: OpenDebtItem, allocations: PaymentAllocation[]): number {
  return Math.max(0, item.cost - computeItemPaidAmount(item.orderItemId, allocations));
}

export function computeSupplierTotalDebt(
  items: OpenDebtItem[],
  allocations: PaymentAllocation[],
): number {
  return items.reduce((sum, it) => sum + computeItemBalance(it, allocations), 0);
}

/**
 * THE key architectural fix for bugs #1, #3, #4, #9, #10: PaymentAllocation
 * is never a table that gets incrementally mutated. It is always fully
 * recomputed, from scratch, from the set of *active* SupplierPayments and
 * the current open debt items — a pure function of its inputs.
 *
 * That single decision is what makes:
 *  - normal payment entry non-manual (it's just "recompute after insert"),
 *  - "sync" idempotent (same inputs -> byte-identical output, always),
 *  - soft delete / restore exactly-once (a deleted payment is simply
 *    excluded from `payments`; restoring re-includes it — there is no
 *    separate "reversal" record to duplicate or forget), and
 *  - editing a payment atomic (there is no "release old allocation" step
 *    to get wrong; the next recompute already reflects the new amount/target).
 *
 * Targeted payments NEVER fall back to FIFO for a leftover remainder —
 * that remainder is simply left unallocated so the UI can surface it,
 * per the explicit rule that FIFO only runs when the user picked FIFO.
 */
export function recomputeSupplierAllocations(
  supplierId: ID,
  payments: SupplierPayment[],
  items: OpenDebtItem[],
): PaymentAllocation[] {
  const activePayments = payments
    .filter((p) => p.supplierId === supplierId && p.status === 'active')
    .slice()
    .sort((a, b) => a.dateIso.localeCompare(b.dateIso) || a.id.localeCompare(b.id));

  const supplierItems = items.filter((it) => it.supplierId === supplierId);
  const allocations: PaymentAllocation[] = [];

  for (const payment of activePayments) {
    let remaining = payment.amount;

    if (payment.targetMode === 'targeted' && payment.targetItemIds?.length) {
      for (const itemId of payment.targetItemIds) {
        if (remaining <= 0) break;
        const item = supplierItems.find((it) => it.orderItemId === itemId);
        if (!item) continue;
        const balance = computeItemBalance(item, allocations);
        if (balance <= 0) continue;
        const amount = Math.min(balance, remaining);
        allocations.push({ paymentId: payment.id, orderItemId: itemId, amount });
        remaining -= amount;
      }
      // No FIFO fallback for the remainder — by design.
    } else {
      const fifoOrder = supplierItems
        .slice()
        .sort(
          (a, b) =>
            a.orderDateIso.localeCompare(b.orderDateIso) ||
            a.orderItemId.localeCompare(b.orderItemId),
        );
      for (const item of fifoOrder) {
        if (remaining <= 0) break;
        const balance = computeItemBalance(item, allocations);
        if (balance <= 0) continue;
        const amount = Math.min(balance, remaining);
        allocations.push({ paymentId: payment.id, orderItemId: item.orderItemId, amount });
        remaining -= amount;
      }
    }
  }

  return allocations;
}

// ---------------------------------------------------------------------------
// Pricing rules
// ---------------------------------------------------------------------------

/** قیمت خرید = قیمت اعلامی تأمین‌کننده × (۱ - درصد تخفیف همکاری) */
export function computeAliPurchasePrice(supplierPrice: number, coopDiscountPct: number): number {
  return Math.round(supplierPrice * (1 - coopDiscountPct / 100));
}

/** قیمت پایه فروش = قیمت خرید × (۱ + درصد سود فروشگاه) */
export function computeAliBaseSalePrice(purchasePrice: number, storeMarginPct: number): number {
  return Math.round(purchasePrice * (1 + storeMarginPct / 100));
}

/**
 * The exact "professional & psychological" rounding rule was only given as
 * two approximate (~) examples in the spec, not a precise formula — it's
 * flagged as an open decision for the user (see handoff report). This
 * default only rounds *up* to the nearest 1,000 so a suggested price is
 * never quoted below true cost + margin; it is intentionally the one part
 * of pricing that is safe to swap out once the user picks a concrete rule.
 */
export function roundSuggestedPrice(basePrice: number): number {
  return Math.ceil(basePrice / 1000) * 1000;
}

/** For Vahid's products: suggest his own last recorded sale price, never Ali's % rule. */
export function getVahidSuggestedPrice(
  productId: ID,
  priorItemsForProductChronological: OrderItem[],
): number | null {
  const matches = priorItemsForProductChronological.filter((it) => it.productId === productId);
  if (matches.length === 0) return null;
  return matches[matches.length - 1].salePrice;
}

// ---------------------------------------------------------------------------
// Profit share (سهم همکاری) — computed only from real, collected profit
// ---------------------------------------------------------------------------

export function computeProfitShareAmount(collectedProfitForScope: number, pct: number): number {
  return Math.round((Math.max(0, collectedProfitForScope) * pct) / 100);
}
