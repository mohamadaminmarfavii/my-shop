// Core domain types for OMS Pro's rewritten financial model.
// These replace the single LEGACY_HTML blob and the ad-hoc `order.profit` /
// `order.settlementStatus` flags in the current app. Every amount is an
// integer number of Toman — never a formatted string.

export type ID = string;

export type OrderStatus =
  | 'new'
  | 'in_supply'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

export type OrderChannel = 'cash' | 'snapp' | 'site' | 'credit';

export interface OrderItem {
  id: ID;
  orderId: ID;
  productId?: ID;
  name?: string;
  qty: number;
  buyPrice: number; // toman, per unit
  salePrice: number; // toman, per unit
  supplierId: ID;
}

export interface Order {
  id: ID;
  customerCode: string;
  customerName?: string;
  orderDateIso: string; // ISO date - used for FIFO ordering and month separation
  status: OrderStatus;
  channel: OrderChannel;
  discount?: number; // fixed toman discount
  discountPct?: number; // percentage discount, 0-100
}

export interface CustomerReceipt {
  id: ID;
  orderId: ID;
  amount: number;
  method: 'cash' | 'card_to_card' | 'gateway' | 'other';
  dateIso: string;
}

export interface SnappSettlement {
  id: ID;
  orderId: ID;
  recordedAmount: number; // مبلغ ثبت‌شده در اسنپ‌پی (may differ from real sale)
  commission: number;
  vatOnCommission: number;
  holdbackPct: number; // نگهداری ۱۰٪
  payoutConfirmed: boolean; // آیا واریزی ۹۰٪ تأیید شده
  holdbackReleased: boolean; // آیا نگهداری آزاد شده
  refund?: {
    type: 'full' | 'partial';
    amount: number;
    feeRefund?: number;
  };
}

export interface Expense {
  id: ID;
  orderId?: ID; // present when this is a direct order expense
  amount: number;
  category: string;
  dateIso: string;
}

export interface CustomerRefund {
  id: ID;
  orderId: ID;
  amount: number;
  type: 'full' | 'partial';
  dateIso: string;
}

export type PaymentTargetMode = 'fifo' | 'targeted';

export interface SupplierPayment {
  id: ID;
  supplierId: ID;
  amount: number; // real cash that left the account
  dateIso: string;
  source: string;
  note?: string;
  targetMode: PaymentTargetMode;
  targetItemIds?: ID[]; // used only when targetMode === 'targeted'
  status: 'active' | 'deleted';
}

export interface SupplierRefund {
  id: ID;
  supplierId: ID;
  amount: number;
  relatedPaymentId?: ID;
  dateIso: string;
  note?: string;
}

export interface ProfitShareRule {
  id: ID;
  partnerId: ID;
  scopeSupplierId?: ID;
  scopeProductId?: ID;
  pct: number; // 0-100
}

export interface ProfitSharePayment {
  id: ID;
  ruleId: ID;
  amount: number;
  dateIso: string;
}

export interface CashWithdrawal {
  id: ID;
  amount: number;
  dateIso: string;
  note?: string;
}

export interface OpeningBalance {
  id: ID;
  periodKey: string; // e.g. '1405-06'
  cashBalance: number;
  supplierDebts: Record<ID, number>;
}

// PaymentAllocation is intentionally NOT a table the UI writes to directly.
// It is a derived/materialized view produced by recomputeSupplierAllocations()
// from the set of active SupplierPayments + open order items. See engine.ts.
export interface PaymentAllocation {
  paymentId: ID;
  orderItemId: ID;
  amount: number;
}

export type AuditAction = 'create' | 'update' | 'delete' | 'restore' | 'sync';

export interface AuditLogEntry {
  id: ID;
  entity: string;
  entityId: ID;
  action: AuditAction;
  before: unknown;
  after: unknown;
  actor: string;
  timestampIso: string;
}
