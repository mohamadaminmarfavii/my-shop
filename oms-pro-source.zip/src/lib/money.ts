// All financial amounts in the app are integer Toman. Nothing is ever stored
// as a formatted string. These helpers are the single, shared place that
// turns user/legacy input (which may use Persian digits, Arabic-Indic
// digits, or "٬"/"," thousands separators) into a plain integer, and back
// into a display string.

const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const ARABIC_INDIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';

export class AmountParseError extends Error {}

export function normalizeDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String(PERSIAN_DIGITS.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(ARABIC_INDIC_DIGITS.indexOf(d)));
}

/**
 * Parses a Toman amount from a number or a string that may contain Persian
 * digits, Arabic-Indic digits, Latin digits, and "٬" / "," thousands
 * separators (in any mix). Returns an integer. Empty/null/undefined input
 * is treated as 0. Anything that isn't a recognizable number throws
 * AmountParseError so the caller can surface a real validation error
 * instead of silently treating garbage as zero.
 */
export function parseAmountToman(input: unknown): number {
  if (input === null || input === undefined || input === '') return 0;
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) {
      throw new AmountParseError(`Invalid amount: ${input}`);
    }
    return Math.round(input);
  }
  const normalized = normalizeDigits(String(input)).trim();
  const cleaned = normalized.replace(/[٬,\s]/g, '');
  if (cleaned === '' || cleaned === '-') return 0;
  if (!/^-?\d+(\.\d+)?$/.test(cleaned)) {
    throw new AmountParseError(`Invalid amount string: ${JSON.stringify(input)}`);
  }
  return Math.round(Number(cleaned));
}

export function formatToman(amount: number): string {
  return Math.round(amount).toLocaleString('fa-IR');
}
