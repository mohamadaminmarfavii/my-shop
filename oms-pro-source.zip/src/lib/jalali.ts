// Converts the ISO timestamps stored on Order (which are plain UTC instants)
// to Jalali (Persian) calendar dates for day/month reports. Uses a fixed
// Iran offset (UTC+3:30, no DST currently observed) rather than the host
// machine's local timezone, so day/month boundaries are correct regardless
// of where the app happens to be opened.

import { toJalaali, type JalaaliDate } from 'jalaali-js';

const IRAN_UTC_OFFSET_MINUTES = 210;

export const PERSIAN_MONTH_NAMES = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];

export function isoToJalali(iso: string): JalaaliDate {
  const utcMs = new Date(iso).getTime();
  const iranMs = utcMs + IRAN_UTC_OFFSET_MINUTES * 60_000;
  const shifted = new Date(iranMs);
  return toJalaali(shifted.getUTCFullYear(), shifted.getUTCMonth() + 1, shifted.getUTCDate());
}

/** e.g. "1405-06" — matches the OpeningBalance.periodKey format used elsewhere */
export function periodKey(iso: string): string {
  const { jy, jm } = isoToJalali(iso);
  return `${jy}-${String(jm).padStart(2, '0')}`;
}

/** e.g. "1405-06-13" */
export function dayKey(iso: string): string {
  const { jy, jm, jd } = isoToJalali(iso);
  return `${jy}-${String(jm).padStart(2, '0')}-${String(jd).padStart(2, '0')}`;
}

export function formatJalaliDate(iso: string): string {
  const { jy, jm, jd } = isoToJalali(iso);
  return `${jd} ${PERSIAN_MONTH_NAMES[jm - 1]} ${jy}`;
}

export function formatPeriodLabel(key: string): string {
  const [jy, jm] = key.split('-').map(Number);
  return `${PERSIAN_MONTH_NAMES[jm - 1]} ${jy}`;
}

/** Formats a "1405-06-13"-style day key directly — no ISO round-trip. */
export function formatDayKeyLabel(key: string): string {
  const [jy, jm, jd] = key.split('-').map(Number);
  return `${jd} ${PERSIAN_MONTH_NAMES[jm - 1]} ${jy}`;
}
