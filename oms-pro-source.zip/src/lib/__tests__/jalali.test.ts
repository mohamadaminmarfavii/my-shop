import { describe, expect, it } from 'vitest';
import { isoToJalali, periodKey, dayKey, formatPeriodLabel, formatDayKeyLabel } from '../jalali';

describe('isoToJalali', () => {
  it('matches the real order sample: epoch 1788510600000 is ۱۴۰۵/۶/۱۳', () => {
    const iso = new Date(1_788_510_600_000).toISOString();
    expect(isoToJalali(iso)).toEqual({ jy: 1405, jm: 6, jd: 13 });
  });

  it('produces the expected period key', () => {
    const iso = new Date(1_788_510_600_000).toISOString();
    expect(periodKey(iso)).toBe('1405-06');
  });

  it('produces the expected day key', () => {
    const iso = new Date(1_788_510_600_000).toISOString();
    expect(dayKey(iso)).toBe('1405-06-13');
  });

  it('keeps late-night UTC timestamps on the correct Iran-local day', () => {
    // 21:00 UTC on a given day is 00:30 the *next* day in Iran (UTC+3:30).
    const iso = '2026-09-04T21:00:00.000Z';
    expect(dayKey(iso)).toBe(dayKey('2026-09-05T01:00:00.000Z'));
  });
});

describe('formatPeriodLabel', () => {
  it('renders a period key as a Persian month + year label', () => {
    expect(formatPeriodLabel('1405-06')).toBe('شهریور 1405');
  });
});

describe('formatDayKeyLabel', () => {
  it('renders a day key directly, without an ISO round-trip', () => {
    expect(formatDayKeyLabel('1405-06-13')).toBe('13 شهریور 1405');
  });
});
