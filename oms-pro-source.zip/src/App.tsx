import { useHashRoute } from './ui/useHashRoute';
import { UpdateNotice } from './ui/UpdateNotice';
import { Dashboard } from './pages/Dashboard';
import { Suppliers } from './pages/Suppliers';
import { OrderItemsPage } from './pages/OrderItems';
import { DailyReportPage } from './pages/DailyReport';
import { MonthlyReportPage } from './pages/MonthlyReport';
import { PersonalProfitPage } from './pages/PersonalProfit';
import { MigrationWizard } from './pages/MigrationWizard';
import { BackupRestorePage } from './pages/BackupRestore';
import './app.css';

const TABS = [
  { id: 'dashboard', label: 'داشبورد' },
  { id: 'suppliers', label: 'حساب تأمین‌کنندگان' },
  { id: 'items', label: 'اقلام سفارش‌ها' },
  { id: 'daily', label: 'گزارش روزانه' },
  { id: 'monthly', label: 'گزارش ماهانه' },
  { id: 'profit', label: 'سود شخصی' },
  { id: 'migration', label: 'مهاجرت از پشتیبان قدیمی' },
  { id: 'backup', label: 'پشتیبان‌گیری و بازیابی' },
] as const;

export default function App() {
  const [route, navigate] = useHashRoute('dashboard');

  return (
    <div className="app">
      <header className="app-header">
        <h1>OMS Pro — نسخهٔ بازنویسی‌شده</h1>
        <nav>
          {TABS.map((t) => (
            <button
              key={t.id}
              className={route === t.id ? 'tab active' : 'tab'}
              onClick={() => navigate(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </header>
      <main>
        {route === 'dashboard' && <Dashboard />}
        {route === 'suppliers' && <Suppliers />}
        {route === 'items' && <OrderItemsPage />}
        {route === 'daily' && <DailyReportPage />}
        {route === 'monthly' && <MonthlyReportPage />}
        {route === 'profit' && <PersonalProfitPage />}
        {route === 'migration' && <MigrationWizard />}
        {route === 'backup' && <BackupRestorePage />}
      </main>
      <footer className="app-footer">نسخهٔ {__APP_VERSION__}</footer>
      <UpdateNotice />
    </div>
  );
}
