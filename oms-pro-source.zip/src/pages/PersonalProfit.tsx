import { useState, type FormEvent } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/schema';
import { loadFullOrderData, addProfitShareRule, addProfitSharePayment } from '../db/repo';
import { buildOrderReportRow, splitPersonalProfit } from '../finance/reporting';
import { formatToman, parseAmountToman, AmountParseError } from '../lib/money';
import { SUPPLIER_ALI, SUPPLIER_VAHID, canonicalSupplierLabel } from '../migration/supplierAlias';

export function PersonalProfitPage() {
  const rules = useLiveQuery(() => db.profitShareRules.toArray(), []) ?? [];
  const sharePayments = useLiveQuery(() => db.profitSharePayments.toArray(), []) ?? [];

  const totals =
    useLiveQuery(async () => {
      const { orders, itemsByOrder, receiptsByOrder, snappByOrder } = await loadFullOrderData();
      const currentRules = await db.profitShareRules.toArray();
      let totalCollected = 0;
      let totalPartnerShare = 0;
      let totalPersonalShare = 0;
      for (const order of orders) {
        const row = buildOrderReportRow(
          order,
          itemsByOrder.get(order.id) ?? [],
          receiptsByOrder.get(order.id) ?? [],
          snappByOrder.get(order.id),
        );
        const split = splitPersonalProfit(row, currentRules);
        totalCollected += row.collectedProfit;
        totalPartnerShare += split.partnerShare;
        totalPersonalShare += split.personalShare;
      }
      return { totalCollected, totalPartnerShare, totalPersonalShare };
    }, [rules.length]) ?? { totalCollected: 0, totalPartnerShare: 0, totalPersonalShare: 0 };

  const paidToPartners = sharePayments.reduce((s, p) => s + p.amount, 0);
  const remainingPayable = Math.max(0, totals.totalPartnerShare - paidToPartners);

  const [partnerName, setPartnerName] = useState('');
  const [scopeSupplierId, setScopeSupplierId] = useState(SUPPLIER_VAHID);
  const [pct, setPct] = useState('50');
  const [ruleError, setRuleError] = useState<string | null>(null);

  async function submitRule(e: FormEvent) {
    e.preventDefault();
    setRuleError(null);
    if (!partnerName.trim()) {
      setRuleError('نام شریک را وارد کنید');
      return;
    }
    const pctNum = Number(pct);
    if (!Number.isFinite(pctNum) || pctNum <= 0 || pctNum > 100) {
      setRuleError('درصد باید عددی بین ۱ تا ۱۰۰ باشد');
      return;
    }
    await addProfitShareRule({ partnerId: partnerName.trim(), scopeSupplierId, pct: pctNum });
    setPartnerName('');
  }

  const [selectedRuleId, setSelectedRuleId] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentError, setPaymentError] = useState<string | null>(null);

  async function submitPayment(e: FormEvent) {
    e.preventDefault();
    setPaymentError(null);
    if (!selectedRuleId) {
      setPaymentError('یک قانون را انتخاب کنید');
      return;
    }
    let amount: number;
    try {
      amount = parseAmountToman(paymentAmount);
    } catch (err) {
      setPaymentError(err instanceof AmountParseError ? 'مبلغ نامعتبر است' : 'خطای غیرمنتظره');
      return;
    }
    if (amount <= 0) {
      setPaymentError('مبلغ باید بزرگ‌تر از صفر باشد');
      return;
    }
    await addProfitSharePayment({ ruleId: selectedRuleId, amount, dateIso: new Date().toISOString() });
    setPaymentAmount('');
  }

  return (
    <div>
      <h2>سود شخصی و سهم همکاری</h2>

      <div className="grid">
        <div className="card">
          <div className="card-value">{formatToman(totals.totalCollected)} ت</div>
          <div className="card-label">جمع سود وصول‌شده</div>
        </div>
        <div className="card">
          <div className="card-value">{formatToman(totals.totalPersonalShare)} ت</div>
          <div className="card-label">سهم شخصی من</div>
        </div>
        <div className="card">
          <div className="card-value">{formatToman(totals.totalPartnerShare)} ت</div>
          <div className="card-label">سهم شرکا (تعهدی)</div>
        </div>
        <div className="card">
          <div className="card-value">{formatToman(remainingPayable)} ت</div>
          <div className="card-label">باقیماندهٔ قابل‌پرداخت به شرکا</div>
        </div>
      </div>

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>قوانین سهم همکاری</h3>
        <table className="table">
          <thead>
            <tr>
              <th>شریک</th>
              <th>محدوده (تأمین‌کننده)</th>
              <th>درصد</th>
            </tr>
          </thead>
          <tbody>
            {rules.map((r) => (
              <tr key={r.id}>
                <td>{r.partnerId}</td>
                <td>{r.scopeSupplierId ? canonicalSupplierLabel(r.scopeSupplierId) : '—'}</td>
                <td>٪{r.pct.toLocaleString('fa-IR')}</td>
              </tr>
            ))}
            {rules.length === 0 && (
              <tr>
                <td colSpan={3} style={{ color: 'var(--muted)' }}>
                  قانونی تعریف نشده — بدون قانون، کل سود وصول‌شده شخصی حساب می‌شود.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <form className="form" onSubmit={submitRule}>
          <label>
            نام شریک
            <input value={partnerName} onChange={(e) => setPartnerName(e.target.value)} placeholder="مثلاً وحید" />
          </label>
          <label>
            محدودهٔ تأمین‌کننده
            <select value={scopeSupplierId} onChange={(e) => setScopeSupplierId(e.target.value)}>
              <option value={SUPPLIER_ALI}>{canonicalSupplierLabel(SUPPLIER_ALI)}</option>
              <option value={SUPPLIER_VAHID}>{canonicalSupplierLabel(SUPPLIER_VAHID)}</option>
            </select>
          </label>
          <label>
            درصد سهم
            <input value={pct} onChange={(e) => setPct(e.target.value)} />
          </label>
          {ruleError && <p className="error">{ruleError}</p>}
          <button className="btn-primary" type="submit">
            افزودن قانون
          </button>
        </form>
      </div>

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>ثبت پرداخت سهم همکاری</h3>
        <form className="form" onSubmit={submitPayment}>
          <label>
            قانون
            <select value={selectedRuleId} onChange={(e) => setSelectedRuleId(e.target.value)}>
              <option value="">— انتخاب کنید —</option>
              {rules.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.partnerId} — {r.scopeSupplierId ? canonicalSupplierLabel(r.scopeSupplierId) : '—'} (٪{r.pct})
                </option>
              ))}
            </select>
          </label>
          <label>
            مبلغ
            <input value={paymentAmount} onChange={(e) => setPaymentAmount(e.target.value)} />
          </label>
          {paymentError && <p className="error">{paymentError}</p>}
          <button className="btn-primary" type="submit">
            ثبت پرداخت
          </button>
        </form>

        <table className="table" style={{ marginTop: 16 }}>
          <thead>
            <tr>
              <th>تاریخ</th>
              <th>مبلغ</th>
            </tr>
          </thead>
          <tbody>
            {sharePayments.map((p) => (
              <tr key={p.id}>
                <td>{new Date(p.dateIso).toLocaleDateString('fa-IR')}</td>
                <td>{formatToman(p.amount)}</td>
              </tr>
            ))}
            {sharePayments.length === 0 && (
              <tr>
                <td colSpan={2} style={{ color: 'var(--muted)' }}>
                  پرداختی ثبت نشده.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
