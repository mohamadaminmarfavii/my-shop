import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/schema';
import { getOpenDebtItems, getSupplierAllocations } from '../db/repo';
import { computeItemBalance } from '../finance/engine';
import { formatToman } from '../lib/money';
import { canonicalSupplierLabel } from '../migration/supplierAlias';

export function OrderItemsPage() {
  const rows =
    useLiveQuery(async () => {
      const [items, orders] = await Promise.all([db.orderItems.toArray(), db.orders.toArray()]);
      const orderById = new Map(orders.map((o) => [o.id, o]));
      const supplierIds = Array.from(new Set(items.map((i) => i.supplierId)));

      const balanceByItemId = new Map<string, number>();
      for (const supplierId of supplierIds) {
        const openItems = await getOpenDebtItems(supplierId);
        const allocations = await getSupplierAllocations(supplierId);
        for (const oi of openItems) {
          balanceByItemId.set(oi.orderItemId, computeItemBalance(oi, allocations));
        }
      }

      return items.map((item) => {
        const order = orderById.get(item.orderId);
        const cost = item.qty * item.buyPrice;
        const isCancelled = order?.status === 'cancelled';
        const balance = isCancelled ? 0 : (balanceByItemId.get(item.id) ?? cost);
        return {
          item,
          order,
          cost,
          balance,
          paid: cost - balance,
          isCancelled,
        };
      });
    }, []) ?? [];

  return (
    <table className="table">
      <thead>
        <tr>
          <th>سفارش</th>
          <th>مشتری</th>
          <th>تأمین‌کننده</th>
          <th>بهای خرید</th>
          <th>پرداخت</th>
          <th>مانده</th>
          <th>وضعیت</th>
        </tr>
      </thead>
      <tbody>
        {rows.map(({ item, order, cost, balance, paid, isCancelled }) => (
          <tr key={item.id}>
            <td>{order?.customerCode ?? item.orderId}</td>
            <td>{order?.customerName ?? '—'}</td>
            <td>{canonicalSupplierLabel(item.supplierId)}</td>
            <td>{formatToman(cost)}</td>
            <td>{formatToman(paid)}</td>
            <td>{formatToman(balance)}</td>
            <td>
              {isCancelled ? (
                <span className="badge open">لغوشده</span>
              ) : (
                <span className={balance === 0 ? 'badge ok' : 'badge open'}>
                  {balance === 0 ? 'تسویه‌شده' : 'باز'}
                </span>
              )}
            </td>
          </tr>
        ))}
        {rows.length === 0 && (
          <tr>
            <td colSpan={7} style={{ color: 'var(--muted)' }}>
              هنوز سفارشی وارد نشده — از تب «ورود پشتیبان» استفاده کنید.
            </td>
          </tr>
        )}
      </tbody>
    </table>
  );
}
