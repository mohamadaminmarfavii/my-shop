import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/schema';
import { SUPPLIER_ALI, SUPPLIER_VAHID, canonicalSupplierLabel } from '../migration/supplierAlias';
import { SupplierDetail } from './SupplierDetail';

export function Suppliers() {
  const extraSupplierIds =
    useLiveQuery(async () => {
      const items = await db.orderItems.toArray();
      const ids = new Set(items.map((i) => i.supplierId));
      ids.delete(SUPPLIER_ALI);
      ids.delete(SUPPLIER_VAHID);
      ids.delete('UNRESOLVED');
      return Array.from(ids);
    }, []) ?? [];

  const supplierIds = [SUPPLIER_ALI, SUPPLIER_VAHID, ...extraSupplierIds];
  const [selected, setSelected] = useState<string>(SUPPLIER_VAHID);

  return (
    <div>
      <nav style={{ marginBottom: 16 }}>
        {supplierIds.map((id) => (
          <button
            key={id}
            className={id === selected ? 'tab active' : 'tab'}
            style={{ color: id === selected ? undefined : 'var(--ink)', borderColor: 'var(--border)' }}
            onClick={() => setSelected(id)}
          >
            {canonicalSupplierLabel(id)}
          </button>
        ))}
      </nav>
      <SupplierDetail supplierId={selected} />
    </div>
  );
}
