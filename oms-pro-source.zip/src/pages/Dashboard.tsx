import { useLiveQuery } from 'dexie-react-hooks';
import { getDashboardSummary } from '../db/repo';
import { formatToman } from '../lib/money';

export function Dashboard() {
  const summary = useLiveQuery(() => getDashboardSummary(), []);

  if (!summary) {
    return <p>در حال بارگذاری…</p>;
  }

  const cards: { label: string; value: string }[] = [
    { label: 'تعداد سفارش‌ها', value: summary.ordersCount.toLocaleString('fa-IR') },
    { label: 'فروش ناخالص', value: `${formatToman(summary.grossSale)} ت` },
    { label: 'بهای خرید', value: `${formatToman(summary.cost)} ت` },
    { label: 'سود تعهدی (نهایی)', value: `${formatToman(summary.accruedProfit)} ت` },
    { label: 'سود وصول‌شدهٔ باقیمانده', value: `${formatToman(summary.collectedProfitRemaining)} ت` },
    { label: 'موجودی واقعی صندوق', value: `${formatToman(summary.cashBalance)} ت` },
    { label: 'سود قابل برداشت', value: `${formatToman(summary.withdrawableProfit)} ت` },
  ];

  return (
    <div>
      <div className="grid">
        {cards.map((c) => (
          <div className="card" key={c.label}>
            <div className="card-value">{c.value}</div>
            <div className="card-label">{c.label}</div>
          </div>
        ))}
      </div>
      <div className="panel">
        <p style={{ margin: 0, color: 'var(--muted)', fontSize: '0.85rem' }}>
          همهٔ اعداد بالا در همین لحظه از روی سفارش‌ها، دریافت‌ها، تسویه‌های اسنپ‌پی و پرداخت‌های
          فعال محاسبه شده‌اند — هیچ عددی از یک فیلد ذخیره‌شده خوانده نمی‌شود.
        </p>
      </div>
    </div>
  );
}
