import { useState, type FormEvent } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import {
  getOpenDebtItems,
  getSupplierAllocations,
  listSupplierPayments,
  addSupplierPayment,
  softDeleteSupplierPayment,
  restoreSupplierPayment,
  runSupplierSync,
} from '../db/repo';
import { computeItemBalance, computeSupplierTotalDebt } from '../finance/engine';
import { formatToman, parseAmountToman, AmountParseError } from '../lib/money';
import { canonicalSupplierLabel } from '../migration/supplierAlias';

export function SupplierDetail({ supplierId }: { supplierId: string }) {
  const items = useLiveQuery(() => getOpenDebtItems(supplierId), [supplierId]) ?? [];
  const payments = useLiveQuery(() => listSupplierPayments(supplierId), [supplierId]) ?? [];
  const allocations =
    useLiveQuery(() => getSupplierAllocations(supplierId), [supplierId, payments.length]) ?? [];

  const totalDebt = computeSupplierTotalDebt(items, allocations);
  const openItems = items.filter((it) => computeItemBalance(it, allocations) > 0);

  const [amount, setAmount] = useState('');
  const [dateIso, setDateIso] = useState(() => new Date().toISOString().slice(0, 10));
  const [source, setSource] = useState('صندوق نقدی');
  const [note, setNote] = useState('');
  const [targetMode, setTargetMode] = useState<'fifo' | 'targeted'>('fifo');
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  function toggleItem(id: string) {
    setSelectedItemIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  async function submitPayment(e: FormEvent) {
    e.preventDefault();
    setError(null);
    let parsed: number;
    try {
      parsed = parseAmountToman(amount);
    } catch (err) {
      setError(err instanceof AmountParseError ? 'مبلغ نامعتبر است' : 'خطای غیرمنتظره');
      return;
    }
    if (parsed <= 0) {
      setError('مبلغ باید بزرگ‌تر از صفر باشد');
      return;
    }
    if (targetMode === 'targeted' && selectedItemIds.length === 0) {
      setError('برای پرداخت هدفمند حداقل یک قلم را انتخاب کنید');
      return;
    }
    await addSupplierPayment({
      supplierId,
      amount: parsed,
      dateIso: new Date(dateIso).toISOString(),
      source,
      note: note || undefined,
      targetMode,
      targetItemIds: targetMode === 'targeted' ? selectedItemIds : undefined,
    });
    setAmount('');
    setNote('');
    setSelectedItemIds([]);
  }

  async function handleSync() {
    const { before, after } = await runSupplierSync(supplierId);
    const changed = JSON.stringify(before) !== JSON.stringify(after);
    setSyncMessage(
      changed
        ? 'تخصیص‌ها بازسازی شدند.'
        : 'همه‌چیز از قبل هماهنگ بود — چون تخصیص‌ها همیشه از پرداخت‌های فعال بازمحاسبه می‌شوند، این دکمه هرگز رکورد یا مبلغ جدیدی نمی‌سازد.',
    );
  }

  return (
    <div>
      <h2 style={{ marginBottom: 4 }}>{canonicalSupplierLabel(supplierId)}</h2>
      <p style={{ color: 'var(--muted)' }}>
        بدهی باز فعلی: <strong style={{ color: 'var(--ink)' }}>{formatToman(totalDebt)} تومان</strong>
      </p>

      <table className="table">
        <thead>
          <tr>
            <th>قلم</th>
            <th>بهای خرید</th>
            <th>پرداخت‌شده</th>
            <th>مانده</th>
            <th>وضعیت</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it) => {
            const balance = computeItemBalance(it, allocations);
            const paid = it.cost - balance;
            return (
              <tr key={it.orderItemId}>
                <td>{it.orderItemId}</td>
                <td>{formatToman(it.cost)}</td>
                <td>{formatToman(paid)}</td>
                <td>{formatToman(balance)}</td>
                <td>
                  <span className={balance === 0 ? 'badge ok' : 'badge open'}>
                    {balance === 0 ? 'تسویه‌شده' : 'باز'}
                  </span>
                </td>
              </tr>
            );
          })}
          {items.length === 0 && (
            <tr>
              <td colSpan={5} style={{ color: 'var(--muted)' }}>
                قلمی برای این تأمین‌کننده ثبت نشده.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>ثبت پرداخت جدید</h3>
        <form className="form" onSubmit={submitPayment}>
          <label>
            مبلغ (تومان)
            <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="مثلاً ۱٬۶۵۰٬۰۰۰" />
          </label>
          <label>
            تاریخ
            <input type="date" value={dateIso} onChange={(e) => setDateIso(e.target.value)} />
          </label>
          <label>
            منبع پرداخت
            <input value={source} onChange={(e) => setSource(e.target.value)} />
          </label>
          <label>
            یادداشت
            <input value={note} onChange={(e) => setNote(e.target.value)} />
          </label>

          <div className="form-row-inline" style={{ marginBottom: 8 }}>
            <input
              id="mode-fifo"
              type="radio"
              checked={targetMode === 'fifo'}
              onChange={() => setTargetMode('fifo')}
            />
            <label htmlFor="mode-fifo">اتصال خودکار به قدیمی‌ترین بدهی (FIFO)</label>
          </div>
          <div className="form-row-inline" style={{ marginBottom: 12 }}>
            <input
              id="mode-targeted"
              type="radio"
              checked={targetMode === 'targeted'}
              onChange={() => setTargetMode('targeted')}
            />
            <label htmlFor="mode-targeted">فقط سفارش / قلم مشخص</label>
          </div>

          {targetMode === 'targeted' && (
            <div style={{ marginBottom: 12 }}>
              {openItems.map((it) => (
                <div className="form-row-inline" key={it.orderItemId}>
                  <input
                    type="checkbox"
                    checked={selectedItemIds.includes(it.orderItemId)}
                    onChange={() => toggleItem(it.orderItemId)}
                  />
                  <span>
                    {it.orderItemId} — مانده {formatToman(computeItemBalance(it, allocations))} تومان
                  </span>
                </div>
              ))}
              {openItems.length === 0 && <p style={{ color: 'var(--muted)' }}>قلم بازی برای انتخاب نیست.</p>}
            </div>
          )}

          {error && <p className="error">{error}</p>}
          <button className="btn-primary" type="submit">
            ثبت پرداخت
          </button>
        </form>
      </div>

      <h3>پرداخت‌های ثبت‌شده</h3>
      <table className="table">
        <thead>
          <tr>
            <th>تاریخ</th>
            <th>مبلغ</th>
            <th>حالت اتصال</th>
            <th>وضعیت</th>
            <th>عملیات</th>
          </tr>
        </thead>
        <tbody>
          {payments.map((p) => (
            <tr key={p.id} style={{ opacity: p.status === 'deleted' ? 0.5 : 1 }}>
              <td>{new Date(p.dateIso).toLocaleDateString('fa-IR')}</td>
              <td>{formatToman(p.amount)}</td>
              <td>{p.targetMode === 'fifo' ? 'FIFO' : 'هدفمند'}</td>
              <td>{p.status === 'active' ? 'فعال' : 'حذف‌شده'}</td>
              <td>
                {p.status === 'active' ? (
                  <button className="btn-secondary btn-danger" onClick={() => softDeleteSupplierPayment(p.id)}>
                    حذف
                  </button>
                ) : (
                  <button className="btn-secondary" onClick={() => restoreSupplierPayment(p.id)}>
                    بازیابی
                  </button>
                )}
              </td>
            </tr>
          ))}
          {payments.length === 0 && (
            <tr>
              <td colSpan={5} style={{ color: 'var(--muted)' }}>
                هنوز پرداختی ثبت نشده.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <button className="btn-secondary" onClick={handleSync}>
        همگام‌سازی (پیش‌نمایش امن)
      </button>
      {syncMessage && (
        <p style={{ color: 'var(--muted)', fontSize: '0.85rem', marginTop: 8 }}>{syncMessage}</p>
      )}
    </div>
  );
}
