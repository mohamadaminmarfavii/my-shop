import { useLiveQuery } from 'dexie-react-hooks';
import { loadFullOrderData } from '../db/repo';
import { buildOrderReportRow, groupRowsByPeriod } from '../finance/reporting';
import { dayKey, formatDayKeyLabel } from '../lib/jalali';
import { formatToman } from '../lib/money';

export function DailyReportPage() {
  const rows = useLiveQuery(async () => {
    const { orders, itemsByOrder, receiptsByOrder, snappByOrder } = await loadFullOrderData();
    return orders.map((order) =>
      buildOrderReportRow(
        order,
        itemsByOrder.get(order.id) ?? [],
        receiptsByOrder.get(order.id) ?? [],
        snappByOrder.get(order.id),
      ),
    );
  }, []);

  const days = rows ? groupRowsByPeriod(rows, (row) => dayKey(row.order.orderDateIso)) : [];

  return (
    <div>
      <h2>گزارش روزانه</h2>
      <table className="table">
        <thead>
          <tr>
            <th>روز</th>
            <th>تعداد سفارش</th>
            <th>فروش ناخالص</th>
            <th>بهای خرید</th>
            <th>سود تعهدی</th>
            <th>سود وصول‌شده</th>
          </tr>
        </thead>
        <tbody>
          {days.map((d) => (
            <tr key={d.periodKey}>
              <td>{formatDayKeyLabel(d.periodKey)}</td>
              <td>{d.ordersCount.toLocaleString('fa-IR')}</td>
              <td>{formatToman(d.grossSale)}</td>
              <td>{formatToman(d.cost)}</td>
              <td>{formatToman(d.accruedProfit)}</td>
              <td>{formatToman(d.collectedProfit)}</td>
            </tr>
          ))}
          {days.length === 0 && (
            <tr>
              <td colSpan={6} style={{ color: 'var(--muted)' }}>
                هنوز سفارشی ثبت نشده.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
