import { useLiveQuery } from 'dexie-react-hooks';
import { loadFullOrderData } from '../db/repo';
import { buildOrderReportRow, groupRowsByPeriod } from '../finance/reporting';
import { periodKey, formatPeriodLabel } from '../lib/jalali';
import { formatToman } from '../lib/money';

export function MonthlyReportPage() {
  const rows = useLiveQuery(async () => {
    const { orders, itemsByOrder, receiptsByOrder, snappByOrder } = await loadFullOrderData();
    return orders.map((order) =>
      buildOrderReportRow(
        order,
        itemsByOrder.get(order.id) ?? [],
        receiptsByOrder.get(order.id) ?? [],
        snappByOrder.get(order.id),
      ),
    );
  }, []);

  const months = rows ? groupRowsByPeriod(rows, (row) => periodKey(row.order.orderDateIso)) : [];

  return (
    <div>
      <h2>گزارش ماهانه</h2>
      <p style={{ color: 'var(--muted)' }}>
        هر ماه فقط بر اساس سفارش‌های همان ماه محاسبه می‌شود — مانده اول دوره از رکورد
        OpeningBalance جداگانه خوانده می‌شود، نه از دوباره‌شماری سفارش‌های ماه قبل.
      </p>
      <table className="table">
        <thead>
          <tr>
            <th>ماه</th>
            <th>تعداد سفارش</th>
            <th>فروش ناخالص</th>
            <th>بهای خرید</th>
            <th>سود تعهدی</th>
            <th>سود وصول‌شده</th>
          </tr>
        </thead>
        <tbody>
          {months.map((m) => (
            <tr key={m.periodKey}>
              <td>{formatPeriodLabel(m.periodKey)}</td>
              <td>{m.ordersCount.toLocaleString('fa-IR')}</td>
              <td>{formatToman(m.grossSale)}</td>
              <td>{formatToman(m.cost)}</td>
              <td>{formatToman(m.accruedProfit)}</td>
              <td>{formatToman(m.collectedProfit)}</td>
            </tr>
          ))}
          {months.length === 0 && (
            <tr>
              <td colSpan={6} style={{ color: 'var(--muted)' }}>
                هنوز سفارشی ثبت نشده.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
