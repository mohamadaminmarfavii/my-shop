import { useState, type ChangeEvent } from 'react';
import { mapLegacyOrder, type LegacyOrder } from '../migration/mapLegacyOrder';
import { runPreflightChecks, type MigrationIssue } from '../migration/preflight';
import { addOrderWithItems, upsertSnappSettlement } from '../db/repo';
import { exportBackup, triggerJsonDownload } from '../migration/backup';
import { formatToman } from '../lib/money';

interface DryRunReport {
  rawOrders: LegacyOrder[];
  issues: MigrationIssue[];
  ordersCount: number;
  itemsCount: number;
  totalGrossSaleRecomputed: number;
  totalCostRecomputed: number;
}

type Status = 'idle' | 'running' | 'done' | 'error';

export function MigrationWizard() {
  const [report, setReport] = useState<DryRunReport | null>(null);
  const [fileName, setFileName] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [resultLog, setResultLog] = useState<string[]>([]);

  async function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setStatus('running');
    setReport(null);
    setResultLog([]);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const rawOrders: LegacyOrder[] = parsed?.data?.orders ?? parsed?.orders ?? [];
      const issues = runPreflightChecks(rawOrders);

      let totalGrossSaleRecomputed = 0;
      let totalCostRecomputed = 0;
      let itemsCount = 0;
      for (const raw of rawOrders) {
        const { order, items } = mapLegacyOrder(raw);
        itemsCount += items.length;
        if (order.status !== 'cancelled') {
          totalGrossSaleRecomputed += items.reduce((s, it) => s + it.qty * it.salePrice, 0);
          totalCostRecomputed += items.reduce((s, it) => s + it.qty * it.buyPrice, 0);
        }
      }

      setFileName(file.name);
      setReport({ rawOrders, issues, ordersCount: rawOrders.length, itemsCount, totalGrossSaleRecomputed, totalCostRecomputed });
      setStatus('idle');
    } catch (err) {
      setResultLog([`خطا در خواندن فایل: ${(err as Error).message}`]);
      setStatus('error');
    }
  }

  async function confirmAndRun() {
    if (!report) return;
    setStatus('running');
    const log: string[] = [];
    try {
      const backup = await exportBackup();
      triggerJsonDownload(`oms-pro-backup-before-migration-${Date.now()}.json`, backup);
      log.push('پشتیبان کامل قبل از مهاجرت دانلود شد — این فایل را نگه دارید، مهاجرت با همین فایل قابل برگشت است.');

      let imported = 0;
      for (const raw of report.rawOrders) {
        const { order, items, snapp } = mapLegacyOrder(raw);
        await addOrderWithItems(order, items);
        if (snapp) await upsertSnappSettlement(snapp);
        imported++;
      }
      log.push(`${imported.toLocaleString('fa-IR')} سفارش با موفقیت وارد شد.`);
      log.push(
        'توجه: پرداخت‌های تأمین‌کننده در این پشتیبان اصلاً ذخیره نشده بودند؛ آن‌ها را از تب «حساب تأمین‌کنندگان» به‌صورت دستی وارد کنید.',
      );
      setResultLog(log);
      setStatus('done');
    } catch (err) {
      log.push(`خطا حین مهاجرت: ${(err as Error).message}`);
      setResultLog(log);
      setStatus('error');
    }
  }

  const errorCount = report?.issues.filter((i) => i.severity === 'error').length ?? 0;
  const warningCount = report?.issues.filter((i) => i.severity === 'warning').length ?? 0;

  return (
    <div>
      <h2>مهاجرت از پشتیبان قدیمی</h2>
      <p style={{ color: 'var(--muted)' }}>
        مرحلهٔ اول همیشه Dry Run است — تا وقتی خودتان روی «تأیید و اجرای مهاجرت» نزنید، هیچ داده‌ای
        نوشته نمی‌شود.
      </p>

      {!report && (
        <div className="panel">
          <input type="file" accept="application/json" onChange={handleFile} disabled={status === 'running'} />
          {status === 'error' && resultLog.map((l, i) => (
            <p key={i} className="error">
              {l}
            </p>
          ))}
        </div>
      )}

      {report && status !== 'done' && (
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>گزارش پیش‌نمایش (Dry Run) — {fileName}</h3>
          <ul>
            <li>تعداد سفارش‌ها: {report.ordersCount.toLocaleString('fa-IR')}</li>
            <li>تعداد اقلام: {report.itemsCount.toLocaleString('fa-IR')}</li>
            <li>جمع فروش بازمحاسبه‌شده (بدون سفارش‌های لغوشده): {formatToman(report.totalGrossSaleRecomputed)} ت</li>
            <li>جمع بهای خرید بازمحاسبه‌شده: {formatToman(report.totalCostRecomputed)} ت</li>
            <li>
              خطاها: <strong>{errorCount.toLocaleString('fa-IR')}</strong> — هشدارها:{' '}
              <strong>{warningCount.toLocaleString('fa-IR')}</strong>
            </li>
          </ul>

          {report.issues.length > 0 && (
            <table className="table">
              <thead>
                <tr>
                  <th>سفارش</th>
                  <th>نوع</th>
                  <th>پیام</th>
                </tr>
              </thead>
              <tbody>
                {report.issues.map((issue, i) => (
                  <tr key={i}>
                    <td>{issue.orderId}</td>
                    <td>
                      <span
                        className="badge"
                        style={
                          issue.severity === 'error'
                            ? { background: '#fdeee9', color: 'var(--danger)' }
                            : { background: '#fff6e0', color: '#8a6d00' }
                        }
                      >
                        {issue.severity === 'error' ? 'خطا' : 'هشدار'}
                      </span>
                    </td>
                    <td>{issue.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-primary" onClick={confirmAndRun} disabled={status === 'running' || errorCount > 0}>
              تأیید و اجرای مهاجرت
            </button>
            <button
              className="btn-secondary"
              onClick={() => {
                setReport(null);
                setStatus('idle');
              }}
            >
              لغو
            </button>
          </div>
          {errorCount > 0 && (
            <p className="error">تا وقتی خطاها رفع نشوند، اجرای واقعی مهاجرت غیرفعال است.</p>
          )}
        </div>
      )}

      {status === 'done' && (
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>نتیجهٔ مهاجرت</h3>
          <ul>
            {resultLog.map((l, i) => (
              <li key={i}>{l}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
