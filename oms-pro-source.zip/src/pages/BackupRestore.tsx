import { useState, type ChangeEvent } from 'react';
import {
  exportBackup,
  triggerJsonDownload,
  validateBackupFile,
  getCurrentCounts,
  restoreBackup,
  type BackupFile,
  type BackupData,
} from '../migration/backup';

const TABLE_LABELS: Record<keyof BackupData, string> = {
  orders: 'سفارش‌ها',
  orderItems: 'اقلام سفارش‌ها',
  customerReceipts: 'دریافت‌های مشتری',
  snappSettlements: 'تسویه‌های اسنپ‌پی',
  supplierPayments: 'پرداخت‌های تأمین‌کننده',
  supplierRefunds: 'برگشت‌های تأمین‌کننده',
  expenses: 'هزینه‌ها',
  customerRefunds: 'برگشت‌های مشتری',
  profitShareRules: 'قوانین سهم همکاری',
  profitSharePayments: 'پرداخت‌های سهم همکاری',
  cashWithdrawals: 'برداشت‌های نقدی',
  openingBalances: 'مانده‌های اول دوره',
  auditLog: 'تاریخچهٔ عملیات',
};

export function BackupRestorePage() {
  const [pending, setPending] = useState<{
    backup: BackupFile;
    counts: Partial<Record<keyof BackupData, number>>;
    currentCounts: Record<keyof BackupData, number>;
  } | null>(null);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [status, setStatus] = useState<'idle' | 'restoring' | 'done'>('idle');

  async function handleDownload() {
    const backup = await exportBackup();
    triggerJsonDownload(`oms-pro-backup-${Date.now()}.json`, backup);
  }

  async function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setValidationErrors([]);
    setPending(null);
    setStatus('idle');
    try {
      const text = await file.text();
      const json = JSON.parse(text);
      const validation = validateBackupFile(json);
      if (!validation.ok) {
        setValidationErrors(validation.errors);
        return;
      }
      const currentCounts = await getCurrentCounts();
      setPending({ backup: json as BackupFile, counts: validation.counts ?? {}, currentCounts });
    } catch (err) {
      setValidationErrors([`فایل قابل خواندن نیست: ${(err as Error).message}`]);
    }
  }

  async function confirmRestore() {
    if (!pending) return;
    setStatus('restoring');
    await restoreBackup(pending.backup);
    setStatus('done');
    setPending(null);
  }

  return (
    <div>
      <h2>پشتیبان‌گیری و بازیابی</h2>

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>دانلود پشتیبان کامل فعلی</h3>
        <p style={{ color: 'var(--muted)' }}>
          فایل شامل نسخهٔ schema و تاریخ ساخت است، برای اعتبارسنجی هنگام بازیابی.
        </p>
        <button className="btn-primary" onClick={handleDownload}>
          دانلود پشتیبان JSON
        </button>
      </div>

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>بازیابی از فایل پشتیبان</h3>
        <p style={{ color: 'var(--muted)' }}>
          فایل قبل از هر تغییری اعتبارسنجی و پیش‌نمایش می‌شود؛ تأیید نهایی، دادهٔ فعلی را با محتوای
          فایل جایگزین می‌کند.
        </p>
        <input type="file" accept="application/json" onChange={handleFile} disabled={status === 'restoring'} />

        {validationErrors.length > 0 && (
          <ul>
            {validationErrors.map((e, i) => (
              <li key={i} className="error">
                {e}
              </li>
            ))}
          </ul>
        )}

        {pending && (
          <div>
            <table className="table">
              <thead>
                <tr>
                  <th>جدول</th>
                  <th>تعداد فعلی</th>
                  <th>تعداد در پشتیبان</th>
                </tr>
              </thead>
              <tbody>
                {(Object.keys(TABLE_LABELS) as (keyof BackupData)[]).map((name) => (
                  <tr key={name}>
                    <td>{TABLE_LABELS[name]}</td>
                    <td>{pending.currentCounts[name].toLocaleString('fa-IR')}</td>
                    <td>{(pending.counts[name] ?? 0).toLocaleString('fa-IR')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="error">
              توجه: تأیید این عملیات، تمام دادهٔ فعلی برنامه را با محتوای این فایل جایگزین می‌کند.
            </p>
            <button className="btn-primary" onClick={confirmRestore} disabled={status === 'restoring'}>
              تأیید و بازیابی
            </button>
          </div>
        )}

        {status === 'done' && <p>بازیابی با موفقیت انجام شد.</p>}
      </div>
    </div>
  );
}
